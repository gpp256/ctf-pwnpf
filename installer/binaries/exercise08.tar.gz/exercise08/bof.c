/* bof.c */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void get_flag() {
    char buf[100];
    int fd = open("flag",0); 
    read(fd, buf, 100);
    write(1, buf, strlen(buf));
    exit(0);
    //execve("/bin/sh", 0, 0); exit(0);
}

int main(int argc, char *argv[]) {
    char magic_number[] = "\xff\xe4\xff\xd4\x54\xc3";
    char buf[300] = {};  /* set all bytes to zero */
    //printf("buf = %p\n", buf);
    //fflush(stdout);
    sleep(1);
    fgets(buf, 0x300, stdin);
    puts(buf);
    return 0;
}
