#include <stdio.h>
#include <stdlib.h>

static void vuln() {
       char buf[100];
       gets(buf);
       printf("Hello! %s\n", buf);
}

int main() {
       setvbuf(stdout, 0, _IONBF, 0);
       puts("Can you tell me your name?");
       vuln();
       return 0;
}
