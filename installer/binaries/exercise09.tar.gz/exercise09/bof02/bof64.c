// gcc -fno-stack-protector -o bof64 bof64.c
#include <stdio.h>
#include <stdlib.h>

static void vuln() {
        char buf[100];
        gets(buf); // gets(3)なので0x00 が入力に混じってもOK。改行まで読み込んでくれる。　fgets(3)の場合は0x00不可=>stack pivotは無理なので、_startなどを使う
        printf("Hello! %s\n", buf);
}

int main() {
        setvbuf(stdout, 0, _IONBF, 0);
        puts("Can you tell me your name?");
        vuln();
        return 0;
}

