// gcc -m32 -fno-stack-protector -o bof bof.c
#include <stdio.h>
#include <stdlib.h>

static void vuln() {
        char buf[100];
        gets(buf);
        printf("Hello! %s\n", buf);
        fflush(stdout);
}

int main() {
        system("date 2>/dev/null");
        puts("Can you tell me your name?");
        fflush(stdout);
        vuln();
        return 0;
}
//__END__
