#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

static void show_flag()
{
        char buf[100] = {0};
        int fd = open("./flag", 0);
        read(fd, buf, sizeof(buf)-1);
        printf("Congrats! %s\n", buf);
}

static void vuln(char *str)
{
        printf(str);
        puts("");
}

int main(int argc, char **argv)
{
        char buf[256] = {0};
        char *p;
        setvbuf(stdout, 0, _IONBF, 0);

        while(1) {
                write(1, "Hello! Can you tell me your name?\n", 34);
                if (fgets(buf, sizeof(buf), stdin)) {
                        p = strchr(buf, '\n');
                        if (p) *p = '\0';
                } else {
                        return(EXIT_FAILURE);
                }
                if (strlen(buf)==0) {
                        puts("bye");
                        return(EXIT_FAILURE);
                }
                vuln(buf);
        }
        return 0;
}
