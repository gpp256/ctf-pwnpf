#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

static void show_flag()
{
        char buf[100] = {0};
        int fd = open("./flag", 0);
        read(fd, buf, sizeof(buf)-1);
        printf("Congrats! %s\n", buf);
}

static void vuln(char *str)
{
        printf(str);
        puts("bye");
}

int main(int argc, char **argv)
{
        char buf[256] = {0};
        setvbuf(stdout, 0, _IONBF, 0);
        write(1, "Hello! Can you tell me your name?\n", 34);
        if (read(0, buf, sizeof(buf) - 1) <= 0) exit(EXIT_FAILURE);
        vuln(buf);
        return 0;
}
