/* bof.c */
#include <stdio.h>
#include <string.h>

void vuln() {
    char buf[100];
    memset(buf, '\0', sizeof(buf));
    read(0, buf, 0x400); // ★BoF!
}

int main(int argc, char *argv[])
{
    char cheat[] = "\xff\xe4\xff\xd4\x54\xc3"; // jmp esp...
    vuln();
    return 0;
}

