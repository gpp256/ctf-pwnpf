#!/bin/sh
#
# install.sh
#
# Copyright (c) 2019 gpp256
# This software is distributed under the MIT License.

git clone https://github.com/niklasb/libc-database.git
patch -p0 < dump.patch
patch -p0 < libcommon.patch
#(cd libc-database/; bash get)
## sh -x fetch_libc.sh x86
## sh -x fetch_libc.sh amd64
# e.g.
## crontab -e
#0 0 */3 * * (cd /opt/ctf/tools/libcdb; sh fetch_libc.sh x86 >/dev/null 2>&1)
#0 1 */3 * * (cd /opt/ctf/tools/libcdb; sh fetch_libc.sh amd64 >/dev/null 2>&1)
