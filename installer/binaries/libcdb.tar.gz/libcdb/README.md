libcdb
===============

libcdb is a tool for creating libc database.

Quick Start
------------

To start, run the following commands.

    $ sh -x install.sh
    $ sh fetch_libc.sh
    Usage: ./fetch_libc.sh {x86|amd64}
    $ sh -x fetch_libc.sh x86
    $ sh -x fetch_libc.sh amd64


    $ (cd libc-database; ./find system fc0)
    archive-eglibc (id libc6-i386_2.15-0ubuntu10_amd64)
    ../libc-2.20.amd64.gentoo.20150910.so (id local-8f317b704fed0ee92204cd48b7c34599083022aa)
    $ (cd libc-database; ./dump local-8f317b704fed0ee92204cd48b7c34599083022aa)
    offset___libc_start_main_ret = 0x19943
    offset_system = 0x0003dc70
    offset_dup2 = 0x000db1a0
    offset_read = 0x000da860
    offset_write = 0x000da8e0
    offset_execl = 0x000b6320
    offset_execv = 0x000b6180
    offset_mprotect = 0x000e6170
    offset_mmap = 0x000e6060
    offset_str_bin_sh = 0x159493
    offset_one_gadget_rce = 0x3db21

Links
--------

https://github.com/niklasb/libc-database  
http://libcdb.com/  
http://security.ubuntu.com/ubuntu/pool/main/e/eglibc/
http://security.ubuntu.com/ubuntu/pool/main/g/glibc/

License
----------

You are bound to the license agreement included in respective files.

