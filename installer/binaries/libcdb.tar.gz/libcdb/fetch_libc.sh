#!/bin/bash
#
# fetch_libc.sh
#
# Copyright (c) 2019 gpp256
# This software is distributed under the MIT License.

# get libc.so.6 in Gentoo-autobuild-files
# Usage: sh fetch_libc.sh {x86|amd64}

# proxy
#HTTP_PROXY=http://2.2.2.2:8080
CURL="curl -s"
RETRY=5
#CURL="curl -x $HTTP_PROXY"
#env > /tmp/environ 

# x86
get_libc_x86() {
url=http://distfiles.gentoo.org/releases/x86/autobuilds/current-install-x86-minimal/
while [ $RETRY -gt 0 ] ; do
	f=`$CURL -l $url | egrep -e 'stage3\-i[46]86\-[A-Za-z0-9]*\.tar\.xz<' 2>/dev/null`
	f=`echo $f | awk -F '"' '{print $8}' 2>/dev/null`
	if [ "x$f" = "x" ] ; then
	RETRY=`expr $RETRY \- 1`; sleep 1; continue
	fi
	break
done
if [ "x$f" = "x" ] ; then
	echo "Error: failed to fetch files"; exit 2
fi
$CURL -o $f ${url}$f
#f=stage3-i686-20150915.tar.bz2
build_date=`echo $f | awk -F '[-.]' '{print $3}' 2>/dev/null`
libcname=`tar tvJf $f ./lib/libc.so.6 2>/dev/null | awk '{print $8}' 2>/dev/null`
libc_prefix=`echo $libcname | sed -e 's/so//' 2>/dev/null`
#libc_prefix=libc-2.20.
#build_date=20150910
tar xvJOf $f ./lib/$libcname > ${libc_prefix}i686.gentoo.${build_date}.so
(cd libc-database; bash add ../${libc_prefix}i686.gentoo.${build_date}.so)
rm -f $f ${libc_prefix}i686.gentoo.${build_date}.so
}

# amd64 
get_libc_amd64() {
url=http://distfiles.gentoo.org/releases/amd64/autobuilds/current-install-amd64-minimal/
while [ $RETRY -gt 0 ] ; do
	f=`$CURL -l $url | egrep -e 'stage3\-amd64\-[A-Za-z0-9]*\.tar\.xz<' 2>/dev/null`
	f=`echo $f | awk -F '"' '{print $8}' 2>/dev/null`
	if [ "x$f" = "x" ] ; then
	RETRY=`expr $RETRY \- 1`; sleep 1; continue
	fi
	break
done
if [ "x$f" = "x" ] ; then
	echo "Error: failed to fetch files"; exit 2
fi
$CURL -o $f ${url}$f
#f=stage3-amd64-20150910.tar.bz2
build_date=`echo $f | awk -F '[-.]' '{print $3}' 2>/dev/null`
libcname=`tar tvJf $f ./lib32/libc.so.6 2>/dev/null | awk '{print $8}' 2>/dev/null`
libc_prefix=`echo $libcname | sed -e 's/so//' 2>/dev/null`
tar xvJOf $f ./lib32/$libcname > ${libc_prefix}amd64.32.gentoo.${build_date}.so
tar xvJOf $f ./lib64/$libcname > ${libc_prefix}amd64.64.gentoo.${build_date}.so
(cd libc-database; bash add ../${libc_prefix}amd64.32.gentoo.${build_date}.so)
(cd libc-database; bash add ../${libc_prefix}amd64.64.gentoo.${build_date}.so)
rm -f $f ${libc_prefix}amd64.*.gentoo.${build_date}.so
}

get_libc_amd64_stage4() {
url="http://distfiles.gentoo.org/releases/amd64/autobuilds/latest-stage4-amd64-minimal.txt"
while [ $RETRY -gt 0 ] ; do
	f=`$CURL -l $url | awk '/^20/ {print $1}' 2>/dev/null`
	#20180201T214502Z/stage4-amd64-minimal-20180201T214502Z.tar.bz2
	if [ "x$f" = "x" ] ; then
	RETRY=`expr $RETRY \- 1`; sleep 1; continue
	fi
	break
done
if [ "x$f" = "x" ] ; then
	echo "Error: failed to fetch files"; exit 2
fi
TAROPT=J
if echo $f | grep -q 'bz2$' 2>/dev/null ; then
TAROPT=j
fi
#20180201T214502Z/stage4-amd64-minimal-20180201T214502Z.tar.bz2
fname=`basename $f`
url="http://distfiles.gentoo.org/releases/amd64/autobuilds/"
$CURL -o $fname ${url}$f
build_date=`echo $f | awk -F '[-.]' '{print $4}' 2>/dev/null`
libcname=`tar tv${TAROPT}f $fname ./lib32/libc.so.6 2>/dev/null | awk '{print $8}' 2>/dev/null`
libc_prefix=`echo $libcname | sed -e 's/so//' 2>/dev/null`
tar xv${TAROPT}Of $fname ./lib32/$libcname > ${libc_prefix}amd64.32.gentoo.${build_date}.so
tar xv${TAROPT}Of $fname ./lib64/$libcname > ${libc_prefix}amd64.64.gentoo.${build_date}.so
(cd libc-database; bash add ../${libc_prefix}amd64.32.gentoo.${build_date}.so)
(cd libc-database; bash add ../${libc_prefix}amd64.64.gentoo.${build_date}.so)
rm -f $fname ${libc_prefix}amd64.*.gentoo.${build_date}.so
}

# Main Routine
if [ $# -ne 1 ] ; then
  echo "Usage: ./$0 {x86|amd64|amd64_stage4}"; exit 1
fi

case $1 in
  x86)   get_libc_x86;   ;;
  amd64) get_libc_amd64; ;;
  amd64_stage4) get_libc_amd64_stage4; ;;
  *)
    echo "Usage: ./$0 {x86|amd64|amd64_stage4}"; exit 1
esac
exit 0
#__END__

#http://libcdb.com/
# git clone https://github.com/niklasb/libc-database.git

# ./get
##Getting archive-glibc
##  -> Location: http://security.ubuntu.com/ubuntu/pool/main/g/glibc//libc6-amd64_2.21-0ubuntu4_i386.deb
##  -> ID: libc6-amd64_2.21-0ubuntu4_i386
##  -> Downloading package
##  -> Extracting package
##  -> Writing libc to db/libc6-amd64_2.21-0ubuntu4_i386.so
##  -> Writing symbols to db/libc6-amd64_2.21-0ubuntu4_i386.symbols

# bash add ../libc-2.20.i686.gentoo.20150915.so
##Adding local libc ../libc-2.20.i686.gentoo.20150915.so (id local-137378b2dafc659ed379697ba1296f1c54d0dfed  ../libc-2.20.i686.gentoo.20150915.so)
##  -> Writing libc to db/local-137378b2dafc659ed379697ba1296f1c54d0dfed.so
##  -> Writing symbols to db/local-137378b2dafc659ed379697ba1296f1c54d0dfed.symbols
##  -> Writing version info

## (cd libc-database; ./find system fc0)
#archive-eglibc (id libc6-i386_2.15-0ubuntu10_amd64)
#../libc-2.20.amd64.gentoo.20150910.so (id local-8f317b704fed0ee92204cd48b7c34599083022aa)

## (cd libc-database; ./dump local-8f317b704fed0ee92204cd48b7c34599083022aa)
#offset___libc_start_main_ret = 0x21aa5
#offset_system = 0x0000000000040fc0
#offset_dup2 = 0x00000000000db400
#offset_read = 0x00000000000dad50
#offset_write = 0x00000000000dadb0
#offset_str_bin_sh = 0x15e92a
## (cd libc-database; ./dump local-137378b2dafc659ed379697ba1296f1c54d0dfed execle)
#offset_execle = 0x000b61c0

## strings -tx -a libc-2.20.i686.gentoo.20150915.so | grep 'GNU C Library'
# 15cce0 GNU C Library (Gentoo 2.20-r2 p5) stable release version 2.20, by Roland McGrath et al.

# 改造後
## ./dump local-137378b2dafc659ed379697ba1296f1c54d0dfed
#offset___libc_start_main_ret = 0x19943
#offset_system = 0x0003dc70
#offset_dup2 = 0x000db1a0
#offset_read = 0x000da860
#offset_write = 0x000da8e0
#offset_execl = 0x000b6320
#offset_execv = 0x000b6180
#offset_mprotect = 0x000e6170
#offset_mmap = 0x000e6060
#offset_str_bin_sh = 0x159493
#offset_one_gadget_rce = 0x3db21

