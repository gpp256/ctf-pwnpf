Assembly Template Code for Code Generation
============================================

```
+ execcmd_aarch64.s 
  as -o execcmd_aarch64.o execcmd_aarch64.s ;ld -o execcmd_aarch64 execcmd_aarch64.o; strace ./execcmd_aarch64
  as -o execcmd_aarch64.o execcmd_aarch64.s ; objcopy -O binary execcmd_aarch64.o execcmd_aarch64.bin ; objdump -b binary -m aarch64 -D execcmd_aarch64.bin

+ execcmd_arm.s 
  as -mthumb -o execcmd_arm.o execcmd_arm.s ;ld -o execcmd_arm execcmd_arm.o; strace ./execcmd_arm | strings
  as -mthumb -o execcmd_arm.o execcmd_arm.s ; objcopy -O binary execcmd_arm.o execcmd_arm.bin ; objdump -b binary -m arm -M force-thumb -D execcmd_arm.bin

+ execcmd_x86-64.s
  nasm -o execcmd_x86-64.o execcmd_x86-64.s ; objdump -b binary -m i386:x86-64 -D execcmd_x86-64.o

+ execve_aarch64.s <==
  as -o execve_aarch64.o execve_aarch64.s ;ld -o execve_aarch64 execve_aarch64.o; strace ./execve_aarch64
  as -o execve_aarch64.o execve_aarch64.s ; objcopy -O binary execve_aarch64.o execve_aarch64.bin ; objdump -b binary -m aarch64 -D execve_aarch64.bin

+ execve_arm.s
  as -o execve_arm execve_arm.s; objcopy -O binary execve_arm execve_arm.o
  objdump -b binary -m arm -D execve_arm.o

+ execve_ppc.s
  as -o execve_ppc.o execve_ppc.s ;ld -o execve_ppc execve_ppc.o; strace ./execve_ppc | strings
  as -o execve_ppc.o execve_ppc.s ;objcopy -O binary execve_ppc.o execve_ppc.bin ; objdump -b binary -m powerpc -D execve_ppc.bin

+ execve_s390.s
  as -o execve_s390.o execve_s390.s ;ld -o execve_s390 execve_s390.o; strace64 ./execve_s390
  as -o execve_s390.o execve_s390.s ; objcopy -O binary execve_s390.o execve_s390.bin ; objdump -b binary -m s390 -D execve_s390.bin

+ execve_x86-64.s 
  nasm -f elf64 -o tp.o tp.s; ld -o tp tp.o

+ execve_x86.s
  as --32 -o execve_x86.o execve_x86.s ; objcopy -O binary execve_x86.o execve_x86.bin ; objdump -b binary -m i386 -D execve_x86.bin

+ fork_and_execve.s 
  as  -o tp.o tp.s ; objcopy -O binary tp.o tp.bin ; objdump -b binary -m i386 -D tp.bin | /opt/ctf/tools/akitools/disastobin > input

+ fork_and_readdir.s 
  nasm -o fork_and_readdir.o fork_and_readdir.s ; objdump -b binary -m i386:x86-64 -D fork_and_readdir.o | /opt/ctf/tools/akitools/disastobin > input

+ fork_and_readfile.s
  nasm -o fork_and_readfile.o fork_and_readfile.s ; objdump -b binary -m i386:x86-64 -D fork_and_readfile.o | /opt/ctf/tools/akitools/disastobin > input

+ readdir_aarch64.s
  as -o readdir_aarch64.o readdir_aarch64.s ;ld -o readdir_aarch64 readdir_aarch64.o; strace ./readdir_aarch64
  as -o readdir_aarch64.o readdir_aarch64.s ; objcopy -O binary readdir_aarch64.o readdir_aarch64.bin ; objdump -b binary -m aarch64 -D readdir_aarch64.bin

+ readdir_arm.s 
  as -mthumb -o readdir_arm.o readdir_arm.s ;ld -o readdir_arm readdir_arm.o; strace ./readdir_arm | strings
  as -mthumb -o readdir_arm.o readdir_arm.s ; objcopy -O binary readdir_arm.o readdir_arm.bin ; objdump -b binary -m arm -M force-thumb -D readdir_arm.bin

+ readdir_mips.s 
  as -o readdir_mips.o readdir_mips.s ;ld -o readdir_mips readdir_mips.o; strace ./readdir_mips
  as -o readdir_mips.o readdir_mips.s ; objcopy -O binary readdir_mips.o readdir_mips.bin ; objdump -b binary -m mips -D readdir_mips.bin

+ readdir_s390.s 
  as -o readdir_s390.o readdir_s390.s ;ld -o readdir_s390 readdir_s390.o;  ./readdir_s390 | strings
  as -o readdir_s390.o readdir_s390.s ; objcopy -O binary readdir_s390.o readdir_s390.bin ; objdump -b binary -m s390 -D readdir_s390.bin

+ readdir_sh4.s 
  as -o readdir_sh4.o readdir_sh4.s ;ld -o readdir_sh4 readdir_sh4.o; strace ./readdir_sh4
  as -o readdir_sh4.o readdir_sh4.s ; objcopy -O binary readdir_sh4.o readdir_sh4.bin ; objdump -b binary -m sh4 -D readdir_sh4.bin

+ readdir_x86-64.s 
  nasm -o readdir_x86-64.o readdir_x86-64.s ; objdump -b binary -m i386:x86-64 -D readdir_x86-64.o

+ readfile_aarch64.s 
  as -o readfile_aarch64.o readfile_aarch64.s ;ld -o readfile_aarch64 readfile_aarch64.o; strace ./readfile_aarch64

+ readfile_arm.s
  as -mthumb -o readfile_arm.o readfile_arm.s ;ld -o readfile_arm readfile_arm.o;  ./readfile_arm | strings
  as -mthumb -o readfile_arm.o readfile_arm.s ; objcopy -O binary readfile_arm.o readfile_arm.bin ; objdump -b binary -m arm -M force-thumb -D readfile_arm.bin

+ readfile_mips.s 
  as -o readfile_mips.o readfile_mips.s ;ld -o readfile_mips readfile_mips.o; strace ./readfile_mips
  as -o readfile_mips.o readfile_mips.s ; objcopy -O binary readfile_mips.o readfile_mips.bin ; objdump -b binary -m mips -D readfile_mips.bin

+ readfile_s390.s
  as -o readfile_s390.o readfile_s390.s ;ld -o readfile_s390 readfile_s390.o;  ./readfile_s390 | strings
  as -o readfile_s390.o readfile_s390.s ; objcopy -O binary readfile_s390.o readfile_s390.bin ; objdump -b binary -m s390 -D readfile_s390.bin

+ readfile_sh4.s 
  as -o readfile_sh4.o readfile_sh4.s ;ld -o readfile_sh4 readfile_sh4.o; strace ./readfile_sh4
  as -o readfile_sh4.o readfile_sh4.s ; objcopy -O binary readfile_sh4.o readfile_sh4.bin ; objdump -b binary -m sh4 -D readfile_sh4.bin

+ stager_arm.s 
  as -mthumb -o stager_arm.o stager_arm.s ;ld -o stager_arm stager_arm.o; strace ./stager_arm | strings
  as -mthumb -o stager_arm.o stager_arm.s ; objcopy -O binary stager_arm.o stager_arm.bin ; objdump -b binary -m arm -M force-thumb -D stager_arm.bin

+ stager_x86-64.s 
  nasm -o stager_x86-64.o stager_x86-64.s ; objdump -b binary -m i386:x86-64 -D stager_x86-64.o

+ write_ppc.s 
  as -o write_ppc.o write_ppc.s ;ld -o write_ppc write_ppc.o; strace ./write_ppc | strings
  as -o write_ppc.o write_ppc.s ;objcopy -O binary write_ppc.o write_ppc.bin ; objdump -b binary -m powerpc -D write_ppc.bin
```

## License

MIT
