#
# PoliCTF2017 - Pong (lvl 1) 509
#
# Copyright (c) 2014-2019 gpp256
# This software is distributed under the MIT License.

use pwntools;
use Time::HiRes qw (usleep);
$timeout=300;

&connect(\$s, 'localhost', 5000) or die "ng";
$buf = "Lv1\n"; syswrite($s, $buf, length($buf));
$data = &read_until($s, qr/From\sforked\schild\n/, $timeout);
$data =~ /OK\s(\d+)\D/ && do { $port = $1; };
close($s);
printf("[+] udp/$port\n");

$addr = &get_udpsocket(\$s, 'localhost', $port) or die "ng";
map { $buf = "-1|-1\n"; send($s, $buf, 0, $addr); } (0..2);

while(1) {
recv($s, $data, 20, 0);
next if ($data !~ /\d\|\d/);
print "[+] recv: $data\n";
$data =~ /(\d+)\|\d+\|\d+\|(\d+)\|(\d)\|\d/ && do {
$p1y = $1; $by = $2; $end = $3;
};
last if (int($end) >0);
printf("[+] p1y=$p1y, bally=$by\n");
$buf = (int($p1y)>int($by)) ?  "1|0" : "0|1";
$delta = abs($p1y-$by)/10-1;
map { send($s, $buf, 0, $addr);  } (0..$delta);
}
__END__
