/* 親プロセスで有効化したseccompのルールは、子プロセスでも有効 */
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <seccomp.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/syscall.h>

// execve(2)
static unsigned char *sc1 = "\x31\xc0\x99\x48\xbb\x2f\x2f\x62\x69\x6e\x2f\x73\x68\x48\xc1\xeb\x08\x53\x48\x89\xe7\x50\x57\x48\x89\xe6\xb0\x3b\x0f\x05";
// open(2), read(2), write(2)
static unsigned char *sc2 = "\x31\xDB\xF7\xE3\xEB\x26\x5B\xB0\x05\x31\xC9\xCD\x80\x89\xC6\x89\xF3\xB0\x03\x54\x59\xB2\x01\xCD\x80\x31\xDB\x39\xC3\x75\x03\x40\xCD\x80\xB0\x04\xB3\x01\xB2\x01\xCD\x80\xEB\xE3\xE8\xD5\xFF\xFF\xFF./flag\x00";
static pid_t pp_id = 0;
static int enable_seccomp() ;

int main(int argc, char *argv[]) {
	int pid, code, status;
	pid_t result;
	enable_seccomp();
	//pid = fork(); // clone(2)
	pid = syscall(SYS_fork); 
	if(pid == -1){ write(2, "ng\n", 3); return 1; }
	if(pid == 0) { // child process
		char a[256] = {0};
		int fd = open("flag", 0);
		if (fd<0) { 
		perror("open");
		} else {
		read(fd, &a, 256); 
		write(1, "child: ", 7);
		write(1, &a, 256);
		close(fd);
		}
	} else { // parent process
#if 0
		char a[256] = {0};
		int fd = open("flag", 0);
		if (fd<0) { 
		perror("open");
		} else {
		read(fd, &a, 256); 
		write(1, "parent: ", 7);
		write(1, &a, 256);
		close(fd);
		}
#endif
		result = wait4(pid, &status, 0, 0);
#if 0
		char *arg[2] = {"ls", 0};
		execve("/bin/ls", arg, 0);
  		//((void (*)(void))sc)();
#endif
	}
	return 0;
}

static int enable_seccomp() {
	int rc;
	scmp_filter_ctx ctx = NULL;
	ctx = seccomp_init(SCMP_ACT_KILL);
	if (ctx == NULL) return ENOMEM;
	
	rc = seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(fork), 0);
	if (rc != 0) { perror("seccomp_rule_add_exact"); goto out; }
#if 0
	rc = seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(open), 0);
	if (rc != 0) { perror("seccomp_rule_add_exact"); goto out; }
#endif
	rc = seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(read), 0);
	if (rc != 0) { perror("seccomp_rule_add_exact"); goto out; }
	rc = seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(write), 0);
	if (rc != 0) { perror("seccomp_rule_add_exact"); goto out; }
	rc = seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(close), 0);
	if (rc != 0) { perror("seccomp_rule_add_exact"); goto out; }
	rc = seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(wait4), 0);
	if (rc != 0) { perror("seccomp_rule_add_exact"); goto out; }
	rc = seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(exit_group), 0);
	if (rc != 0) { perror("seccomp_rule_add_exact"); goto out; }
	rc = seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(rt_sigreturn), 0);
	if (rc != 0) { perror("seccomp_rule_add_exact"); goto out; }
	if (seccomp_load(ctx)) { perror("seccomp_load"); goto out; }
	return rc;
out:
	seccomp_release(ctx);
	return (rc < 0)? -rc : rc;
}
/*
open(2)を許可している場合
$ seccomp-tools dump ./tp01
 line  CODE  JT   JF      K
=================================
 0000: 0x20 0x00 0x00 0x00000004  A = arch
 0001: 0x15 0x00 0x0b 0xc000003e  if (A != ARCH_X86_64) goto 0013
 0002: 0x20 0x00 0x00 0x00000000  A = sys_number
 0003: 0x35 0x09 0x00 0x40000000  if (A >= 0x40000000) goto 0013
 0004: 0x15 0x07 0x00 0x00000000  if (A == read) goto 0012
 0005: 0x15 0x06 0x00 0x00000001  if (A == write) goto 0012
 0006: 0x15 0x05 0x00 0x00000002  if (A == open) goto 0012
 0007: 0x15 0x04 0x00 0x00000003  if (A == close) goto 0012
 0008: 0x15 0x03 0x00 0x0000000f  if (A == rt_sigreturn) goto 0012
 0009: 0x15 0x02 0x00 0x00000039  if (A == fork) goto 0012
 0010: 0x15 0x01 0x00 0x0000003d  if (A == wait4) goto 0012
 0011: 0x15 0x00 0x01 0x000000e7  if (A != exit_group) goto 0013
 0012: 0x06 0x00 0x00 0x7fff0000  return ALLOW
 0013: 0x06 0x00 0x00 0x00000000  return KILL
$ ./tp01
child: FLAG_GGGGGGGGGGGGGGGG

open(2)を許可していない場合
$ seccomp-tools dump ./tp01
 line  CODE  JT   JF      K
=================================
 0000: 0x20 0x00 0x00 0x00000004  A = arch
 0001: 0x15 0x00 0x0a 0xc000003e  if (A != ARCH_X86_64) goto 0012
 0002: 0x20 0x00 0x00 0x00000000  A = sys_number
 0003: 0x35 0x08 0x00 0x40000000  if (A >= 0x40000000) goto 0012
 0004: 0x15 0x06 0x00 0x00000000  if (A == read) goto 0011
 0005: 0x15 0x05 0x00 0x00000001  if (A == write) goto 0011
 0006: 0x15 0x04 0x00 0x00000003  if (A == close) goto 0011
 0007: 0x15 0x03 0x00 0x0000000f  if (A == rt_sigreturn) goto 0011
 0008: 0x15 0x02 0x00 0x00000039  if (A == fork) goto 0011
 0009: 0x15 0x01 0x00 0x0000003d  if (A == wait4) goto 0011
 0010: 0x15 0x00 0x01 0x000000e7  if (A != exit_group) goto 0012
 0011: 0x06 0x00 0x00 0x7fff0000  return ALLOW
 0012: 0x06 0x00 0x00 0x00000000  return KILL
$ ./tp01
間違ったシステムコール
$ strace -f ./tp01
prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0)  = 0
prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER, {len = 13, filter = 0x6042a0}) = 0
fork(strace: Process 27127 attached
)                                  = 27127
[pid 27126] wait4(27127,  <unfinished ...>
[pid 27127] +++ killed by SIGSYS +++ ★
<... wait4 resumed> [{WIFSIGNALED(s) && WTERMSIG(s) == SIGSYS}], 0, NULL) = 27127
--- SIGCHLD {si_signo=SIGCHLD, si_code=CLD_KILLED, si_pid=27127, si_uid=0, si_status=SIGSYS, si_utime=0, si_stime=0} ---
exit_group(0)                           = ?
*/
