/* prctl(2), seccomp(2)でもシステムコールの利用制限は可能(より細かい制御が可能) */
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <linux/seccomp.h>
#include <linux/filter.h>
#include <linux/audit.h>
#include <sys/syscall.h>
#include <sys/prctl.h>

// execve(2)
static unsigned char *sc1 = "\x31\xc0\x99\x48\xbb\x2f\x2f\x62\x69\x6e\x2f\x73\x68\x48\xc1\xeb\x08\x53\x48\x89\xe7\x50\x57\x48\x89\xe6\xb0\x3b\x0f\x05";
// open(2), read(2), write(2)
static unsigned char *sc2 = "\x31\xDB\xF7\xE3\xEB\x26\x5B\xB0\x05\x31\xC9\xCD\x80\x89\xC6\x89\xF3\xB0\x03\x54\x59\xB2\x01\xCD\x80\x31\xDB\x39\xC3\x75\x03\x40\xCD\x80\xB0\x04\xB3\x01\xB2\x01\xCD\x80\xEB\xE3\xE8\xD5\xFF\xFF\xFF./flag\x00";
static pid_t pp_id = 0;
static int enable_seccomp() ;

int main(int argc, char *argv[]) {
	int pid, code, status;
	pid_t result;
	//pid = fork(); // clone(2)
	pid = syscall(SYS_fork); 
	if(pid == -1){ write(2, "ng\n", 3); return 1; }
	if(pid == 0) { // child process
		enable_seccomp();
		/* ng */
		char a[256] = {0};
		int fd = open("flag", 0);
		if (fd<0) { 
		perror("open");
		} else {
		read(fd, &a, 256); 
		write(1, "child: ", 7);
		write(1, &a, 256);
		//close(fd);
		}
	} else { // parent process
#if 1
		/* ok */
		char a[256] = {0};
		int fd = open("flag", 0);
		if (fd<0) { 
		perror("open");
		} else {
		read(fd, &a, 256); 
		write(1, "parent: ", 7);
		write(1, &a, 256);
		close(fd);
		}
#endif
		result = wait4(pid, &status, 0, 0);
#if 0
		char *arg[2] = {"ls", 0};
		execve("/bin/ls", arg, 0);
  		//((void (*)(void))sc)();
#endif
	}
	return 0;
}

static int enable_seccomp() {
	int rc=0;
	struct sock_filter filter[] = {
		// アーキテクチャ情報のロード
		BPF_STMT(BPF_LD | BPF_W | BPF_ABS, (offsetof(struct seccomp_data, arch))),
		// アーキテクチャ情報のチェック(true:1個先へ，false:0個先への意味)
		// アーキテクチャのチェックは必須 
		// チェックが存在しない場合，例えばx86からx64の実行コンテキストにすることでシステムコール番号のチェックすり抜けが起き得る
		BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, AUDIT_ARCH_I386, 1, 0),
		BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_KILL),
		// システムコール番号のロード
		BPF_STMT(BPF_LD | BPF_W | BPF_ABS, (offsetof(struct seccomp_data, nr))),
		// システムコール番号のチェック
#if 0
		BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, __NR_open, 0, 1),
		BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
#endif
		BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, __NR_read, 0, 1),
		BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
		BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, __NR_write, 0, 1),
		BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
		BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, __NR_exit, 0, 1),
		BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
		BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_KILL),
	};
	struct sock_fprog prog = {
	.len = (unsigned short) (sizeof(filter) / sizeof(filter[0])),
	.filter = filter,
	};
	if (prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0)) {
		perror("prctl(NO_NEW_PRIVS)"); rc=1; goto out;
	}
#if 1
	if (prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER, &prog, 0, 0)) {
		perror("prctl(SECCOMP)"); rc=2;
	}
#else
	if (syscall(__NR_seccomp, SECCOMP_SET_MODE_FILTER,0, &prog)) {
		perror("seccomp"); rc=3;
	}
#endif
out:
	return rc;
}

/*
$ seccomp-tools dump ./tp03
 line  CODE  JT   JF      K
=================================
 0000: 0x20 0x00 0x00 0x00000004  A = arch
 0001: 0x15 0x01 0x00 0x40000003  if (A == ARCH_I386) goto 0003
 0002: 0x06 0x00 0x00 0x00000000  return KILL
 0003: 0x20 0x00 0x00 0x00000000  A = sys_number
 0004: 0x15 0x00 0x01 0x00000003  if (A != read) goto 0006
 0005: 0x06 0x00 0x00 0x7fff0000  return ALLOW
 0006: 0x15 0x00 0x01 0x00000004  if (A != write) goto 0008
 0007: 0x06 0x00 0x00 0x7fff0000  return ALLOW
 0008: 0x15 0x00 0x01 0x00000001  if (A != exit) goto 0010
 0009: 0x06 0x00 0x00 0x7fff0000  return ALLOW
 0010: 0x06 0x00 0x00 0x00000000  return KILL

$ ./tp03
parent:FLAG_GGGGGGGGGGGGGGGG

*/
