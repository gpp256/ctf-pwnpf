#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <seccomp.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/syscall.h>

// execve(2)
static unsigned char *sc = "\x31\xc0\x99\x48\xbb\x2f\x2f\x62\x69\x6e\x2f\x73\x68\x48\xc1\xeb\x08\x53\x48\x89\xe7\x50\x57\x48\x89\xe6\xb0\x3b\x0f\x05";
static pid_t pp_id = 0;

int main(int argc, char *argv[]) {
        int rc;
        scmp_filter_ctx ctx = NULL;
        ctx = seccomp_init(SCMP_ACT_KILL);
        if (ctx == NULL) return ENOMEM;

        //rc = seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(read), 1, SCMP_A0(SCMP_CMP_EQ, STDIN_FILENO));
        //if (rc != 0) goto out;
        rc = seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(write), 1, SCMP_A0(SCMP_CMP_EQ, STDOUT_FILENO));
        if (rc != 0) goto out;
        rc = seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(write), 1, SCMP_A0(SCMP_CMP_EQ, STDERR_FILENO));
        if (rc != 0) goto out;
        rc = seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(read), 0);
        if (rc != 0) goto out;
        rc = seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(close), 0);
        if (rc != 0) goto out;
        rc = seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(kill), 0);
        if (rc != 0) goto out;
        rc = seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(getppid), 0);
        if (rc != 0) goto out;
        rc = seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(nanosleep), 0);
        if (rc != 0) goto out;
        rc = seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(exit_group), 0);
        if (rc != 0) goto out;
        rc = seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(fork), 0);
        if (rc != 0) goto out;
        rc = seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(clone), 0);
        if (rc != 0) goto out;
        rc = seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(wait4), 0);
        if (rc != 0) goto out;
        rc = seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(rt_sigreturn), 0);
        if (rc != 0) goto out;
        rc = seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(seccomp), 0);
        if (rc != 0) goto out;
        rc = seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(prctl), 0);
        if (rc != 0) goto out;
        rc = seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(openat), 0);
        if (rc != 0) goto out;
	if (seccomp_load(ctx)) { perror("seccomp_load"); goto out; }

	char a[256] = {0};
	pp_id = getppid();
#if 0
	/* ng */
	int fd = open("flag", 0);
	read(fd, &a, 256); 
	write(1, &a, 256);
	close(fd);
#endif
#if 0
	/* ok */
	read(0, &a, 255); 
	write(1, &a, 255);
#endif
#if 0
	/* ng */
	char *arg[2] = {"ls", 0};
	execve("/bin/ls", arg, 0);
  	//((void (*)(void))sc)();
#endif

#if 1
	{
		int pid, code, status;
		pid_t result;
		//clone(strace: Process 30057 attached
		//[pid 30056] wait4(-1,  <unfinished ...>

		//pid = fork(); // clone(2)
		pid = syscall(SYS_fork); 
		if(pid == -1){ write(2, "ng\n", 3); goto out; }

		//if (pid!=0) goto out; // 終了処理へ

		if(pid == 0){
		write(1, "child\n", 6);
#if 0
		//char *arg[2] = {"ls", 0};
		//execve("/bin/ls", arg, 0);
		//[pid 30387] execve(0x400e62, 0x7ffde4fe4c40, 0, 0x7f4c59caa290 <no return ...>
		//[pid 30387] +++ killed by SIGSYS +++
  		//((void (*)(void))sc)();
#endif
#if 0
		int pid2 = fork();
		if(pid2 == -1){ write(2, "ng\n", 3); return(2); }
		if(pid2 == 0){
		char *arg[2] = {"ls", 0};
		execve("/bin/ls", arg, 0);
		} else {
		result = wait4(pid2, &status, 0, 0);
		}
#endif
#if 1
		int pid2;
		if ((pid2 = fork()) != 0) {
			// 2回目のロードはうまくいかない
			//seccomp_reset(ctx, SCMP_ACT_ALLOW);
			//seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(open), 0);
			//if (seccomp_load(ctx)) { perror("seccomp_load"); goto out; }
			//seccomp_release(ctx);
			exit(0); // 親プロセス終了
		}
		write(1, "child2\n", 8);

		// 親がいなくなっても解除されない?!
		//char *arg[2] = {"sh", 0};
		//execve("/bin/sh", arg, 0);
		//((void (*)(void))sc)();

		//char a[256] = {0};
		//int fd = open("flag", 0);
		// /usr/include/linux/fcntl.h:#define AT_FDCWD             -100    /* Special value used to indicate

		// openat(2)ですり抜けできることもある
		int fd = openat(-100, "flag", 0);
		read(fd, &a, 256); 
		write(1, &a, 256); write(1, "\n", 1);

		exit(0);
#endif
		}

		else {
		result = wait4(pid, &status, 0, 0);
		}

	}
#endif

out:
	// 2回目のロードはうまくいかない
	//seccomp_reset(ctx, SCMP_ACT_ALLOW);
	//seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(open), 0);
	//seccomp_rule_add_exact(ctx, SCMP_ACT_ALLOW, SCMP_SYS(execve), 0);
	//if (seccomp_load(ctx)) { perror("seccomp_load"); goto out; }
        //seccomp_release(ctx);
        //ctx = seccomp_init(SCMP_ACT_ALLOW);
        seccomp_release(ctx);
        return (rc < 0 ? -rc : rc);
}

/*
# ltrace -f ./tp
[pid 29060] __libc_start_main(0x400836, 1, 0x7ffd91b83b98, 0x400b40 <unfinished ...>
[pid 29060] seccomp_init(0, 0x7ffd91b83b98, 0x7ffd91b83ba8, 0)                                                                                                           = 0x12a3010
[pid 29060] seccomp_rule_add_exact(0x12a3010, 0x7fff0000, 0, 1)                                                                                                          = 0
[pid 29060] seccomp_rule_add_exact(0x12a3010, 0x7fff0000, 1, 1)                                                                                                          = 0
[pid 29060] seccomp_rule_add_exact(0x12a3010, 0x7fff0000, 1, 1)                                                                                                          = 0
[pid 29060] seccomp_rule_add_exact(0x12a3010, 0x7fff0000, 3, 0)                                                                                                          = 0
[pid 29060] seccomp_rule_add_exact(0x12a3010, 0x7fff0000, 231, 0)                                                                                                        = 0
[pid 29060] seccomp_rule_add_exact(0x12a3010, 0x7fff0000, 15, 0)                                                                                                         = 0
[pid 29060] seccomp_load(0x12a3010, 0, 0, 7)                                                                                                                             = 0
[pid 29060] +++ killed by SIGSYS +++
*/
