/* bof.c */
#include <stdio.h>
#include <string.h>
#include <stdlib.h> 
#include <unistd.h>
#include <signal.h>

void sigcatch(int);

int main(int argc, char *argv[])
{
    char buf[300] = {};  /* set all bytes to zero */
    if (SIG_ERR == signal(SIGALRM, sigcatch)) {
    printf("failed to set signal handler.\n");
    }
    printf("buf = %p\n", buf);
    fflush(stdout);
    alarm(1);
    fgets(buf, 0x300, stdin);
    alarm(0);
    puts(buf);
    return 0;
}

void sigcatch(int sig) {
printf("NGGGGGGGGGGG! catch SIGALRM and exit.\n");
exit(1);
}
