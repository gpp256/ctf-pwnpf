参考：CTFでよく見かける対解析機能
=====================================

## 対解析機能とその対策sleep(3),nanosleep(2),alarm(2),ptrace(2)

```
+ Pedaのdeactiveコマンドを利用する（nanosleepなどシステムコールは対応できない）★
  例) gdb-peda$ deactive sleep
  Breakpoint 2 at 0x400430
  'sleep' deactivated
+ バイナリエディタhtなどで実行ファイルを編集し、該当処理を0x90(nop)などで埋める★
  alarm/sleepは引数を0にすればよい。
+ コマンドラインからddで実行ファイルを編集し、該当処理を0x90で埋める
  例）アドレス確認
  8048a7b: c7 04 24 1e 00 00 00 mov DWORD PTR [esp],0x1e
  8048a82: e8 69 fb ff ff call 80485f0 <sleep@plt>
  $ dd conv=notrunc if=nops of=codegate2013_pwn400 seek=$((0xa82)) bs=1 count=5
+ gdbを使い、分岐命令直前のcmp/testでbreak pointを設定。setコマンドでレジスタやメモリを値を書き換えて、分岐先を変える★
  例)ptrace(2)を呼んだ後にset $eax = 0

```

## 動作検証

```
e.g.
$ make
$ echo hoge | gdb -q -ex r -ex q ./ptrace
$ echo hoge | gdb -q -ex 'b *0x80485a3' -ex r -ex 'set $eax=0' -ex c -ex q ./ptrace

アドレスは環境に合わせて確認が必要
objdumpなどで逆アセンブルして確認
```
