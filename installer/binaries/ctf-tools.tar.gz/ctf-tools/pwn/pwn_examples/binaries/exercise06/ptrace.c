/* bof.c */
#include <stdio.h>
#include <string.h>
#include <sys/ptrace.h>

int main(int argc, char *argv[])
{
    char buf[300] = {};  /* set all bytes to zero */
    printf("buf = %p\n", buf);
    fflush(stdout);
    if (ptrace(PTRACE_TRACEME, 0, 1, 0) == -1) {
        printf("NGGGGGGGGGGGGGGGGG!\n");
        return 1;
    }
    fgets(buf, 0x300, stdin);
    puts(buf);
    return 0;
}
