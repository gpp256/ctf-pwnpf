/* bof.c */
#include <stdio.h>
#include <sys/time.h>
#include <string.h>
#define MILLI_SEC 1000

int main(int argc, char *argv[])
{
    char buf[300] = {};  /* set all bytes to zero */
    struct timespec req = {1000, 500*MILLI_SEC};
    printf("buf = %p\n", buf);
    fflush(stdout);
    nanosleep(&req, NULL);
    fgets(buf, 0x300, stdin);
    puts(buf);
    return 0;
}
