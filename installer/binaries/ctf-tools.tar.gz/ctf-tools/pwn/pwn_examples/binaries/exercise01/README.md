参考：ソースコードとアセンブリコード
==========================================

## 動作検証
```
次のコマンドで逆アセンブルした結果を見てみましょう

objdump –d –Mintel test

次のコマンドで関数呼び出し時のスタックの状態を見てみましょう

gdb -q test -ex 'b my_func' -ex r -ex q

すべて読む必要はありません。読み飛ばしのコツを以下に記載します

```

## 読み飛ばしについて

```
!!!シンボル情報なしの場合のバイナリ解析法（初動調査編）

対象は ELF 32/64-bit LSB executable。知っているとPwn/Reversing系の問題を解くときに効率アップできる。


!!見なくてよいところはブロック単位で押さえる

完全に覚える必要はない。形で見分けがつく程度でよい。

シンボル情報ありの場合で確認し、以下をさっと読み飛ばす。

慣れるまでは並べて見比べてもよい

■x86
0804847c <_init>:
 804847c:	55                   	push   ebp
 804847d:	89 e5                	mov    ebp,esp
 804847f:	53                   	push   ebx
 8048480:	83 ec 04             	sub    esp,0x4
 8048483:	e8 00 00 00 00       	call   8048488 <_init+0xc>
 8048488:	5b                   	pop    ebx
 8048489:	81 c3 94 16 00 00    	add    ebx,0x1694
 804848f:	8b 93 fc ff ff ff    	mov    edx,DWORD PTR [ebx-0x4]
 8048495:	85 d2                	test   edx,edx
 8048497:	74 05                	je     804849e <_init+0x22>
 8048499:	e8 92 00 00 00       	call   8048530 <__gmon_start__@plt>
 804849e:	58                   	pop    eax
 804849f:	5b                   	pop    ebx
 80484a0:	c9                   	leave  
 80484a1:	c3                   	ret    

080485b0 <deregister_tm_clones>:
 80485b0:	b8 63 9b 04 08       	mov    eax,0x8049b63
 80485b5:	2d 60 9b 04 08       	sub    eax,0x8049b60
 80485ba:	83 f8 06             	cmp    eax,0x6
 80485bd:	77 02                	ja     80485c1 <deregister_tm_clones+0x11>
 80485bf:	f3 c3                	repz ret 
 80485c1:	b8 00 00 00 00       	mov    eax,0x0
 80485c6:	85 c0                	test   eax,eax
 80485c8:	74 f5                	je     80485bf <deregister_tm_clones+0xf>
 80485ca:	55                   	push   ebp
 80485cb:	89 e5                	mov    ebp,esp
 80485cd:	83 ec 18             	sub    esp,0x18
 80485d0:	c7 04 24 60 9b 04 08 	mov    DWORD PTR [esp],0x8049b60
 80485d7:	ff d0                	call   eax
 80485d9:	c9                   	leave  
 80485da:	c3                   	ret    
 80485db:	90                   	nop
 80485dc:	8d 74 26 00          	lea    esi,[esi+eiz*1+0x0]

080485e0 <register_tm_clones>:
 80485e0:	b8 60 9b 04 08       	mov    eax,0x8049b60
 80485e5:	2d 60 9b 04 08       	sub    eax,0x8049b60
 80485ea:	c1 f8 02             	sar    eax,0x2
 80485ed:	89 c2                	mov    edx,eax
 80485ef:	c1 ea 1f             	shr    edx,0x1f
 80485f2:	01 d0                	add    eax,edx
 80485f4:	d1 f8                	sar    eax,1
 80485f6:	75 02                	jne    80485fa <register_tm_clones+0x1a>
 80485f8:	f3 c3                	repz ret 
 80485fa:	ba 00 00 00 00       	mov    edx,0x0
 80485ff:	85 d2                	test   edx,edx
 8048601:	74 f5                	je     80485f8 <register_tm_clones+0x18>
 8048603:	55                   	push   ebp
 8048604:	89 e5                	mov    ebp,esp
 8048606:	83 ec 18             	sub    esp,0x18
 8048609:	89 44 24 04          	mov    DWORD PTR [esp+0x4],eax
 804860d:	c7 04 24 60 9b 04 08 	mov    DWORD PTR [esp],0x8049b60
 8048614:	ff d2                	call   edx
 8048616:	c9                   	leave  
 8048617:	c3                   	ret    
 8048618:	90                   	nop
 8048619:	8d b4 26 00 00 00 00 	lea    esi,[esi+eiz*1+0x0]

08048620 <__do_global_dtors_aux>:
 8048620:	80 3d 84 9b 04 08 00 	cmp    BYTE PTR ds:0x8049b84,0x0
 8048627:	75 13                	jne    804863c <__do_global_dtors_aux+0x1c>
 8048629:	55                   	push   ebp
 804862a:	89 e5                	mov    ebp,esp
 804862c:	83 ec 08             	sub    esp,0x8
 804862f:	e8 7c ff ff ff       	call   80485b0 <deregister_tm_clones>
 8048634:	c6 05 84 9b 04 08 01 	mov    BYTE PTR ds:0x8049b84,0x1
 804863b:	c9                   	leave  
 804863c:	f3 c3                	repz ret 
 804863e:	66 90                	xchg   ax,ax

08048640 <frame_dummy>:
 8048640:	a1 24 9a 04 08       	mov    eax,ds:0x8049a24
 8048645:	85 c0                	test   eax,eax
 8048647:	74 1e                	je     8048667 <frame_dummy+0x27>
 8048649:	b8 00 00 00 00       	mov    eax,0x0
 804864e:	85 c0                	test   eax,eax
 8048650:	74 15                	je     8048667 <frame_dummy+0x27>
 8048652:	55                   	push   ebp
 8048653:	89 e5                	mov    ebp,esp
 8048655:	83 ec 18             	sub    esp,0x18
 8048658:	c7 04 24 24 9a 04 08 	mov    DWORD PTR [esp],0x8049a24
 804865f:	ff d0                	call   eax
 8048661:	c9                   	leave  
 8048662:	e9 79 ff ff ff       	jmp    80485e0 <register_tm_clones>
 8048667:	e9 74 ff ff ff       	jmp    80485e0 <register_tm_clones>

08048880 <__libc_csu_init>:
 8048880:	55                   	push   ebp
 8048881:	89 e5                	mov    ebp,esp
 8048883:	57                   	push   edi
 8048884:	56                   	push   esi
 8048885:	53                   	push   ebx
 8048886:	e8 4f 00 00 00       	call   80488da <__i686.get_pc_thunk.bx>
 804888b:	81 c3 91 12 00 00    	add    ebx,0x1291
 8048891:	83 ec 1c             	sub    esp,0x1c
 8048894:	e8 e3 fb ff ff       	call   804847c <_init>
 8048899:	8d bb 04 ff ff ff    	lea    edi,[ebx-0xfc]
 804889f:	8d 83 00 ff ff ff    	lea    eax,[ebx-0x100]
 80488a5:	29 c7                	sub    edi,eax
 80488a7:	c1 ff 02             	sar    edi,0x2
 80488aa:	85 ff                	test   edi,edi
 80488ac:	74 24                	je     80488d2 <__libc_csu_init+0x52>
 80488ae:	31 f6                	xor    esi,esi
 80488b0:	8b 45 10             	mov    eax,DWORD PTR [ebp+0x10]
 80488b3:	89 44 24 08          	mov    DWORD PTR [esp+0x8],eax
 80488b7:	8b 45 0c             	mov    eax,DWORD PTR [ebp+0xc]
 80488ba:	89 44 24 04          	mov    DWORD PTR [esp+0x4],eax
 80488be:	8b 45 08             	mov    eax,DWORD PTR [ebp+0x8]
 80488c1:	89 04 24             	mov    DWORD PTR [esp],eax
 80488c4:	ff 94 b3 00 ff ff ff 	call   DWORD PTR [ebx+esi*4-0x100]
 80488cb:	83 c6 01             	add    esi,0x1
 80488ce:	39 fe                	cmp    esi,edi
 80488d0:	72 de                	jb     80488b0 <__libc_csu_init+0x30>
 80488d2:	83 c4 1c             	add    esp,0x1c
 80488d5:	5b                   	pop    ebx
 80488d6:	5e                   	pop    esi
 80488d7:	5f                   	pop    edi
 80488d8:	5d                   	pop    ebp
 80488d9:	c3                   	ret    

080488e0 <_fini>:
 80488e0:	55                   	push   ebp
 80488e1:	89 e5                	mov    ebp,esp
 80488e3:	53                   	push   ebx
 80488e4:	83 ec 04             	sub    esp,0x4
 80488e7:	e8 00 00 00 00       	call   80488ec <_fini+0xc>
 80488ec:	5b                   	pop    ebx
 80488ed:	81 c3 30 12 00 00    	add    ebx,0x1230
 80488f3:	59                   	pop    ecx
 80488f4:	5b                   	pop    ebx
 80488f5:	c9                   	leave  
 80488f6:	c3                   	ret    

■x86-64

00000000004004b0 <_init>:
  4004b0:	48 83 ec 08          	sub    rsp,0x8
  4004b4:	48 8b 05 7d 06 20 00 	mov    rax,QWORD PTR [rip+0x20067d]        # 600b38 <_DYNAMIC+0x1d0>
  4004bb:	48 85 c0             	test   rax,rax
  4004be:	74 05                	je     4004c5 <_init+0x15>
  4004c0:	e8 7b 00 00 00       	call   400540 <__gmon_start__@plt>
  4004c5:	48 83 c4 08          	add    rsp,0x8
  4004c9:	c3                   	ret    

0000000000400600 <deregister_tm_clones>:
  400600:	b8 a7 0b 60 00       	mov    eax,0x600ba7
  400605:	55                   	push   rbp
  400606:	48 2d a0 0b 60 00    	sub    rax,0x600ba0
  40060c:	48 83 f8 0e          	cmp    rax,0xe
  400610:	48 89 e5             	mov    rbp,rsp
  400613:	76 1b                	jbe    400630 <deregister_tm_clones+0x30>
  400615:	b8 00 00 00 00       	mov    eax,0x0
  40061a:	48 85 c0             	test   rax,rax
  40061d:	74 11                	je     400630 <deregister_tm_clones+0x30>
  40061f:	5d                   	pop    rbp
  400620:	bf a0 0b 60 00       	mov    edi,0x600ba0
  400625:	ff e0                	jmp    rax
  400627:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
  40062e:	00 00 
  400630:	5d                   	pop    rbp
  400631:	c3                   	ret    
  400632:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]
  400636:	66 2e 0f 1f 84 00 00 	nop    WORD PTR cs:[rax+rax*1+0x0]
  40063d:	00 00 00 

0000000000400640 <register_tm_clones>:
  400640:	be a0 0b 60 00       	mov    esi,0x600ba0
  400645:	55                   	push   rbp
  400646:	48 81 ee a0 0b 60 00 	sub    rsi,0x600ba0
  40064d:	48 c1 fe 03          	sar    rsi,0x3
  400651:	48 89 e5             	mov    rbp,rsp
  400654:	48 89 f0             	mov    rax,rsi
  400657:	48 c1 e8 3f          	shr    rax,0x3f
  40065b:	48 01 c6             	add    rsi,rax
  40065e:	48 d1 fe             	sar    rsi,1
  400661:	74 15                	je     400678 <register_tm_clones+0x38>
  400663:	b8 00 00 00 00       	mov    eax,0x0
  400668:	48 85 c0             	test   rax,rax
  40066b:	74 0b                	je     400678 <register_tm_clones+0x38>
  40066d:	5d                   	pop    rbp
  40066e:	bf a0 0b 60 00       	mov    edi,0x600ba0
  400673:	ff e0                	jmp    rax
  400675:	0f 1f 00             	nop    DWORD PTR [rax]
  400678:	5d                   	pop    rbp
  400679:	c3                   	ret    
  40067a:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]

0000000000400680 <__do_global_dtors_aux>:
  400680:	80 3d 19 05 20 00 00 	cmp    BYTE PTR [rip+0x200519],0x0        # 600ba0 <__TMC_END__>
  400687:	75 11                	jne    40069a <__do_global_dtors_aux+0x1a>
  400689:	55                   	push   rbp
  40068a:	48 89 e5             	mov    rbp,rsp
  40068d:	e8 6e ff ff ff       	call   400600 <deregister_tm_clones>
  400692:	5d                   	pop    rbp
  400693:	c6 05 06 05 20 00 01 	mov    BYTE PTR [rip+0x200506],0x1        # 600ba0 <__TMC_END__>
  40069a:	f3 c3                	repz ret 
  40069c:	0f 1f 40 00          	nop    DWORD PTR [rax+0x0]

00000000004006a0 <frame_dummy>:
  4006a0:	bf 60 09 60 00       	mov    edi,0x600960
  4006a5:	48 83 3f 00          	cmp    QWORD PTR [rdi],0x0
  4006a9:	75 05                	jne    4006b0 <frame_dummy+0x10>
  4006ab:	eb 93                	jmp    400640 <register_tm_clones>
  4006ad:	0f 1f 00             	nop    DWORD PTR [rax]
  4006b0:	b8 00 00 00 00       	mov    eax,0x0
  4006b5:	48 85 c0             	test   rax,rax
  4006b8:	74 f1                	je     4006ab <frame_dummy+0xb>
  4006ba:	55                   	push   rbp
  4006bb:	48 89 e5             	mov    rbp,rsp
  4006be:	ff d0                	call   rax
  4006c0:	5d                   	pop    rbp
  4006c1:	e9 7a ff ff ff       	jmp    400640 <register_tm_clones>
  4006c6:	66 2e 0f 1f 84 00 00 	nop    WORD PTR cs:[rax+rax*1+0x0]
  4006cd:	00 00 00 

0000000000400760 <__libc_csu_init>:
  400760:	41 57                	push   r15
  400762:	41 89 ff             	mov    r15d,edi
  400765:	41 56                	push   r14
  400767:	49 89 f6             	mov    r14,rsi
  40076a:	41 55                	push   r13
  40076c:	49 89 d5             	mov    r13,rdx
  40076f:	41 54                	push   r12
  400771:	4c 8d 25 d8 01 20 00 	lea    r12,[rip+0x2001d8]        # 600950 <__frame_dummy_init_array_entry>
  400778:	55                   	push   rbp
  400779:	48 8d 2d d8 01 20 00 	lea    rbp,[rip+0x2001d8]        # 600958 <__init_array_end>
  400780:	53                   	push   rbx
  400781:	4c 29 e5             	sub    rbp,r12
  400784:	31 db                	xor    ebx,ebx
  400786:	48 c1 fd 03          	sar    rbp,0x3
  40078a:	48 83 ec 08          	sub    rsp,0x8
  40078e:	e8 1d fd ff ff       	call   4004b0 <_init>
  400793:	48 85 ed             	test   rbp,rbp
  400796:	74 1e                	je     4007b6 <__libc_csu_init+0x56>
  400798:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
  40079f:	00 
  4007a0:	4c 89 ea             	mov    rdx,r13
  4007a3:	4c 89 f6             	mov    rsi,r14
  4007a6:	44 89 ff             	mov    edi,r15d★rdiに任意の値4byteを格納できる。任意関数を呼びたい場合に使うことがある
  4007a9:	41 ff 14 dc          	call   QWORD PTR [r12+rbx*8]
  4007ad:	48 83 c3 01          	add    rbx,0x1
  4007b1:	48 39 eb             	cmp    rbx,rbp
  4007b4:	75 ea                	jne    4007a0 <__libc_csu_init+0x40>
  4007b6:	48 83 c4 08          	add    rsp,0x8
  4007ba:	5b                   	pop    rbx★上の星印の部分とセットで使う
  4007bb:	5d                   	pop    rbp
  4007bc:	41 5c                	pop    r12
  4007be:	41 5d                	pop    r13
  4007c0:	41 5e                	pop    r14
  4007c2:	41 5f                	pop    r15
  4007c4:	c3                   	ret    
  4007c5:	90                   	nop
  4007c6:	66 2e 0f 1f 84 00 00 	nop    WORD PTR cs:[rax+rax*1+0x0]
  4007cd:	00 00 00 

00000000004007d4 <_fini>:
  4007d4:	48 83 ec 08          	sub    rsp,0x8
  4007d8:	48 83 c4 08          	add    rsp,0x8
  4007dc:	c3                   	ret    

見なくてよいところは以外と多い




!!読込み開始ポイントはEntry pointを知らなくても分かる

慣れるとreadelfなどでEntry point addressを確認しなくても一目で分かる。

シンボル情報あり

00000000004005d0 <_start>:
  4005d0:	31 ed                	xor    ebp,ebp
  4005d2:	49 89 d1             	mov    r9,rdx
  4005d5:	5e                   	pop    rsi
  4005d6:	48 89 e2             	mov    rdx,rsp
  4005d9:	48 83 e4 f0          	and    rsp,0xfffffffffffffff0
  4005dd:	50                   	push   rax
  4005de:	54                   	push   rsp
  4005df:	49 c7 c0 d0 07 40 00 	mov    r8,0x4007d0
  4005e6:	48 c7 c1 60 07 40 00 	mov    rcx,0x400760
  4005ed:	48 c7 c7 50 05 40 00 	mov    rdi,0x400550★main()?
  4005f4:	e8 37 ff ff ff       	call   400530 <__libc_start_main@plt>
  4005f9:	f4                   	hlt    
  4005fa:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]

シンボル情報なし

  4005d0:	48 83 ec 08          	sub    rsp,0x8
  4005d4:	e8 47 01 00 00       	call   400720 <execl@plt+0x160>★ここから読み始める
  4005d9:	31 c0                	xor    eax,eax
  4005db:	48 83 c4 08          	add    rsp,0x8
  4005df:	c3                   	ret    
  4005e0:	31 ed                	xor    ebp,ebp
  4005e2:	49 89 d1             	mov    r9,rdx
  4005e5:	5e                   	pop    rsi
  4005e6:	48 89 e2             	mov    rdx,rsp
  4005e9:	48 83 e4 f0          	and    rsp,0xfffffffffffffff0
  4005ed:	50                   	push   rax
  4005ee:	54                   	push   rsp
  4005ef:	49 c7 c0 c0 08 40 00 	mov    r8,0x4008c0
  4005f6:	48 c7 c1 50 08 40 00 	mov    rcx,0x400850
  4005fd:	48 c7 c7 d0 05 40 00 	mov    rdi,0x4005d0★↑第一引数の0x4005d0を参照
  400604:	e8 77 ff ff ff       	call   400580 <__libc_start_main@plt>
  400609:	f4                   	hlt    
  40060a:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]


```
