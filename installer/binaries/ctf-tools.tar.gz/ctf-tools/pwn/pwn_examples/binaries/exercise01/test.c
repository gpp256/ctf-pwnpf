#include <stdio.h>

int my_func(int a, int *b) {
	int x;
	int y;

	x = a;
	y = *b;
	*b = 10;
	b = NULL;

	return x+y;
}

int main() {
	int a;
	int b;
	int c;

	a = 10;
	b = 20;
	c = my_func(a, &b);
	printf("%d\n", c);
	return 0;
}
