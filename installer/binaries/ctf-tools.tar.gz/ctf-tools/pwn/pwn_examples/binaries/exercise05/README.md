BOF Examples
======================

## 動作検証

```
e.g.
$ make
$ cp bof2 bof_${userid}
socatを使い、サーバとして起動。port番号(${port}には適宜空いているポート指定する
$ socat TCP-LISTEN:${port},reuseaddr,fork EXEC:./bof2

別端末で以下を実行し、サーバに接続
$ nc localhost ${port}

更に別端末で以下を実行
$ gdb –q –p `pidof –s ./bof2`

サーバ側でstraceを付けて実行し、コマンドncで長い文字列を送信した場合にどうなるかを確認

$ strace –f socat TCP-LISTEN:${port},reuseaddr,fork EXEC:./bof2

```
