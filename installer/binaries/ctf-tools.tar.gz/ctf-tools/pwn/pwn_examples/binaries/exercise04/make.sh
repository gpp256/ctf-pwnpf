#!/bin/sh
case "$1" in
  build)
	gcc -m32 -o dep test.c
	gcc -m32 -o nodep test.c -z execstack
	gcc -m32 -o ssp test.c -fstack-protector
	gcc -m32 -o nossp test.c -fno-stack-protector
	gcc -m32 -o relro test.c -Wl,-z,relro,-z,now 
	gcc -m32 -o norelro test.c -Wl,-z,norelro
	gcc -m32 -o pie test.c -pie
	gcc -m32 -o nopie test.c 
	;;
  clean)
	rm -f dep nodep ssp nossp relro norelro pie nopie test *.txt;;
  *)    echo "Usage: ./$0 {build|clean}";;
esac

#sysctl kernel.randomize_va_space = 2 ; aslr
#sysctl kernel.randomize_va_space = 0 ; noaslr

