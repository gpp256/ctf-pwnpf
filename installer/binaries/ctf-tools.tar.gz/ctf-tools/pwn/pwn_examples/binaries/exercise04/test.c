#include <stdio.h>

int my_func(int a, int *b) {
	int x;
	int y;

	x = a;
	y = *b;
	*b = 10;
	b = NULL;

	char buf[100];
	printf("%p\n", buf);
	fgets(buf, 0x100, stdin);
	printf("%s\n", buf);

	return x+y;
}

int main() {
	int a;
	int b;
	int c;

	a = 10;
	b = 20;
	printf("my_func=%p\n", my_func);
	c = my_func(a, &b);
	printf("%d\n", c);
	return 0;
}
