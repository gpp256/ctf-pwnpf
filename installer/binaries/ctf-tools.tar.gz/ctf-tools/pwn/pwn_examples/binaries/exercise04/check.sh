gdb -q dep -ex start -ex vmmap -ex q
gdb -q nodep -ex start -ex vmmap -ex q
objdump -d -Mintel ssp
objdump -d -Mintel nossp
readelf -S relro
readelf -S norelro
./pie
./nopie

