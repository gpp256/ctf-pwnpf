表層解析・静的解析
============================

## セキュリティ対策（OS）
```
+ NX: No eXecute/Never eXecute, Exec Shield, (DEP: Data Execution Prevention)
  確認方法：checkesc --file binary
  無効化: gcc -m32 -o nodep test.c -z execstack

+ ASLR: Address Space Layout Randomization
  確認方法: sysctl -a 2>/dev/null| grep randomi (kernel.randomize_va_space =0の場合は無効）
  無効化: sysctl kernel.randomize_va_space=0 (有効化したい場合は1や2を指定）
```

## セキュリティ対策（実行ファイル）
```
+ Stack Canary, StackGuard, SSP: Stack Smashing Protector
  確認方法：checkesc --file binary
  無効化: gcc -m32 -o nossp test.c –fno-stack-protector
+ RELRO: RELocation Read-Only
  確認方法：checkesc –file binary
  無効化: gcc –m32 –o norelro test.c -Wl,-z,norelro
+ PIE: Position Independent Executables
  確認方法：checkesc –file binary
  無効化: デフォルト無効（有効化したい場合はgcc -m32 -o pie test.c –pie）
  Ubuntu: 18.04ではデフォルト有効 (無効化したい場合はgcc -m32 -no-pie -o nopie test.c ）
```

## 参考：checksec の出力結果の例
```
+ DEP有効、stack上でshell起動不可/困難=> 例：ret2libc/ropなどで攻略
  $ checksec –file dep
  RELRO STACK CANARY NX PIE RPATH RUNPATH FILE
  No RELRO No canary found NX enabled No PIE No RPATH No RUNPATH dep
+ ssp有効＋DEP有効=> 例：カナリア値をリークしてbofで攻める
  $ checksec –file ssp
  RELRO STACK CANARY NX PIE RPATH RUNPATH FILE
  No RELRO Canary found NX enabled No PIE No RPATH No RUNPATH ssp
+ RELRO有効、GOT上書き不可＋DEP有効=> 例：__environをリークしてリターンアドレスを上書き
  $ checksec –file relro
  RELRO STACK CANARY NX PIE RPATH RUNPATH FILE
  Full RELRO No canary found NX enabled No PIE No RPATH No RUNPATH relro
+ DEP有効＋PIE有効=> 例：基準として使えるアドレスをリークして相対アドレスで攻める
  $ checksec –file pie
  RELRO STACK CANARY NX PIE RPATH RUNPATH FILE
  No RELRO No canary found NX enabled PIE enabled No RPATH No RUNPATH pie

ポイント：ssp無効の場合、9割以上の確率でbofによる攻略が可能
```

## 動作検証
```
sh make.sh build
```

