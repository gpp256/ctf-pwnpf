参考: アセンブラを利用して学習
================================

## 動作検証

```
sh –x make.sh build; # ビルド
strace -f ./test 2>&1 | egrep -e open -e read -e write ; # システムコールの実行確認
/bin/sh起動のためのShellcodeの作成: objdump -d -Mintel shell.o | 
  /opt/ctf/tools/akitools/disastobin | 
  /opt/ctf/tools/akitools/tohex
```

