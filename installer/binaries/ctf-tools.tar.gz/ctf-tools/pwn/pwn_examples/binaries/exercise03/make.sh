#!/bin/sh
case "$1" in
  build)
	echo FLAG_GGGGGGGGGGGGGGGG > flag
	nasm -f elf test.asm ; ld -m elf_i386 -o test test.o
	;;
  clean)
	rm -f flag test.o test ;;
  *)    echo "Usage: ./$0 {build|clean}";;
esac

