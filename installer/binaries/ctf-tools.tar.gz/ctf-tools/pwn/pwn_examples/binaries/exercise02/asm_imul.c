#include<stdio.h>
#include<stdlib.h>
#include<string.h>

static void invoke_command();
static int get_key(int i) ;

int main(int argc, char **argv) {
        long int answer = 0;
        char buf[100];
        printf("Access Code: ");
        fgets(buf, sizeof(buf), stdin);
        answer = strtol(buf, NULL, 10);
        if (get_key(5) == answer) invoke_command();
        return 1;
}

static void invoke_command() {
	printf("OK\n");
        system("/bin/sh"); exit(0);
}

static int get_key(int i) {
        int in1=10,in2=i,out1;
        __asm__ __volatile__(
	"mov %%eax, %1; mov %%ecx, %2; imul %%ecx; mov %0, %%eax;" 
        : "=r"(out1) 
        : "r"(in1),"r"(in2) 
        : "%eax");
        return out1;
}
