参考：インラインアセンブラで学習
==================================

## 参考URL

[GCCのインラインアセンブラの書き方for x86](http://d.hatena.ne.jp/wocota/20090628/1246188338)

[GCC Inline Assembler](http://caspar.hazymoon.jp/OpenBSD/annex/gcc_inline_asm.html)

## 例

    static int get_key() {
    int in1=10,in2=5,out1;
    __asm__ ("mov %%eax, %1; /* eaxにin1の値をストア*/
    add %%eax, %2; /* eaxとin2を加算*/
    mov %0, %%eax;" /* eaxをout1にストア*/
    :"=r"(out1) /* 出力変数out1が%0 */
    :"r"(in1),"r"(in2) /* 入力変数in1が%1 変数in2が%2 */
    :"%eax" /* 破壊されるレジスタ*/
    );
    return out1;
    }

## 動作検証

```
make
./asm
./asm_imul
```
