/* bof.c */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#define MILLI_SEC 1000

#if 0
static void check() {
    if (ptrace(PTRACE_TRACEME, 0, 1, 0) == -1) {
        printf("NGGGGGGGGGGGGGGGGG!\n");
        exit(1);
    }
}
#endif

static void get_flag() {
    char buf[100];
    int fd = open("flag",0); 
    read(fd, buf, 100);
    write(1, buf, 100);
    exit(0);
    //execve("/bin/sh", 0, 0); exit(0);
}

int main(int argc, char *argv[]) {
    char buf[300] = {};  /* set all bytes to zero */
    struct timespec req = {5, 500*MILLI_SEC};
    printf("buf = %p\n", buf);
    fflush(stdout);
    nanosleep(&req, NULL);
    memset(buf, '\0', sizeof(buf));
    read(0, buf, 0x300);
    puts(buf);
    return 0;
}

