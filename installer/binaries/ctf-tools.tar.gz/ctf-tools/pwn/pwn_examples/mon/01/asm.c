#include<stdio.h>
#include<stdlib.h>
#include<string.h>

static void invoke_command();
static int get_key(int i) ;

int main(int argc, char **argv) {
        long int answer = 0;
        char buf[100];
        printf("Access Code: ");
	fflush(stdout);
        fgets(buf, sizeof(buf), stdin);
        answer = strtol(buf, NULL, 10);
        if (get_key(0) == answer) invoke_command();
        return 1;
}

static void invoke_command() {
        system("/bin/sh"); exit(0);
}

static int get_key(int i) {
        int a = i;
        __asm__ __volatile__("mov %%ecx, %0;" : : "r"(i) : "%ecx");
        __asm__ __volatile__("mov %%edx, %0;" : : "r"(a) : "%edx");
        __asm__ __volatile__("jmp label_2;");
        __asm__ __volatile__("label_1:");
        __asm__ __volatile__("add %%ecx, 0x1;" : : : "%ecx");
        __asm__ __volatile__("mov %%eax, %%ecx;" : : : "%eax");
        __asm__ __volatile__("add %%edx, %%eax;" : : : "%edx");
        __asm__ __volatile__("label_2:");
        __asm__ __volatile__("cmp %ecx, 0xfefe;");
        __asm__ __volatile__("jle label_1;");
        __asm__ __volatile__("sub %%edx, 0x321;" : : : "%edx");
        __asm__ __volatile__("mov %%ecx, %%edx;" : : : "%ecx");
        __asm__ __volatile__("imul %%ecx;" : : : "%edx", "%eax");
        __asm__ __volatile__("mov %0, %%edx" : "=r"(a));
        return a;
}
