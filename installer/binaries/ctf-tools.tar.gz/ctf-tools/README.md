ctf-tools
==========

CTFで役立ちそうなツールを集めたいと考えています。

共有可能なスクリプトなどがありましたら是非追加をお願いします。

使用法
-------------

    e.g.
    $ cd steganography
    $ sh imagemagick.sh
    Usage: ./magemagick.sh infile {jpg|bmp|png|...}
    $ sh imagemagick.sh hoge.jpg bmp

ディレクトリ構成
--------------------

    ./steganography/ : various tools for steganography
    ./forensics/     : various tools for forensics
    ./crypto/        : various tools for decrypting the encrypted parts
    ./network/       : various tools for packet analysis
    ./pwn/           : various tools for pwn/reversing categories
    ...

Links
--------

http://www.imagemagick.org/  
http://foremost.sourceforge.net/  


License
---------

MIT
