tmux new-window -n test
tmux split-window -h
tmux split-window -v -t test.0
tmux split-window -v -t test.1

tmux send-keys -t test.0 'echo 0' C-m
#tmux send-keys -t test.1 'ssh root@192.168.1.4' C-m
#tmux send-keys -t test.2 'ssh root@192.168.1.8' C-m
tmux send-keys -t test.3 'echo 3' C-m
